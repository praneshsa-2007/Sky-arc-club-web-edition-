'use strict';

/**
 * Tournament Fixture Generator, Scheduling & Progression Service
 * Supports:
 *  - LEAGUE (Round Robin)
 *  - KNOCKOUT (Single Elimination with Byes & Auto-Advancement)
 *  - NESTED_LEAGUE (Group Leagues -> Knockout)
 *  - KNOCKOUT_TO_LEAGUE (Knockout until QF -> Top Qualifiers League -> Final)
 *  - POOL_KNOCKOUT (Pools -> Knockout bracket)
 *
 * Conflict Prevention:
 *  - No participant playing 2 matches at the same time
 *  - No court double booked at the same time
 *  - No referee assigned to 2 matches at the same time
 *  - Byes auto-advance winner immediately
 */

// Fisher-Yates shuffle
function shuffle(array) {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// Next power of 2
function nextPowerOf2(n) {
  let p = 1;
  while (p < n) p <<= 1;
  return p;
}

// Round name helper for knockout brackets
function getRoundName(totalParticipantsInBracket, currentRoundParticipants) {
  if (currentRoundParticipants === 2) return 'Final';
  if (currentRoundParticipants === 4) return 'Semi Finals';
  if (currentRoundParticipants === 8) return 'Quarter Finals';
  return `Round of ${currentRoundParticipants}`;
}

/**
 * Helper to parse HH:MM from strings like "09:00 AM" or "09:00"
 */
function parseStartTime(timingStr) {
  if (!timingStr) return '09:00:00';
  const match = timingStr.match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/i);
  if (!match) return '09:00:00';
  let hours = parseInt(match[1], 10);
  const mins = match[2];
  const meridiem = match[3] ? match[3].toUpperCase() : null;
  if (meridiem === 'PM' && hours < 12) hours += 12;
  if (meridiem === 'AM' && hours === 12) hours = 0;
  return `${String(hours).padStart(2, '0')}:${mins}:00`;
}

/**
 * Add minutes to "HH:MM:SS" time string
 */
function addMinutesToTime(timeStr, minutesToAdd) {
  const parts = timeStr.split(':');
  let totalMins = parseInt(parts[0], 10) * 60 + parseInt(parts[1], 10) + minutesToAdd;
  const h = Math.floor(totalMins / 60) % 24;
  const m = totalMins % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:00`;
}

/**
 * Conflict-free Court & Random Referee Scheduler
 * Schedules match list sequentially across available courts & referees.
 */
function assignCourtAndRefereeSchedule(matches, tournament, courts, referees, startDate) {
  if (!matches || matches.length === 0) return [];
  const activeCourts = courts.filter(c => c.active);
  const activeReferees = referees.filter(r => r.status === 'ACTIVE');

  let baseTime = parseStartTime(tournament.timing);
  const matchDurationMins = 45; // 45 minutes per match slot
  const scheduledDate = startDate || tournament.start_date;

  // Track busy resources per time slot:
  // slotTime -> { courts: Set(court_id), referees: Set(referee_id), participants: Set(team_id) }
  const slotBookings = {};

  function getSlot(timeStr) {
    if (!slotBookings[timeStr]) {
      slotBookings[timeStr] = {
        courts: new Set(),
        referees: new Set(),
        participants: new Set()
      };
    }
    return slotBookings[timeStr];
  }

  // Pre-sort matches so earlier rounds get scheduled first
  matches.forEach(m => {
    if (m.is_bye) {
      m.scheduled_date = null;
      m.scheduled_time = null;
      m.court_id = null;
      m.referee_id = null;
      return;
    }

    let currentTime = baseTime;
    let assigned = false;
    let attempts = 0;

    while (!assigned && attempts < 500) {
      attempts++;
      const slot = getSlot(currentTime);

      const team1Id = m.team1_id;
      const team2Id = m.team2_id;

      // Check participant clash in this time slot
      const hasTeamClash = (team1Id && slot.participants.has(team1Id)) ||
                           (team2Id && slot.participants.has(team2Id));

      if (!hasTeamClash) {
        // Find available court
        const freeCourt = activeCourts.find(c => !slot.courts.has(c.id));
        // Find available referees
        const freeReferees = activeReferees.filter(r => !slot.referees.has(r.id));

        if (freeCourt) {
          // Select referee randomly if referees exist
          let chosenRef = null;
          if (freeReferees.length > 0) {
            const randIdx = Math.floor(Math.random() * freeReferees.length);
            chosenRef = freeReferees[randIdx];
          }

          m.scheduled_date = scheduledDate;
          m.scheduled_time = currentTime;
          m.court_id = freeCourt.id;
          m.referee_id = chosenRef ? chosenRef.id : (activeReferees[0]?.id || null);

          // Mark resources busy in this slot
          slot.courts.add(freeCourt.id);
          if (chosenRef) slot.referees.add(chosenRef.id);
          if (team1Id) slot.participants.add(team1Id);
          if (team2Id) slot.participants.add(team2Id);

          assigned = true;
          break;
        }
      }

      // If cannot schedule in current time slot, shift forward by 45 mins
      currentTime = addMinutesToTime(currentTime, matchDurationMins);
    }

    if (!assigned) {
      m.scheduled_date = scheduledDate;
      m.scheduled_time = currentTime;
      m.court_id = activeCourts[0]?.id || null;
      m.referee_id = activeReferees[0]?.id || null;
    }
  });

  return matches;
}

/**
 * 1. KNOCKOUT FIXTURE GENERATION
 * Standard single-elimination bracket with fair randomized draw and byes.
 */
async function generateKnockoutFixtures(tournament, category, teams, courts, referees, conn) {
  if (teams.length < 2) {
    throw new Error('At least 2 participants/teams are required to generate fixtures.');
  }

  // Stage record
  const [stageRes] = await conn.query(`
    INSERT INTO tournament_stages (tournament_id, category_id, stage_name, stage_type, sequence_order, status)
    VALUES (?, ?, 'Knockout Main Bracket', 'KNOCKOUT', 1, 'ONGOING')
  `, [tournament.id, category.id]);
  const stageId = stageRes.insertId;

  // Determine bracket size (power of 2)
  const numTeams = teams.length;
  const bracketSize = nextPowerOf2(numTeams);
  const numByes = bracketSize - numTeams;

  // Randomize teams
  const shuffledTeams = shuffle(teams);

  // Position teams and byes
  // In standard seeding, byes are distributed evenly
  const bracketSlots = new Array(bracketSize).fill(null);
  let teamIdx = 0;
  for (let i = 0; i < bracketSize; i++) {
    // If byes needed, alternate byes at end of pairs
    if (i % 2 === 1 && numByes > 0 && (bracketSize - i) <= numByes * 2) {
      bracketSlots[i] = 'BYE';
    } else if (teamIdx < shuffledTeams.length) {
      bracketSlots[i] = shuffledTeams[teamIdx++];
    } else {
      bracketSlots[i] = 'BYE';
    }
  }

  // Calculate rounds
  const totalRounds = Math.log2(bracketSize);
  const roundMatches = []; // array of match arrays per round

  let matchCounter = 1;

  // First Round matches
  const round1Matches = [];
  const r1Participants = bracketSize;
  const round1Name = getRoundName(bracketSize, r1Participants);

  for (let i = 0; i < bracketSize; i += 2) {
    const t1 = bracketSlots[i];
    const t2 = bracketSlots[i + 1];

    const isBye = (t1 === 'BYE' || t2 === 'BYE');
    const actualTeam1 = (t1 && t1 !== 'BYE') ? t1 : null;
    const actualTeam2 = (t2 && t2 !== 'BYE') ? t2 : null;
    const byeWinner = isBye ? (actualTeam1 || actualTeam2) : null;

    round1Matches.push({
      round_number: 1,
      round_name: round1Name,
      match_number: matchCounter++,
      team1_id: actualTeam1 ? actualTeam1.id : null,
      team2_id: actualTeam2 ? actualTeam2.id : null,
      is_bye: isBye ? 1 : 0,
      status: isBye ? 'BYE' : 'SCHEDULED',
      winner_id: byeWinner ? byeWinner.id : null,
      stage_id: stageId
    });
  }
  roundMatches.push(round1Matches);

  // Subsequent Rounds (R2 ... Final)
  let prevRoundMatches = round1Matches;
  for (let r = 2; r <= totalRounds; r++) {
    const curRoundMatches = [];
    const participantsInRound = bracketSize / Math.pow(2, r - 1);
    const roundName = getRoundName(bracketSize, participantsInRound);

    for (let i = 0; i < prevRoundMatches.length; i += 2) {
      curRoundMatches.push({
        round_number: r,
        round_name: roundName,
        match_number: matchCounter++,
        team1_id: null,
        team2_id: null,
        is_bye: 0,
        status: 'SCHEDULED',
        winner_id: null,
        stage_id: stageId
      });
    }
    roundMatches.push(curRoundMatches);
    prevRoundMatches = curRoundMatches;
  }

  // Assign schedule (courts & referees) to non-bye round 1 matches
  const allMatchesToInsert = [];
  for (let r = 0; r < roundMatches.length; r++) {
    for (let m = 0; m < roundMatches[r].length; m++) {
      allMatchesToInsert.push(roundMatches[r][m]);
    }
  }

  // Conflict-free scheduling on Round 1 matches
  assignCourtAndRefereeSchedule(roundMatches[0], tournament, courts, referees, tournament.start_date);

  // Insert matches round by round to link next_match_id
  const insertedMatchesByRound = [];

  for (let r = totalRounds - 1; r >= 0; r--) {
    const currentRoundList = roundMatches[r];
    const insertedInCurrentRound = [];

    for (let i = 0; i < currentRoundList.length; i++) {
      const m = currentRoundList[i];
      let nextMatchId = null;
      let nextMatchSlot = null;

      if (r < totalRounds - 1) {
        const nextRoundList = insertedMatchesByRound[0]; // the round above us
        const nextIdx = Math.floor(i / 2);
        nextMatchId = nextRoundList[nextIdx].id;
        nextMatchSlot = (i % 2 === 0) ? 'TEAM1' : 'TEAM2';
      }

      const [mRes] = await conn.query(`
        INSERT INTO tournament_matches (
          tournament_id, category_id, stage_id, round_name, round_number, match_number,
          team1_id, team2_id, is_bye, scheduled_date, scheduled_time, court_id, referee_id,
          status, winner_id, next_match_id, next_match_slot
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        tournament.id, category.id, m.stage_id, m.round_name, m.round_number, m.match_number,
        m.team1_id, m.team2_id, m.is_bye, m.scheduled_date || null, m.scheduled_time || null,
        m.court_id || null, m.referee_id || null, m.status, m.winner_id,
        nextMatchId, nextMatchSlot
      ]);

      insertedInCurrentRound.push({ id: mRes.insertId, ...m, nextMatchId, nextMatchSlot });
    }
    insertedMatchesByRound.unshift(insertedInCurrentRound);
  }

  // Auto-advance byes into round 2!
  const round1Inserted = insertedMatchesByRound[0];
  for (const m of round1Inserted) {
    if (m.is_bye && m.winner_id && m.nextMatchId) {
      const colToUpdate = m.nextMatchSlot === 'TEAM1' ? 'team1_id' : 'team2_id';
      await conn.query(`
        UPDATE tournament_matches SET ${colToUpdate} = ? WHERE id = ?
      `, [m.winner_id, m.nextMatchId]);
    }
  }

  return { stageId, totalMatches: allMatchesToInsert.length };
}

/**
 * 2. LEAGUE FIXTURE GENERATION
 * Round Robin (All play all) with points table
 */
async function generateLeagueFixtures(tournament, category, teams, courts, referees, conn) {
  if (teams.length < 2) {
    throw new Error('At least 2 participants/teams are required for a league tournament.');
  }

  const [stageRes] = await conn.query(`
    INSERT INTO tournament_stages (tournament_id, category_id, stage_name, stage_type, sequence_order, status)
    VALUES (?, ?, 'League Stage', 'LEAGUE', 1, 'ONGOING')
  `, [tournament.id, category.id]);
  const stageId = stageRes.insertId;

  // Initialize standings for every team
  for (const team of teams) {
    await conn.query(`
      INSERT INTO tournament_standings (tournament_id, category_id, stage_id, group_name, team_id)
      VALUES (?, ?, ?, 'LEAGUE', ?)
    `, [tournament.id, category.id, stageId, team.id]);
  }

  // Generate round robin pairings using Berger / Circle method
  const shuffledTeams = shuffle(teams);
  const n = shuffledTeams.length;
  const isOdd = n % 2 !== 0;
  const teamList = [...shuffledTeams];
  if (isOdd) teamList.push(null); // dummy for bye

  const numRounds = teamList.length - 1;
  const half = teamList.length / 2;
  const matches = [];
  let matchCounter = 1;

  for (let r = 0; r < numRounds; r++) {
    const roundName = `Round ${r + 1}`;
    for (let i = 0; i < half; i++) {
      const t1 = teamList[i];
      const t2 = teamList[teamList.length - 1 - i];

      if (t1 && t2) {
        matches.push({
          round_number: r + 1,
          round_name: roundName,
          match_number: matchCounter++,
          team1_id: t1.id,
          team2_id: t2.id,
          is_bye: 0,
          status: 'SCHEDULED',
          stage_id: stageId
        });
      }
    }
    // Rotate circle (keep element 0 fixed, rotate others)
    const fixed = teamList[0];
    const last = teamList.pop();
    teamList.splice(1, 0, last);
    teamList[0] = fixed;
  }

  // Schedule conflict-free
  assignCourtAndRefereeSchedule(matches, tournament, courts, referees, tournament.start_date);

  for (const m of matches) {
    await conn.query(`
      INSERT INTO tournament_matches (
        tournament_id, category_id, stage_id, round_name, round_number, match_number,
        team1_id, team2_id, is_bye, scheduled_date, scheduled_time, court_id, referee_id,
        status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      tournament.id, category.id, m.stage_id, m.round_name, m.round_number, m.match_number,
      m.team1_id, m.team2_id, m.is_bye, m.scheduled_date, m.scheduled_time, m.court_id, m.referee_id,
      m.status
    ]);
  }

  return { stageId, totalMatches: matches.length };
}

/**
 * 3. NESTED LEAGUE FIXTURE GENERATION
 * Divides teams into Groups (e.g. Group A, Group B).
 * Each group plays a Round Robin league.
 * Pre-creates Knockout semi-final/final stage.
 */
async function generateNestedLeagueFixtures(tournament, category, teams, courts, referees, conn) {
  if (teams.length < 4) {
    throw new Error('At least 4 participants/teams are required for a nested league tournament.');
  }

  const numGroups = 2; // Group A & Group B
  const shuffledTeams = shuffle(teams);
  const groups = { 'GROUP_A': [], 'GROUP_B': [] };

  shuffledTeams.forEach((team, idx) => {
    const groupKey = (idx % 2 === 0) ? 'GROUP_A' : 'GROUP_B';
    groups[groupKey].push(team);
  });

  const [stageRes] = await conn.query(`
    INSERT INTO tournament_stages (tournament_id, category_id, stage_name, stage_type, sequence_order, status)
    VALUES (?, ?, 'Nested League Group Stage', 'LEAGUE', 1, 'ONGOING')
  `, [tournament.id, category.id]);
  const groupStageId = stageRes.insertId;

  // Initialize standings
  for (const [groupName, groupTeams] of Object.entries(groups)) {
    for (const team of groupTeams) {
      await conn.query(`
        INSERT INTO tournament_standings (tournament_id, category_id, stage_id, group_name, team_id)
        VALUES (?, ?, ?, ?, ?)
      `, [tournament.id, category.id, groupStageId, groupName, team.id]);
    }
  }

  const matches = [];
  let matchCounter = 1;

  for (const [groupName, groupTeams] of Object.entries(groups)) {
    const gList = [...groupTeams];
    if (gList.length % 2 !== 0) gList.push(null);
    const numRounds = gList.length - 1;
    const half = gList.length / 2;

    for (let r = 0; r < numRounds; r++) {
      const roundName = `${groupName === 'GROUP_A' ? 'Group A' : 'Group B'} - Round ${r + 1}`;
      for (let i = 0; i < half; i++) {
        const t1 = gList[i];
        const t2 = gList[gList.length - 1 - i];
        if (t1 && t2) {
          matches.push({
            round_number: r + 1,
            round_name: roundName,
            match_number: matchCounter++,
            team1_id: t1.id,
            team2_id: t2.id,
            is_bye: 0,
            status: 'SCHEDULED',
            stage_id: groupStageId
          });
        }
      }
      const fixed = gList[0];
      const last = gList.pop();
      gList.splice(1, 0, last);
      gList[0] = fixed;
    }
  }

  assignCourtAndRefereeSchedule(matches, tournament, courts, referees, tournament.start_date);

  for (const m of matches) {
    await conn.query(`
      INSERT INTO tournament_matches (
        tournament_id, category_id, stage_id, round_name, round_number, match_number,
        team1_id, team2_id, is_bye, scheduled_date, scheduled_time, court_id, referee_id, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      tournament.id, category.id, m.stage_id, m.round_name, m.round_number, m.match_number,
      m.team1_id, m.team2_id, m.is_bye, m.scheduled_date, m.scheduled_time, m.court_id, m.referee_id, m.status
    ]);
  }

  // Create stage 2 placeholder (Knockout Finals)
  await conn.query(`
    INSERT INTO tournament_stages (tournament_id, category_id, stage_name, stage_type, sequence_order, status)
    VALUES (?, ?, 'Nested League Knockout Finals', 'KNOCKOUT', 2, 'UPCOMING')
  `, [tournament.id, category.id]);

  return { stageId: groupStageId, totalMatches: matches.length };
}

/**
 * 4. KNOCKOUT UNTIL QUARTER FINALS -> LEAGUE
 * Hybrid format: Knockout rounds down to Quarter Finals/Top 4, then League stage!
 */
async function generateKnockoutToLeagueFixtures(tournament, category, teams, courts, referees, conn) {
  if (teams.length < 4) {
    throw new Error('At least 4 participants/teams required for Knockout to League format.');
  }

  // If teams <= 4, directly create the League stage!
  if (teams.length <= 4) {
    return generateLeagueFixtures(tournament, category, teams, courts, referees, conn);
  }

  // Otherwise, run knockout rounds until 4 finalists remain
  const [stageRes] = await conn.query(`
    INSERT INTO tournament_stages (tournament_id, category_id, stage_name, stage_type, sequence_order, status)
    VALUES (?, ?, 'Knockout Preliminary Stage', 'KNOCKOUT', 1, 'ONGOING')
  `, [tournament.id, category.id]);
  const stageId = stageRes.insertId;

  // Next stage placeholder: League Stage
  await conn.query(`
    INSERT INTO tournament_stages (tournament_id, category_id, stage_name, stage_type, sequence_order, status)
    VALUES (?, ?, 'Final League Stage', 'LEAGUE', 2, 'UPCOMING')
  `, [tournament.id, category.id]);

  // Generate knockout preliminaries down to 4
  const bracketSize = nextPowerOf2(teams.length);
  const shuffledTeams = shuffle(teams);
  const bracketSlots = new Array(bracketSize).fill(null);
  const numByes = bracketSize - teams.length;

  let teamIdx = 0;
  for (let i = 0; i < bracketSize; i++) {
    if (i % 2 === 1 && numByes > 0 && (bracketSize - i) <= numByes * 2) {
      bracketSlots[i] = 'BYE';
    } else if (teamIdx < shuffledTeams.length) {
      bracketSlots[i] = shuffledTeams[teamIdx++];
    } else {
      bracketSlots[i] = 'BYE';
    }
  }

  // Run knockout down until 4 slots
  const matches = [];
  let matchCounter = 1;
  const r1Matches = [];

  for (let i = 0; i < bracketSize; i += 2) {
    const t1 = bracketSlots[i];
    const t2 = bracketSlots[i + 1];
    const isBye = (t1 === 'BYE' || t2 === 'BYE');
    const actual1 = (t1 && t1 !== 'BYE') ? t1 : null;
    const actual2 = (t2 && t2 !== 'BYE') ? t2 : null;
    const byeWinner = isBye ? (actual1 || actual2) : null;

    r1Matches.push({
      round_number: 1,
      round_name: 'Knockout Preliminary Round 1',
      match_number: matchCounter++,
      team1_id: actual1 ? actual1.id : null,
      team2_id: actual2 ? actual2.id : null,
      is_bye: isBye ? 1 : 0,
      status: isBye ? 'BYE' : 'SCHEDULED',
      winner_id: byeWinner ? byeWinner.id : null,
      stage_id: stageId
    });
  }

  assignCourtAndRefereeSchedule(r1Matches, tournament, courts, referees, tournament.start_date);

  for (const m of r1Matches) {
    await conn.query(`
      INSERT INTO tournament_matches (
        tournament_id, category_id, stage_id, round_name, round_number, match_number,
        team1_id, team2_id, is_bye, scheduled_date, scheduled_time, court_id, referee_id,
        status, winner_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      tournament.id, category.id, m.stage_id, m.round_name, m.round_number, m.match_number,
      m.team1_id, m.team2_id, m.is_bye, m.scheduled_date, m.scheduled_time, m.court_id, m.referee_id,
      m.status, m.winner_id
    ]);
  }

  return { stageId, totalMatches: r1Matches.length };
}

/**
 * 5. POOL / GROUP SYSTEM -> KNOCKOUT
 * Divides participants into POOL A and POOL B.
 * Each pool operates as a round-robin league.
 * When all pool matches finish, top 1 or 2 per pool are automatically placed into the Knockout stage!
 */
async function generatePoolKnockoutFixtures(tournament, category, teams, courts, referees, conn) {
  if (teams.length < 4) {
    throw new Error('At least 4 participants/teams are required for a Pool to Knockout tournament.');
  }

  const [poolStageRes] = await conn.query(`
    INSERT INTO tournament_stages (tournament_id, category_id, stage_name, stage_type, sequence_order, status)
    VALUES (?, ?, 'Pool Stage (Round Robin)', 'POOL', 1, 'ONGOING')
  `, [tournament.id, category.id]);
  const poolStageId = poolStageRes.insertId;

  // Knockout stage placeholder
  await conn.query(`
    INSERT INTO tournament_stages (tournament_id, category_id, stage_name, stage_type, sequence_order, status)
    VALUES (?, ?, 'Championship Knockout Finals', 'KNOCKOUT', 2, 'UPCOMING')
  `, [tournament.id, category.id]);

  const shuffledTeams = shuffle(teams);
  const pools = { 'POOL_A': [], 'POOL_B': [] };

  shuffledTeams.forEach((team, idx) => {
    const poolKey = (idx % 2 === 0) ? 'POOL_A' : 'POOL_B';
    pools[poolKey].push(team);
  });

  // Initialize pool standings
  for (const [poolKey, poolTeams] of Object.entries(pools)) {
    for (const team of poolTeams) {
      await conn.query(`
        INSERT INTO tournament_standings (tournament_id, category_id, stage_id, group_name, team_id)
        VALUES (?, ?, ?, ?, ?)
      `, [tournament.id, category.id, poolStageId, poolKey, team.id]);
    }
  }

  const matches = [];
  let matchCounter = 1;

  for (const [poolKey, poolTeams] of Object.entries(pools)) {
    const pList = [...poolTeams];
    if (pList.length % 2 !== 0) pList.push(null);
    const numRounds = pList.length - 1;
    const half = pList.length / 2;

    for (let r = 0; r < numRounds; r++) {
      const roundName = `${poolKey === 'POOL_A' ? 'Pool A' : 'Pool B'} - Match ${r + 1}`;
      for (let i = 0; i < half; i++) {
        const t1 = pList[i];
        const t2 = pList[pList.length - 1 - i];
        if (t1 && t2) {
          matches.push({
            round_number: r + 1,
            round_name: roundName,
            match_number: matchCounter++,
            team1_id: t1.id,
            team2_id: t2.id,
            is_bye: 0,
            status: 'SCHEDULED',
            stage_id: poolStageId
          });
        }
      }
      const fixed = pList[0];
      const last = pList.pop();
      pList.splice(1, 0, last);
      pList[0] = fixed;
    }
  }

  assignCourtAndRefereeSchedule(matches, tournament, courts, referees, tournament.start_date);

  for (const m of matches) {
    await conn.query(`
      INSERT INTO tournament_matches (
        tournament_id, category_id, stage_id, round_name, round_number, match_number,
        team1_id, team2_id, is_bye, scheduled_date, scheduled_time, court_id, referee_id, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      tournament.id, category.id, m.stage_id, m.round_name, m.round_number, m.match_number,
      m.team1_id, m.team2_id, m.is_bye, m.scheduled_date, m.scheduled_time, m.court_id, m.referee_id, m.status
    ]);
  }

  return { stageId: poolStageId, totalMatches: matches.length };
}

/**
 * Handle Match Result Submission & Auto-progression
 */
async function processMatchResult({ matchId, team1Score, team2Score, scoresDetail, winnerId, refereeUserId, manOfMatch, durationMinutes, remarks, conn }) {
  // Fetch match details
  const [mRows] = await conn.query(`
    SELECT m.*, t.format as tournament_format, t.status as tournament_status,
           c.type as category_type, s.stage_type, s.group_name as stage_group
    FROM tournament_matches m
    JOIN tournaments t ON m.tournament_id = t.id
    JOIN tournament_categories c ON m.category_id = c.id
    LEFT JOIN tournament_stages s ON m.stage_id = s.id
    WHERE m.id = ?
  `, [matchId]);

  if (mRows.length === 0) throw new Error('Match not found.');
  const match = mRows[0];

  if (match.status === 'COMPLETED') {
    throw new Error('This match has already been completed and locked.');
  }

  // Check if result is already locked
  const [existingResult] = await conn.query('SELECT * FROM match_results WHERE match_id = ?', [matchId]);
  if (existingResult.length > 0 && existingResult[0].is_locked) {
    throw new Error('This match result is locked and cannot be modified.');
  }

  const loserId = (match.team1_id === winnerId) ? match.team2_id : match.team1_id;

  // Insert locked result
  await conn.query(`
    INSERT INTO match_results (
      match_id, team1_score, team2_score, scores_detail, winner_id,
      submitted_by_user_id, submitted_at, locked_at, is_locked, man_of_match, duration_minutes, remarks
    ) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW(), 1, ?, ?, ?)
    ON DUPLICATE KEY UPDATE
      team1_score = VALUES(team1_score),
      team2_score = VALUES(team2_score),
      scores_detail = VALUES(scores_detail),
      winner_id = VALUES(winner_id),
      submitted_by_user_id = VALUES(submitted_by_user_id),
      man_of_match = VALUES(man_of_match),
      duration_minutes = VALUES(duration_minutes),
      remarks = VALUES(remarks)
  `, [
    matchId, team1Score, team2Score, scoresDetail || `${team1Score}-${team2Score}`, winnerId,
    refereeUserId, manOfMatch || null, durationMinutes || null, remarks || null
  ]);

  // Update match record
  await conn.query(`
    UPDATE tournament_matches
    SET status = 'COMPLETED', winner_id = ?, loser_id = ?, man_of_match = ?, completed_at = NOW()
    WHERE id = ?
  `, [winnerId, loserId, manOfMatch || null, matchId]);

  // AUTO TOURNAMENT PROGRESSION
  // 1. Knockout match progression
  if (match.next_match_id) {
    const colToUpdate = match.next_match_slot === 'TEAM1' ? 'team1_id' : 'team2_id';
    await conn.query(`
      UPDATE tournament_matches SET ${colToUpdate} = ? WHERE id = ?
    `, [winnerId, match.next_match_id]);
  }

  // 2. League / Pool Standings update
  if (match.stage_type === 'LEAGUE' || match.stage_type === 'POOL') {
    await updateLeagueStandings(match, team1Score, team2Score, winnerId, loserId, conn);
    // Check if group/pool stage is completed and auto-advance qualifiers!
    await checkAndAdvanceStageQualifiers(match, conn);
  }

  // 3. Check if final match in the tournament/category
  await checkCategoryAndTournamentCompletion(match, winnerId, loserId, conn);

  return { success: true, winnerId, loserId };
}

/**
 * Update standings for league and pool stages
 */
async function updateLeagueStandings(match, t1Score, t2Score, winnerId, loserId, conn) {
  // Update team 1
  const t1Won = (match.team1_id === winnerId);
  await conn.query(`
    UPDATE tournament_standings
    SET played = played + 1,
        won = won + ?,
        lost = lost + ?,
        points = points + ?,
        points_scored = points_scored + ?,
        points_conceded = points_conceded + ?,
        point_diff = point_diff + ?
    WHERE tournament_id = ? AND team_id = ?
  `, [
    t1Won ? 1 : 0,
    t1Won ? 0 : 1,
    t1Won ? 2 : 0,
    t1Score,
    t2Score,
    t1Score - t2Score,
    match.tournament_id,
    match.team1_id
  ]);

  // Update team 2
  const t2Won = (match.team2_id === winnerId);
  await conn.query(`
    UPDATE tournament_standings
    SET played = played + 1,
        won = won + ?,
        lost = lost + ?,
        points = points + ?,
        points_scored = points_scored + ?,
        points_conceded = points_conceded + ?,
        point_diff = point_diff + ?
    WHERE tournament_id = ? AND team_id = ?
  `, [
    t2Won ? 1 : 0,
    t2Won ? 0 : 1,
    t2Won ? 2 : 0,
    t2Score,
    t1Score,
    t2Score - t1Score,
    match.tournament_id,
    match.team2_id
  ]);

  // Re-rank standings in this stage & group
  const [rows] = await conn.query(`
    SELECT id, group_name FROM tournament_standings
    WHERE tournament_id = ?
    ORDER BY group_name, points DESC, point_diff DESC, points_scored DESC
  `, [match.tournament_id]);

  let currentRank = 1;
  let currentGroup = '';
  for (const r of rows) {
    if (r.group_name !== currentGroup) {
      currentGroup = r.group_name;
      currentRank = 1;
    }
    await conn.query('UPDATE tournament_standings SET rank_position = ? WHERE id = ?', [currentRank++, r.id]);
  }
}

/**
 * Check if pool or group stage completed, and advance top teams to knockout finals!
 */
async function checkAndAdvanceStageQualifiers(match, conn) {
  // Check if any matches remain in this stage
  const [pending] = await conn.query(`
    SELECT COUNT(*) as count FROM tournament_matches
    WHERE stage_id = ? AND status != 'COMPLETED' AND status != 'BYE'
  `, [match.stage_id]);

  if (pending[0].count === 0) {
    // Stage is completed! Mark stage completed
    await conn.query('UPDATE tournament_stages SET status = "COMPLETED" WHERE id = ?', [match.stage_id]);

    // Check for next stage
    const [nextStages] = await conn.query(`
      SELECT * FROM tournament_stages
      WHERE tournament_id = ? AND category_id = ? AND sequence_order > 1
      ORDER BY sequence_order ASC LIMIT 1
    `, [match.tournament_id, match.category_id]);

    if (nextStages.length > 0) {
      const nextStage = nextStages[0];
      // Mark next stage ongoing
      await conn.query('UPDATE tournament_stages SET status = "ONGOING" WHERE id = ?', [nextStage.id]);

      // If next stage is KNOCKOUT, qualify top 1 from each group/pool
      if (nextStage.stage_type === 'KNOCKOUT') {
        const [groups] = await conn.query(`
          SELECT DISTINCT group_name FROM tournament_standings WHERE stage_id = ?
        `, [match.stage_id]);

        const topTeams = [];
        for (const g of groups) {
          const [top] = await conn.query(`
            SELECT team_id FROM tournament_standings
            WHERE stage_id = ? AND group_name = ?
            ORDER BY rank_position ASC LIMIT 1
          `, [match.stage_id, g.group_name]);
          if (top.length > 0) {
            topTeams.push(top[0].team_id);
            await conn.query(`
              UPDATE tournament_standings SET qualified = 1 WHERE stage_id = ? AND team_id = ?
            `, [match.stage_id, top[0].team_id]);
          }
        }

        if (topTeams.length >= 2) {
          // Check if championship match already exists
          const [existingMatches] = await conn.query(`
            SELECT id FROM tournament_matches WHERE stage_id = ?
          `, [nextStage.id]);

          if (existingMatches.length === 0) {
            // Create championship final match
            const [courts] = await conn.query('SELECT * FROM courts WHERE active = 1');
            const [referees] = await conn.query('SELECT * FROM referees WHERE status = "ACTIVE"');
            const [tRows] = await conn.query('SELECT * FROM tournaments WHERE id = ?', [match.tournament_id]);

            const finalMatch = [{
              round_number: 1,
              round_name: 'Championship Final',
              match_number: 99,
              team1_id: topTeams[0],
              team2_id: topTeams[1],
              is_bye: 0,
              status: 'SCHEDULED',
              stage_id: nextStage.id
            }];

            assignCourtAndRefereeSchedule(finalMatch, tRows[0], courts, referees, tRows[0].end_date);

            await conn.query(`
              INSERT INTO tournament_matches (
                tournament_id, category_id, stage_id, round_name, round_number, match_number,
                team1_id, team2_id, is_bye, scheduled_date, scheduled_time, court_id, referee_id, status
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `, [
              match.tournament_id, match.category_id, nextStage.id, finalMatch[0].round_name,
              finalMatch[0].round_number, finalMatch[0].match_number, finalMatch[0].team1_id, finalMatch[0].team2_id,
              0, finalMatch[0].scheduled_date, finalMatch[0].scheduled_time, finalMatch[0].court_id,
              finalMatch[0].referee_id, 'SCHEDULED'
            ]);
          }
        }
      }
    }
  }
}

/**
 * Check if the entire category and tournament are completed
 */
async function checkCategoryAndTournamentCompletion(match, winnerId, loserId, conn) {
  // Check if all matches in the category are completed
  const [catPending] = await conn.query(`
    SELECT COUNT(*) as count FROM tournament_matches
    WHERE category_id = ? AND status != 'COMPLETED' AND status != 'BYE'
  `, [match.category_id]);

  if (catPending[0].count === 0) {
    // If this was a knockout final or league leader, set category winner & runner up
    let catWinner = winnerId;
    let catRunnerUp = loserId;

    if (match.stage_type === 'LEAGUE') {
      const [topStandings] = await conn.query(`
        SELECT team_id FROM tournament_standings
        WHERE category_id = ? ORDER BY rank_position ASC LIMIT 2
      `, [match.category_id]);
      if (topStandings.length > 0) catWinner = topStandings[0].team_id;
      if (topStandings.length > 1) catRunnerUp = topStandings[1].team_id;
    }

    await conn.query(`
      UPDATE tournament_categories
      SET winner_team_id = ?, runner_up_team_id = ?
      WHERE id = ?
    `, [catWinner, catRunnerUp, match.category_id]);
  }

  // Check if all categories in the tournament are completed
  const [allPending] = await conn.query(`
    SELECT COUNT(*) as count FROM tournament_matches
    WHERE tournament_id = ? AND status != 'COMPLETED' AND status != 'BYE'
  `, [match.tournament_id]);

  if (allPending[0].count === 0) {
    // Set tournament status to COMPLETED automatically
    await conn.query(`
      UPDATE tournaments SET status = 'COMPLETED', winner_id = ?, runner_up_id = ? WHERE id = ?
    `, [winnerId, loserId, match.tournament_id]);
  }
}

module.exports = {
  generateKnockoutFixtures,
  generateLeagueFixtures,
  generateNestedLeagueFixtures,
  generateKnockoutToLeagueFixtures,
  generatePoolKnockoutFixtures,
  processMatchResult
};
