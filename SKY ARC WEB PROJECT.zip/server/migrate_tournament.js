'use strict';

/**
 * Migration script for Tournament Management Features
 */
require('dotenv').config();
const { pool } = require('./db');

async function migrate() {
  const conn = await pool.getConnection();
  try {
    console.log('🔄 Starting tournament database migration...');
    await conn.query('START TRANSACTION');

    // 1. Update users role ENUM to include 'REFEREE'
    console.log('1. Updating users.role ENUM...');
    await conn.query(`
      ALTER TABLE users 
      MODIFY COLUMN role ENUM('MEMBER','COACH','COURT_INCHARGE','REFEREE') NOT NULL DEFAULT 'MEMBER'
    `);

    // 2. Referees table
    console.log('2. Creating referees table...');
    await conn.query(`
      CREATE TABLE IF NOT EXISTS referees (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NULL,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(150) NULL,
        phone VARCHAR(20) NULL,
        qualification VARCHAR(150) NULL,
        experience VARCHAR(100) NULL,
        availability VARCHAR(255) DEFAULT 'AVAILABLE',
        status ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    // 3. Tournaments table
    console.log('3. Creating tournaments table...');
    await conn.query(`
      CREATE TABLE IF NOT EXISTS tournaments (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(200) NOT NULL,
        description TEXT NULL,
        format ENUM('LEAGUE','KNOCKOUT','NESTED_LEAGUE','KNOCKOUT_TO_LEAGUE','POOL_KNOCKOUT') NOT NULL DEFAULT 'KNOCKOUT',
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        venue VARCHAR(150) NOT NULL,
        timing VARCHAR(100) NOT NULL,
        food_provided TINYINT(1) NOT NULL DEFAULT 0,
        poster_url VARCHAR(255) NULL,
        status ENUM('DRAFT','REGISTRATION_OPEN','REGISTRATION_CLOSED','UPCOMING','ONGOING','COMPLETED','CANCELLED') NOT NULL DEFAULT 'DRAFT',
        registration_deadline DATE NULL,
        format_config JSON NULL,
        winner_id INT UNSIGNED NULL,
        runner_up_id INT UNSIGNED NULL,
        created_by INT UNSIGNED NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    // 4. Tournament categories table
    console.log('4. Creating tournament_categories table...');
    await conn.query(`
      CREATE TABLE IF NOT EXISTS tournament_categories (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        tournament_id INT UNSIGNED NOT NULL,
        category_name ENUM('MENS_SINGLES','WOMENS_SINGLES','MENS_DOUBLES','WOMENS_DOUBLES','MIXED_DOUBLES') NOT NULL,
        display_name VARCHAR(100) NOT NULL,
        type ENUM('SINGLES','DOUBLES') NOT NULL,
        winner_team_id INT UNSIGNED NULL,
        runner_up_team_id INT UNSIGNED NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
        UNIQUE KEY uq_tourn_cat (tournament_id, category_name)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    // 5. Tournament registrations table
    console.log('5. Creating tournament_registrations table...');
    await conn.query(`
      CREATE TABLE IF NOT EXISTS tournament_registrations (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        tournament_id INT UNSIGNED NOT NULL,
        category_id INT UNSIGNED NOT NULL,
        member_id INT UNSIGNED NOT NULL,
        partner_id INT UNSIGNED NULL,
        team_name VARCHAR(255) NOT NULL,
        pair_identifier VARCHAR(100) NOT NULL,
        registration_status ENUM('CONFIRMED','CANCELLED') NOT NULL DEFAULT 'CONFIRMED',
        group_name VARCHAR(50) NULL,
        seed INT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
        FOREIGN KEY (category_id) REFERENCES tournament_categories(id) ON DELETE CASCADE,
        FOREIGN KEY (member_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (partner_id) REFERENCES users(id) ON DELETE SET NULL,
        UNIQUE KEY uq_cat_pair (category_id, pair_identifier),
        INDEX idx_member (member_id),
        INDEX idx_partner (partner_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    // 6. Tournament stages table
    console.log('6. Creating tournament_stages table...');
    await conn.query(`
      CREATE TABLE IF NOT EXISTS tournament_stages (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        tournament_id INT UNSIGNED NOT NULL,
        category_id INT UNSIGNED NOT NULL,
        stage_name VARCHAR(100) NOT NULL,
        stage_type ENUM('KNOCKOUT','LEAGUE','POOL') NOT NULL,
        group_name VARCHAR(50) NULL,
        sequence_order INT NOT NULL DEFAULT 1,
        status ENUM('UPCOMING','ONGOING','COMPLETED') NOT NULL DEFAULT 'UPCOMING',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
        FOREIGN KEY (category_id) REFERENCES tournament_categories(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    // 7. Tournament matches table
    console.log('7. Creating tournament_matches table...');
    await conn.query(`
      CREATE TABLE IF NOT EXISTS tournament_matches (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        tournament_id INT UNSIGNED NOT NULL,
        category_id INT UNSIGNED NOT NULL,
        stage_id INT UNSIGNED NULL,
        round_name VARCHAR(100) NOT NULL,
        round_number INT NOT NULL DEFAULT 1,
        match_number INT NOT NULL,
        team1_id INT UNSIGNED NULL,
        team2_id INT UNSIGNED NULL,
        is_bye TINYINT(1) NOT NULL DEFAULT 0,
        scheduled_date DATE NULL,
        scheduled_time TIME NULL,
        court_id INT UNSIGNED NULL,
        referee_id INT UNSIGNED NULL,
        status ENUM('SCHEDULED','ONGOING','COMPLETED','CANCELLED','BYE') NOT NULL DEFAULT 'SCHEDULED',
        winner_id INT UNSIGNED NULL,
        loser_id INT UNSIGNED NULL,
        man_of_match VARCHAR(100) NULL,
        next_match_id INT UNSIGNED NULL,
        next_match_slot ENUM('TEAM1','TEAM2') NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        completed_at DATETIME NULL,
        FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
        FOREIGN KEY (category_id) REFERENCES tournament_categories(id) ON DELETE CASCADE,
        FOREIGN KEY (stage_id) REFERENCES tournament_stages(id) ON DELETE SET NULL,
        FOREIGN KEY (team1_id) REFERENCES tournament_registrations(id) ON DELETE SET NULL,
        FOREIGN KEY (team2_id) REFERENCES tournament_registrations(id) ON DELETE SET NULL,
        FOREIGN KEY (court_id) REFERENCES courts(id) ON DELETE SET NULL,
        FOREIGN KEY (referee_id) REFERENCES referees(id) ON DELETE SET NULL,
        FOREIGN KEY (winner_id) REFERENCES tournament_registrations(id) ON DELETE SET NULL,
        FOREIGN KEY (loser_id) REFERENCES tournament_registrations(id) ON DELETE SET NULL,
        FOREIGN KEY (next_match_id) REFERENCES tournament_matches(id) ON DELETE SET NULL,
        INDEX idx_sched_court (court_id, scheduled_date, scheduled_time),
        INDEX idx_sched_ref (referee_id, scheduled_date, scheduled_time)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    // 8. Match results table
    console.log('8. Creating match_results table...');
    await conn.query(`
      CREATE TABLE IF NOT EXISTS match_results (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        match_id INT UNSIGNED NOT NULL,
        team1_score INT NOT NULL DEFAULT 0,
        team2_score INT NOT NULL DEFAULT 0,
        scores_detail VARCHAR(100) NULL,
        winner_id INT UNSIGNED NOT NULL,
        submitted_by_user_id INT UNSIGNED NOT NULL,
        submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        locked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        is_locked TINYINT(1) NOT NULL DEFAULT 1,
        man_of_match VARCHAR(100) NULL,
        duration_minutes INT NULL,
        remarks TEXT NULL,
        FOREIGN KEY (match_id) REFERENCES tournament_matches(id) ON DELETE CASCADE,
        FOREIGN KEY (winner_id) REFERENCES tournament_registrations(id) ON DELETE CASCADE,
        FOREIGN KEY (submitted_by_user_id) REFERENCES users(id) ON DELETE CASCADE,
        UNIQUE KEY uq_match_res (match_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    // 9. Tournament standings table
    console.log('9. Creating tournament_standings table...');
    await conn.query(`
      CREATE TABLE IF NOT EXISTS tournament_standings (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        tournament_id INT UNSIGNED NOT NULL,
        category_id INT UNSIGNED NOT NULL,
        stage_id INT UNSIGNED NULL,
        group_name VARCHAR(50) NOT NULL DEFAULT 'MAIN',
        team_id INT UNSIGNED NOT NULL,
        played INT NOT NULL DEFAULT 0,
        won INT NOT NULL DEFAULT 0,
        lost INT NOT NULL DEFAULT 0,
        points INT NOT NULL DEFAULT 0,
        points_scored INT NOT NULL DEFAULT 0,
        points_conceded INT NOT NULL DEFAULT 0,
        point_diff INT NOT NULL DEFAULT 0,
        rank_position INT NOT NULL DEFAULT 0,
        qualified TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
        FOREIGN KEY (category_id) REFERENCES tournament_categories(id) ON DELETE CASCADE,
        FOREIGN KEY (stage_id) REFERENCES tournament_stages(id) ON DELETE CASCADE,
        FOREIGN KEY (team_id) REFERENCES tournament_registrations(id) ON DELETE CASCADE,
        UNIQUE KEY uq_group_team (stage_id, group_name, team_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    await conn.query('COMMIT');
    console.log('🎉 Tournament migration completed successfully!');
  } catch (err) {
    await conn.query('ROLLBACK');
    console.error('❌ Migration failed:', err);
    throw err;
  } finally {
    conn.release();
    process.exit(0);
  }
}

migrate();
