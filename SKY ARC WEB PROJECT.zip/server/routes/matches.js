'use strict';

const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/matchController');
const { authenticate } = require('../middleware/auth');

router.get('/:id', authenticate, ctrl.getMatch);
router.post('/:id/result', authenticate, ctrl.submitMatchResult);

module.exports = router;
