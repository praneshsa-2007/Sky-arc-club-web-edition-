'use strict';
const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/settingsController');
const { authenticate, authorize } = require('../middleware/auth');

router.get('/',     authenticate, ctrl.getSettings);
router.put('/',     authenticate, authorize('COACH','COURT_INCHARGE'), ctrl.updateSettings);
router.get('/batches',   authenticate, ctrl.getBatches);
router.put('/batches',   authenticate, authorize('COACH','COURT_INCHARGE'), ctrl.updateBatches);

module.exports = router;
