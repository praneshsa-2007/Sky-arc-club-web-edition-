'use strict';
const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/userController');
const { authenticate, authorize } = require('../middleware/auth');

router.get('/',         authenticate, authorize('COURT_INCHARGE','COACH'), ctrl.listUsers);
router.post('/',        authenticate, authorize('COURT_INCHARGE'), ctrl.createUser);
router.get('/:id',      authenticate, authorize('COURT_INCHARGE','COACH'), ctrl.getUser);
router.put('/:id/status', authenticate, authorize('COURT_INCHARGE','COACH'), ctrl.setUserStatus);
router.put('/:id',      authenticate, authorize('COURT_INCHARGE'), ctrl.updateUser);

module.exports = router;
