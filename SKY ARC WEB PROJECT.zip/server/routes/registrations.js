'use strict';

const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/registrationController');
const { authenticate } = require('../middleware/auth');

router.get('/my', authenticate, ctrl.getMyRegistrations);
router.get('/my-next-match', authenticate, ctrl.getMyNextMatch);

module.exports = router;
