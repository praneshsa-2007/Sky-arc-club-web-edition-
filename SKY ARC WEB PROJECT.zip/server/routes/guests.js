'use strict';
const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/guestController');
const { authenticate, authorize } = require('../middleware/auth');

router.get('/',    authenticate, authorize('COURT_INCHARGE','COACH'), ctrl.listGuests);
router.post('/',   authenticate, authorize('COURT_INCHARGE'), ctrl.createGuestReservation);
router.delete('/:id', authenticate, authorize('COURT_INCHARGE'), ctrl.cancelGuestReservation);

module.exports = router;
