'use strict';

const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/tournamentController');
const regCtrl = require('../controllers/registrationController');
const { authenticate, authorize } = require('../middleware/auth');

// Public/Authenticated tournament listing & details
router.get('/', ctrl.listTournaments);
router.get('/:id', ctrl.getTournament);
router.get('/:id/fixtures', ctrl.getFixtures);
router.get('/:id/standings', ctrl.getStandings);
router.get('/:id/participants', ctrl.getParticipants);

// Coach tournament management
router.post('/', authenticate, authorize('COACH'), ctrl.createTournament);
router.post('/upload-poster', authenticate, authorize('COACH'), ctrl.uploadPoster);
router.post('/:id/publish', authenticate, authorize('COACH'), ctrl.publishTournament);
router.post('/:id/status', authenticate, authorize('COACH'), ctrl.setTournamentStatus);
router.post('/:id/generate-fixtures', authenticate, authorize('COACH'), ctrl.generateFixtures);

// End tournament with 2-step confirmation (Coach or Court In-Charge)
router.post('/:id/end', authenticate, authorize('COACH', 'COURT_INCHARGE'), ctrl.endTournament);

// Delete tournament (Coach only)
router.delete('/:id', authenticate, authorize('COACH'), ctrl.deleteTournament);

// Member registration for a tournament
router.post('/:id/register', authenticate, authorize('MEMBER', 'COACH'), regCtrl.registerForTournament);

module.exports = router;
