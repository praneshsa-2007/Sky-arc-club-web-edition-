'use strict';
const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/timetableController');
const { authenticate } = require('../middleware/auth');

router.get('/', authenticate, ctrl.getTimetable);

module.exports = router;
