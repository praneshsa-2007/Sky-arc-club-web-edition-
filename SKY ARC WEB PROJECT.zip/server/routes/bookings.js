'use strict';
const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/bookingController');
const { authenticate, authorize } = require('../middleware/auth');

router.get('/',           authenticate, ctrl.listBookings);
router.post('/',          authenticate, ctrl.createBooking);
router.delete('/:id',     authenticate, ctrl.cancelBooking);
router.post('/reserve',   authenticate, authorize('COACH','COURT_INCHARGE'), ctrl.reserveWholeCourt);

module.exports = router;
