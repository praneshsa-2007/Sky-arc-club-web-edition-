'use strict';
const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/courtController');
const { authenticate, authorize } = require('../middleware/auth');

router.get('/',        authenticate, ctrl.listCourts);
router.post('/',       authenticate, authorize('COACH'), ctrl.createCourt);
router.put('/:id',     authenticate, authorize('COACH'), ctrl.updateCourt);
router.delete('/:id',  authenticate, authorize('COACH'), ctrl.deleteCourt);

module.exports = router;
