'use strict';

const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/refereeController');
const { authenticate, authorize } = require('../middleware/auth');

router.get('/', authenticate, authorize('COURT_INCHARGE', 'COACH'), ctrl.listReferees);
router.post('/', authenticate, authorize('COURT_INCHARGE'), ctrl.createReferee);
router.put('/:id', authenticate, authorize('COURT_INCHARGE'), ctrl.updateReferee);
router.get('/my-matches', authenticate, authorize('REFEREE'), ctrl.getMyAssignedMatches);

module.exports = router;
