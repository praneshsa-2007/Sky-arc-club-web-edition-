'use strict';
const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/slotController');
const { authenticate, authorize } = require('../middleware/auth');

router.get('/',           authenticate, ctrl.listSlots);
router.post('/',          authenticate, authorize('COACH'), ctrl.createSlot);
router.put('/:id',        authenticate, authorize('COACH'), ctrl.updateSlot);
router.delete('/:id',     authenticate, authorize('COACH'), ctrl.deleteSlot);
router.post('/copy',      authenticate, authorize('COACH'), ctrl.copySlots);

module.exports = router;
