'use strict';

require('dotenv').config();
const bcrypt = require('bcrypt');
const { pool } = require('../db');

const SALT_ROUNDS = 12;

async function seedTournamentData() {
  const conn = await pool.getConnection();
  try {
    console.log('🌱 Seeding members and referees...');

    const sampleMembers = [
      { name: 'Arun Kumar', username: 'arun_k', email: 'arun@skyarc.local', role: 'MEMBER' },
      { name: 'Karthik Raja', username: 'karthik_r', email: 'karthik@skyarc.local', role: 'MEMBER' },
      { name: 'Suresh Raina', username: 'suresh_r', email: 'suresh@skyarc.local', role: 'MEMBER' },
      { name: 'Praveen Chand', username: 'praveen_c', email: 'praveen@skyarc.local', role: 'MEMBER' },
      { name: 'Vijay Anand', username: 'vijay_a', email: 'vijay@skyarc.local', role: 'MEMBER' },
      { name: 'Priya Mani', username: 'priya_m', email: 'priya@skyarc.local', role: 'MEMBER' },
      { name: 'Ananya Sharma', username: 'ananya_s', email: 'ananya@skyarc.local', role: 'MEMBER' },
    ];

    const hash = await bcrypt.hash('2015672754', SALT_ROUNDS);

    for (const m of sampleMembers) {
      await conn.query(`
        INSERT INTO users (name, username, email, password_hash, role, active)
        VALUES (?, ?, ?, ?, ?, 1)
        ON DUPLICATE KEY UPDATE name=VALUES(name)
      `, [m.name, m.username, m.email, hash, m.role]);
    }

    const sampleReferees = [
      {
        name: 'Ramesh Kumar',
        username: 'referee_ramesh',
        email: 'ramesh.ref@skyarc.local',
        phone: '9876543210',
        qualification: 'National BWF Level 2 Umpire',
        experience: '8 Years Professional Officiating'
      },
      {
        name: 'Deepak Selvam',
        username: 'referee_deepak',
        email: 'deepak.ref@skyarc.local',
        phone: '9876543211',
        qualification: 'State Badminton Umpire Certified',
        experience: '5 Years Academy & State Tournaments'
      },
      {
        name: 'Shankar Raman',
        username: 'referee_shankar',
        email: 'shankar.ref@skyarc.local',
        phone: '9876543212',
        qualification: 'Chief Badminton Referee Certified',
        experience: '12 Years Senior Match Referee'
      }
    ];

    for (const r of sampleReferees) {
      // Create user account for referee
      const [uRes] = await conn.query(`
        INSERT INTO users (name, username, email, password_hash, role, phone, active)
        VALUES (?, ?, ?, ?, 'REFEREE', ?, 1)
        ON DUPLICATE KEY UPDATE name=VALUES(name), role='REFEREE'
      `, [r.name, r.username, r.email, hash, r.phone]);

      const [uRows] = await conn.query('SELECT id FROM users WHERE username = ?', [r.username]);
      const userId = uRows[0]?.id;

      // Create referee record
      const [refRows] = await conn.query('SELECT id FROM referees WHERE name = ?', [r.name]);
      if (refRows.length === 0) {
        await conn.query(`
          INSERT INTO referees (user_id, name, email, phone, qualification, experience, availability, status)
          VALUES (?, ?, ?, ?, ?, ?, 'AVAILABLE', 'ACTIVE')
        `, [userId, r.name, r.email, r.phone, r.qualification, r.experience]);
      } else {
        await conn.query(`
          UPDATE referees SET user_id = ?, email = ?, phone = ?, qualification = ?, experience = ?, status = 'ACTIVE'
          WHERE id = ?
        `, [userId, r.email, r.phone, r.qualification, r.experience, refRows[0].id]);
      }
    }

    console.log('✅ Seeded members and referees with password "2015672754"!');
  } catch (err) {
    console.error('❌ Seeding failed:', err);
  } finally {
    conn.release();
    process.exit(0);
  }
}

seedTournamentData();
