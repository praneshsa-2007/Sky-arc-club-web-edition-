'use strict';

/**
 * Seed script - creates the two default development users.
 * Run: node server/seed/seed.js
 * Make sure your .env and database are set up first.
 */

require('dotenv').config();
const bcrypt = require('bcrypt');
const { pool, testConnection } = require('../db');

const SALT_ROUNDS = 12;

const users = [
  {
    name:            'Pranesh SA',
    username:        'pranesh_sa',
    email:           'praneshsajey@gmail.com',
    password:        '2015672754',
    age:             19,
    role:            'COURT_INCHARGE',
    phone:           null,
    date_of_joining: new Date().toISOString().slice(0, 10),
  },
  {
    name:            'Venkatesh',
    username:        'Venkatesh',
    email:           'coach.venkatesh@skyarc.local',  // unique email for coach
    password:        '2015672754',
    age:             45,
    role:            'COACH',
    phone:           null,
    date_of_joining: new Date().toISOString().slice(0, 10),
  },
];

async function seed() {
  await testConnection();

  for (const u of users) {
    try {
      const hash = await bcrypt.hash(u.password, SALT_ROUNDS);
      await pool.execute(
        `INSERT INTO users (name, username, email, password_hash, age, role, phone, date_of_joining)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           password_hash = VALUES(password_hash),
           age = VALUES(age),
           role = VALUES(role),
           name = VALUES(name)`,
        [u.name, u.username, u.email, hash, u.age, u.role, u.phone, u.date_of_joining]
      );
      console.log(`✅  Seeded user: ${u.username} (${u.role})`);
    } catch (err) {
      console.error(`❌  Failed to seed ${u.username}:`, err.message);
    }
  }

  const defaultCourts = [
    { court_number: '1', court_name: 'Court 1', court_type: 'WOODEN' },
    { court_number: '2', court_name: 'Court 2', court_type: 'WOODEN' },
    { court_number: '3', court_name: 'Court 3', court_type: 'WOODEN' },
    { court_number: '4', court_name: 'Court 4', court_type: 'WOODEN' },
  ];

  for (const c of defaultCourts) {
    try {
      await pool.execute(
        `INSERT INTO courts (court_number, court_name, court_type, active)
         VALUES (?, ?, ?, 1)
         ON DUPLICATE KEY UPDATE court_name=VALUES(court_name), court_type=VALUES(court_type), active=1`,
        [c.court_number, c.court_name, c.court_type]
      );
      console.log(`✅  Seeded court: ${c.court_name} (${c.court_type})`);
    } catch (err) {
      console.error(`❌  Failed to seed ${c.court_name}:`, err.message);
    }
  }

  console.log('\n🎉  Seed complete!');
  console.log('   Court Incharge: pranesh_sa  / 2015672754');
  console.log('   Coach:          Venkatesh   / 2015672754');
  console.log('   Courts:         Court 1, Court 2, Court 3, Court 4 (WOODEN)');
  process.exit(0);
}

seed();
