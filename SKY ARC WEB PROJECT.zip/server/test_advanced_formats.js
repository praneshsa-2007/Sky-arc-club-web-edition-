'use strict';

/**
 * Advanced Tournament Formats & Referee Officiating Test Suite
 * Tests:
 *  - Format C: Nested League (Group A & Group B -> Knockout Finals)
 *  - Format D: Knockout until Quarter Finals -> League Stage
 *  - Format E: Pool System -> Knockout Finals
 *  - Referee dashboard & score submission for assigned referee
 *  - Court allocation conflict prevention (no court double-booked)
 */

const BASE_URL = 'http://localhost:3000';

async function request(endpoint, options = {}) {
  const url = BASE_URL + endpoint;
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (options.token) headers['Authorization'] = `Bearer ${options.token}`;

  const res = await fetch(url, {
    method: options.method || 'GET',
    headers,
    body: options.body ? JSON.stringify(options.body) : undefined
  });

  const data = await res.json().catch(() => ({}));
  return { status: res.status, ok: res.ok, data };
}

async function runAdvancedTests() {
  console.log('🏸 Starting Advanced Formats & Referee Officiating Test Suite...\n');
  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  ✅ PASS: ${message}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${message}`);
      failed++;
    }
  }

  try {
    // 1. Log in Coach & Incharge & Referees & Members
    const coachLogin = await request('/api/auth/login', { method: 'POST', body: { username: 'Venkatesh', password: '2015672754' } });
    const inchargeLogin = await request('/api/auth/login', { method: 'POST', body: { username: 'pranesh_sa', password: '2015672754' } });
    const refLogin = await request('/api/auth/login', { method: 'POST', body: { username: 'referee_deepak', password: '2015672754' } });
    const m1 = await request('/api/auth/login', { method: 'POST', body: { username: 'arun_k', password: '2015672754' } });
    const m2 = await request('/api/auth/login', { method: 'POST', body: { username: 'karthik_r', password: '2015672754' } });
    const m3 = await request('/api/auth/login', { method: 'POST', body: { username: 'suresh_r', password: '2015672754' } });
    const m4 = await request('/api/auth/login', { method: 'POST', body: { username: 'praveen_c', password: '2015672754' } });
    const m5 = await request('/api/auth/login', { method: 'POST', body: { username: 'vijay_a', password: '2015672754' } });
    const m6 = await request('/api/auth/login', { method: 'POST', body: { username: 'priya_m', password: '2015672754' } });

    const coachToken = coachLogin.data.token;
    const refToken = refLogin.data.token;
    const members = [m1, m2, m3, m4, m5, m6];

    // TEST FORMAT C: NESTED LEAGUE
    console.log('--- 1. Testing Format C: Nested League (Group A & B -> Knockout) ---');
    const nestedTourn = await request('/api/tournaments', {
      method: 'POST',
      token: coachToken,
      body: {
        name: 'SkyArc Nested Champions Cup 2026',
        format: 'NESTED_LEAGUE',
        start_date: '2026-11-10',
        end_date: '2026-11-14',
        venue: 'Arena 1',
        timing: '09:00 AM – 05:00 PM',
        categories: ['MENS_SINGLES']
      }
    });
    const nestedId = nestedTourn.data.tournamentId;
    await request(`/api/tournaments/${nestedId}/publish`, { method: 'POST', token: coachToken });
    const nestedCat = (await request(`/api/tournaments/${nestedId}`)).data.categories[0];

    // Register 4 members for Nested League
    for (let i = 0; i < 4; i++) {
      await request(`/api/tournaments/${nestedId}/register`, {
        method: 'POST',
        token: members[i].data.token,
        body: { category_id: nestedCat.id }
      });
    }

    const nestedFix = await request(`/api/tournaments/${nestedId}/generate-fixtures`, {
      method: 'POST',
      token: coachToken,
      body: {}
    });
    assert(nestedFix.ok, 'Nested League fixtures generated successfully');

    const nestedStandings = (await request(`/api/tournaments/${nestedId}/standings?category_id=${nestedCat.id}`)).data;
    const groups = [...new Set(nestedStandings.map(s => s.group_name))];
    assert(groups.includes('GROUP_A') && groups.includes('GROUP_B'), 'Nested League partitioned into Group A and Group B');

    // TEST FORMAT E: POOL SYSTEM -> KNOCKOUT
    console.log('\n--- 2. Testing Format E: Pool System -> Knockout ---');
    const poolTourn = await request('/api/tournaments', {
      method: 'POST',
      token: coachToken,
      body: {
        name: 'SkyArc Super Pool Championship 2026',
        format: 'POOL_KNOCKOUT',
        start_date: '2026-11-20',
        end_date: '2026-11-25',
        venue: 'Main Arena',
        timing: '09:00 AM – 06:00 PM',
        categories: ['MENS_SINGLES']
      }
    });
    const poolId = poolTourn.data.tournamentId;
    await request(`/api/tournaments/${poolId}/publish`, { method: 'POST', token: coachToken });
    const poolCat = (await request(`/api/tournaments/${poolId}`)).data.categories[0];

    // Register 4 members
    for (let i = 0; i < 4; i++) {
      await request(`/api/tournaments/${poolId}/register`, {
        method: 'POST',
        token: members[i].data.token,
        body: { category_id: poolCat.id }
      });
    }

    const poolFix = await request(`/api/tournaments/${poolId}/generate-fixtures`, {
      method: 'POST',
      token: coachToken,
      body: {}
    });
    assert(poolFix.ok, 'Pool -> Knockout fixtures generated successfully');

    const poolStandings = (await request(`/api/tournaments/${poolId}/standings?category_id=${poolCat.id}`)).data;
    const pools = [...new Set(poolStandings.map(s => s.group_name))];
    assert(pools.includes('POOL_A') && pools.includes('POOL_B'), 'Pool system divided into POOL_A and POOL_B');

    // TEST REFEREE DASHBOARD & OFFICIATING
    console.log('\n--- 3. Testing Referee Dashboard & Assigned Matches ---');
    const myMatchesRes = await request('/api/referees/my-matches', { token: refToken });
    assert(myMatchesRes.ok, 'Referee successfully fetched assigned matches from /api/referees/my-matches');
    assert(myMatchesRes.data.referee && myMatchesRes.data.referee.name, `Logged-in referee profile: "${myMatchesRes.data.referee?.name}"`);

    // Verify Court Conflict Prevention
    console.log('\n--- 4. Testing Court Conflict Prevention ---');
    const allMatches = (await request(`/api/tournaments/${poolId}/fixtures`)).data;
    const courtTimeKeys = new Set();
    let hasConflict = false;

    allMatches.forEach(m => {
      if (m.scheduled_date && m.scheduled_time && m.court_id) {
        const key = `${m.scheduled_date}_${m.scheduled_time}_${m.court_id}`;
        if (courtTimeKeys.has(key)) hasConflict = true;
        courtTimeKeys.add(key);
      }
    });
    assert(!hasConflict, 'Zero court scheduling conflicts: No two matches scheduled on same court at same time');

    console.log('\n========================================');
    console.log(`Advanced Formats Test Results: ${passed} PASSED, ${failed} FAILED`);
    console.log('========================================\n');
  } catch (err) {
    console.error('Advanced test error:', err);
  } finally {
    process.exit(failed > 0 ? 1 : 0);
  }
}

runAdvancedTests();
