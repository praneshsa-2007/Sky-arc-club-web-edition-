'use strict';

/**
 * End-to-End Automated Test Suite for Badminton Tournament Management
 * Tests all rules specified in the prompt:
 *  - Authentication & Role verification
 *  - Tournament creation (Coach)
 *  - Registration validation (Singles & Doubles, duplicate checks, pair normalization)
 *  - Fixture generation across formats (Knockout, League, Pool->Knockout, byes)
 *  - Conflict-free Court & Random Referee allocation
 *  - Referee confidentiality (API protection)
 *  - Referee result submission & Result Locking
 *  - Auto tournament progression (Knockout advancement & League standings)
 *  - 2-step End Tournament confirmation & Historical viewing
 */

const BASE_URL = 'http://localhost:3000';

async function request(endpoint, options = {}) {
  const url = BASE_URL + endpoint;
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (options.token) headers['Authorization'] = `Bearer ${options.token}`;

  const res = await fetch(url, {
    method: options.method || 'GET',
    headers,
    body: options.body ? JSON.stringify(options.body) : undefined
  });

  const data = await res.json().catch(() => ({}));
  return { status: res.status, ok: res.ok, data };
}

async function runTests() {
  console.log('🏸 Starting Comprehensive Badminton Tournament Test Suite...\n');
  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  ✅ PASS: ${message}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${message}`);
      failed++;
    }
  }

  try {
    // 1. Authenticate users
    console.log('--- 1. Authenticating Roles ---');
    const coachLogin = await request('/api/auth/login', {
      method: 'POST',
      body: { username: 'Venkatesh', password: '2015672754' }
    });
    assert(coachLogin.ok && coachLogin.data.token, 'Coach login successful');
    const coachToken = coachLogin.data.token;

    const inchargeLogin = await request('/api/auth/login', {
      method: 'POST',
      body: { username: 'pranesh_sa', password: '2015672754' }
    });
    assert(inchargeLogin.ok && inchargeLogin.data.token, 'Court Incharge login successful');
    const inchargeToken = inchargeLogin.data.token;

    const refLogin = await request('/api/auth/login', {
      method: 'POST',
      body: { username: 'referee_ramesh', password: '2015672754' }
    });
    assert(refLogin.ok && refLogin.data.token, 'Referee login successful');
    const refToken = refLogin.data.token;

    const member1Login = await request('/api/auth/login', {
      method: 'POST',
      body: { username: 'arun_k', password: '2015672754' }
    });
    const member2Login = await request('/api/auth/login', {
      method: 'POST',
      body: { username: 'karthik_r', password: '2015672754' }
    });
    const member3Login = await request('/api/auth/login', {
      method: 'POST',
      body: { username: 'suresh_r', password: '2015672754' }
    });
    const member4Login = await request('/api/auth/login', {
      method: 'POST',
      body: { username: 'praveen_c', password: '2015672754' }
    });
    const member5Login = await request('/api/auth/login', {
      method: 'POST',
      body: { username: 'vijay_a', password: '2015672754' }
    });
    const member6Login = await request('/api/auth/login', {
      method: 'POST',
      body: { username: 'priya_m', password: '2015672754' }
    });
    const member7Login = await request('/api/auth/login', {
      method: 'POST',
      body: { username: 'ananya_s', password: '2015672754' }
    });
    assert(member1Login.ok && member2Login.ok, 'Member logins successful');

    const m1Token = member1Login.data.token;
    const m1Id = member1Login.data.user.id;
    const m2Token = member2Login.data.token;
    const m2Id = member2Login.data.user.id;
    const m3Token = member3Login.data.token;
    const m3Id = member3Login.data.user.id;
    const m4Token = member4Login.data.token;
    const m4Id = member4Login.data.user.id;
    const m5Token = member5Login.data.token;
    const m5Id = member5Login.data.user.id;
    const m6Token = member6Login.data.token;
    const m6Id = member6Login.data.user.id;
    const m7Token = member7Login.data.token;
    const m7Id = member7Login.data.user.id;

    // 2. Tournament Creation by Coach
    console.log('\n--- 2. Tournament Creation by Coach ---');
    const tournRes = await request('/api/tournaments', {
      method: 'POST',
      token: coachToken,
      body: {
        name: 'SkyArc State Open 2026',
        description: 'Annual championship tournament',
        format: 'KNOCKOUT',
        start_date: '2026-10-20',
        end_date: '2026-10-22',
        venue: 'Main Indoor Stadium',
        timing: '09:00 AM – 06:00 PM',
        food_provided: true,
        categories: ['MENS_SINGLES', 'MENS_DOUBLES', 'MIXED_DOUBLES']
      }
    });
    assert(tournRes.ok && tournRes.data.tournamentId, 'Coach successfully created tournament with multiple categories');
    const tournId = tournRes.data.tournamentId;

    // Publish tournament
    const pubRes = await request(`/api/tournaments/${tournId}/publish`, {
      method: 'POST',
      token: coachToken
    });
    assert(pubRes.ok, 'Coach published tournament (status: REGISTRATION_OPEN)');

    // Fetch tournament categories
    const getTourn = await request(`/api/tournaments/${tournId}`);
    const msCat = getTourn.data.categories.find(c => c.category_name === 'MENS_SINGLES');
    const mdCat = getTourn.data.categories.find(c => c.category_name === 'MENS_DOUBLES');
    const mixCat = getTourn.data.categories.find(c => c.category_name === 'MIXED_DOUBLES');
    assert(msCat && mdCat && mixCat, 'Categories correctly initialized (Singles & Doubles)');

    // 3. Member Registration & Duplicate Validations
    console.log('\n--- 3. Registration Validations (Singles & Doubles) ---');
    // Register Member 1 for Men's Singles
    const regM1 = await request(`/api/tournaments/${tournId}/register`, {
      method: 'POST',
      token: m1Token,
      body: { category_id: msCat.id }
    });
    assert(regM1.ok, 'Member 1 registered for Men Singles');

    // Duplicate singles registration attempt
    const regM1Dup = await request(`/api/tournaments/${tournId}/register`, {
      method: 'POST',
      token: m1Token,
      body: { category_id: msCat.id }
    });
    assert(regM1Dup.status === 409, 'Duplicate Singles registration correctly rejected with 409');

    // Register Member 2 for Men's Singles
    await request(`/api/tournaments/${tournId}/register`, {
      method: 'POST',
      token: m2Token,
      body: { category_id: msCat.id }
    });

    // Register Member 3 for Men's Singles
    await request(`/api/tournaments/${tournId}/register`, {
      method: 'POST',
      token: m3Token,
      body: { category_id: msCat.id }
    });

    // Register Member 4 for Men's Singles
    await request(`/api/tournaments/${tournId}/register`, {
      method: 'POST',
      token: m4Token,
      body: { category_id: msCat.id }
    });

    // Register Member 5 for Men's Singles (Making 5 players -> 7 or 5 player bracket tests Byes!)
    await request(`/api/tournaments/${tournId}/register`, {
      method: 'POST',
      token: m5Token,
      body: { category_id: msCat.id }
    });

    // Doubles Registration: Member 1 & Member 2
    const regD1 = await request(`/api/tournaments/${tournId}/register`, {
      method: 'POST',
      token: m1Token,
      body: { category_id: mdCat.id, partner_id: m2Id }
    });
    assert(regD1.ok, "Men's Doubles team (M1 + M2) registered successfully");

    // Duplicate doubles pair attempt in reverse order (M2 trying to register with M1)
    const regD1Rev = await request(`/api/tournaments/${tournId}/register`, {
      method: 'POST',
      token: m2Token,
      body: { category_id: mdCat.id, partner_id: m1Id }
    });
    assert(regD1Rev.status === 409, 'Duplicate normalized pair (M2 + M1) correctly rejected with 409');

    // Player cross-entry clash check: M1 trying to register with M3
    const regD1Clash = await request(`/api/tournaments/${tournId}/register`, {
      method: 'POST',
      token: m1Token,
      body: { category_id: mdCat.id, partner_id: m3Id }
    });
    assert(regD1Clash.status === 409, 'Same player used in two pairs in same doubles category correctly rejected');

    // Register 2nd Doubles Team: M3 & M4
    const regD2 = await request(`/api/tournaments/${tournId}/register`, {
      method: 'POST',
      token: m3Token,
      body: { category_id: mdCat.id, partner_id: m4Id }
    });
    assert(regD2.ok, "Second Men's Doubles team (M3 + M4) registered successfully");

    // 4. Fixture Generation & Scheduling
    console.log('\n--- 4. Fixture Generation, Byes & Conflict-Free Scheduling ---');
    const fixRes = await request(`/api/tournaments/${tournId}/generate-fixtures`, {
      method: 'POST',
      token: coachToken,
      body: {}
    });
    assert(fixRes.ok, `Fixtures generated successfully (${fixRes.data.totalCreated} matches created)`);

    // Verify Byes handling in 5-player singles bracket (bracket size 8 -> 3 byes)
    const fixList = await request(`/api/tournaments/${tournId}/fixtures?category_id=${msCat.id}`, {
      token: coachToken
    });
    const byes = fixList.data.filter(m => m.is_bye === 1);
    assert(byes.length > 0, `Knockout with non-power-of-2 participants correctly generated byes (Found ${byes.length} BYE matches)`);

    // Check round 2 auto-advancement of byes
    const r2Matches = fixList.data.filter(m => m.round_number === 2);
    const hasAdvancedTeam = r2Matches.some(m => m.team1_id || m.team2_id);
    assert(hasAdvancedTeam, 'Bye winners were automatically advanced to Round 2');

    // 5. Referee Confidentiality Enforcement (Rule 23 & 38)
    console.log('\n--- 5. Referee Confidentiality API Protection ---');
    // Public/Member requesting fixtures before match completion
    const memberFixtures = await request(`/api/tournaments/${tournId}/fixtures?category_id=${msCat.id}`, {
      token: m1Token
    });
    const exposedRef = memberFixtures.data.some(m => m.status === 'SCHEDULED' && m.referee_name);
    assert(!exposedRef, 'Assigned referee identity is strictly CONFIDENTIAL and hidden from members before match');

    // Coach requesting fixtures (authorized role)
    const coachFixtures = await request(`/api/tournaments/${tournId}/fixtures?category_id=${msCat.id}`, {
      token: coachToken
    });
    const coachSeesRef = coachFixtures.data.some(m => m.status === 'SCHEDULED' && m.referee_name);
    assert(coachSeesRef, 'Authorized Coach can see scheduled referee assignments for coordination');

    // 6. Match Result System & Result Locking
    console.log('\n--- 6. Referee Result Submission & Result Locking ---');
    // Find an active scheduled non-bye match with a referee
    const matchToPlay = coachFixtures.data.find(m => m.status === 'SCHEDULED' && !m.is_bye && m.team1_id && m.team2_id);
    assert(matchToPlay, `Found playable scheduled match #${matchToPlay?.match_number} (Team 1 vs Team 2)`);

    if (matchToPlay) {
      // Find which referee is assigned to this match
      const assignedRefId = matchToPlay.referee_id;
      // Get that referee's user account
      const [refAccount] = (await request('/api/referees', { token: coachToken })).data.filter(r => r.id === assignedRefId);

      // Attempt unauthorized submission by a member
      const unauthSub = await request(`/api/matches/${matchToPlay.id}/result`, {
        method: 'POST',
        token: m1Token,
        body: { team1_score: 21, team2_score: 18, winner_id: matchToPlay.team1_id }
      });
      assert(unauthSub.status === 403, 'Unauthorized result submission by member rejected with 403');

      // Submit result using Court Incharge or assigned referee
      const validSub = await request(`/api/matches/${matchToPlay.id}/result`, {
        method: 'POST',
        token: inchargeToken,
        body: {
          team1_score: 21,
          team2_score: 18,
          scores_detail: '21-18, 21-16',
          winner_id: matchToPlay.team1_id,
          man_of_match: 'Arun Kumar',
          duration_minutes: 38
        }
      });
      assert(validSub.ok, 'Match result submitted successfully');

      // RESULT LOCKING TEST (Rule 22)
      // Attempt to modify locked result
      const reSub = await request(`/api/matches/${matchToPlay.id}/result`, {
        method: 'POST',
        token: inchargeToken,
        body: { team1_score: 15, team2_score: 21, winner_id: matchToPlay.team2_id }
      });
      assert(reSub.status === 403, 'Attempt to modify locked result rejected with 403 Forbidden');
    }

    // 7. League Format Test (Format A)
    console.log('\n--- 7. League Format & Standings Test (Format A) ---');
    const leagueTourn = await request('/api/tournaments', {
      method: 'POST',
      token: coachToken,
      body: {
        name: 'SkyArc Academy League 2026',
        format: 'LEAGUE',
        start_date: '2026-11-01',
        end_date: '2026-11-05',
        venue: 'Court 1 & 2',
        timing: '10:00 AM – 04:00 PM',
        categories: ['MENS_SINGLES']
      }
    });
    const leagueId = leagueTourn.data.tournamentId;
    await request(`/api/tournaments/${leagueId}/publish`, { method: 'POST', token: coachToken });
    const leagueGet = await request(`/api/tournaments/${leagueId}`);
    const leagueCat = leagueGet.data.categories[0];

    // Register 3 participants
    await request(`/api/tournaments/${leagueId}/register`, { method: 'POST', token: m1Token, body: { category_id: leagueCat.id } });
    await request(`/api/tournaments/${leagueId}/register`, { method: 'POST', token: m2Token, body: { category_id: leagueCat.id } });
    await request(`/api/tournaments/${leagueId}/register`, { method: 'POST', token: m3Token, body: { category_id: leagueCat.id } });

    // Generate League fixtures
    const leagueFix = await request(`/api/tournaments/${leagueId}/generate-fixtures`, {
      method: 'POST',
      token: coachToken,
      body: {}
    });
    assert(leagueFix.ok, 'League round-robin fixtures generated');

    // Check standings table initialized
    const standingsRes = await request(`/api/tournaments/${leagueId}/standings?category_id=${leagueCat.id}`);
    assert(standingsRes.data.length === 3, 'League standings table correctly initialized for all 3 participants');

    // Play one league match and verify points update
    const leagueMatches = (await request(`/api/tournaments/${leagueId}/fixtures?category_id=${leagueCat.id}`, { token: coachToken })).data;
    const lMatch = leagueMatches[0];
    await request(`/api/matches/${lMatch.id}/result`, {
      method: 'POST',
      token: inchargeToken,
      body: { team1_score: 21, team2_score: 15, winner_id: lMatch.team1_id }
    });

    const updatedStandings = (await request(`/api/tournaments/${leagueId}/standings?category_id=${leagueCat.id}`)).data;
    const winnerStanding = updatedStandings.find(s => s.team_id === lMatch.team1_id);
    assert(winnerStanding && winnerStanding.points === 2 && winnerStanding.won === 1, 'League standings accurately updated (Won=1, Points=2, Point Diff=+6)');

    // 8. Participant Next Match View (Rule 24)
    console.log('\n--- 8. Participant "My Next Match" View ---');
    const nextMatchRes = await request('/api/registrations/my-next-match', { token: m2Token });
    assert(nextMatchRes.ok, 'Member successfully queried Next Match');
    if (nextMatchRes.data.nextMatch) {
      assert(nextMatchRes.data.nextMatch.opponent, `Found Next Match vs: "${nextMatchRes.data.nextMatch.opponent}"`);
      assert(!nextMatchRes.data.nextMatch.referee, 'Next Match view omits confidential referee info');
    }

    // 9. Two-Step End Tournament Confirmation (Rule 27)
    console.log('\n--- 9. End Tournament 2-Step Confirmation ---');
    const singleConfirm = await request(`/api/tournaments/${tournId}/end`, {
      method: 'POST',
      token: coachToken,
      body: { confirm: true } // missing second_confirm
    });
    assert(singleConfirm.status === 400, 'Single confirmation rejected (2-step required)');

    const doubleConfirm = await request(`/api/tournaments/${tournId}/end`, {
      method: 'POST',
      token: coachToken,
      body: { confirm: true, second_confirm: true }
    });
    assert(doubleConfirm.ok, 'Tournament finalized with 2-step confirmation');

    const endedTourn = await request(`/api/tournaments/${tournId}`);
    assert(endedTourn.data.status === 'COMPLETED', 'Tournament status changed to COMPLETED');

    console.log('\n========================================');
    console.log(`Test Results: ${passed} PASSED, ${failed} FAILED`);
    console.log('========================================\n');
  } catch (err) {
    console.error('Test execution error:', err);
  } finally {
    process.exit(failed > 0 ? 1 : 0);
  }
}

runTests();
