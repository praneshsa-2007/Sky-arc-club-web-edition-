'use strict';

const { pool } = require('./db');

async function run() {
  console.log('🧪 Testing Delete Tournament and Incharge Referee addition...');

  // 1. Log in Coach
  const coachLoginRes = await fetch('http://localhost:3000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'Venkatesh', password: '2015672754' })
  });
  const coachData = await coachLoginRes.json();
  const coachToken = coachData.token;
  console.log('  ✅ Coach logged in');

  // 2. Log in Incharge
  const inchargeLoginRes = await fetch('http://localhost:3000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'pranesh_sa', password: '2015672754' })
  });
  const inchargeData = await inchargeLoginRes.json();
  const inchargeToken = inchargeData.token;
  console.log('  ✅ Court Incharge logged in');

  // 3. Test Incharge adding a referee from Add Member/Coach/Referee slot
  const testRefUsername = `ref_test_${Date.now()}`;
  const addRefRes = await fetch('http://localhost:3000/api/referees', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${inchargeToken}`
    },
    body: JSON.stringify({
      name: 'Test Umpire Kumar',
      username: testRefUsername,
      email: `${testRefUsername}@skyarc.local`,
      password: 'password123',
      phone: '9876543299',
      qualification: 'BWF Certified International Umpire',
      experience: '8 years officiating'
    })
  });
  const addRefData = await addRefRes.json();
  if (addRefRes.status !== 201) throw new Error(`Add referee failed: ${JSON.stringify(addRefData)}`);
  console.log(`  ✅ Referee added successfully: ID ${addRefData.refereeId}`);

  // Verify referee user can log in
  const refLoginRes = await fetch('http://localhost:3000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: testRefUsername, password: 'password123' })
  });
  const refLoginData = await refLoginRes.json();
  if (!refLoginData.token || refLoginData.user.role !== 'REFEREE') {
    throw new Error('Newly created referee failed to authenticate');
  }
  console.log('  ✅ Newly created referee login authenticated successfully');

  // 4. Coach creates a tournament to delete
  const createTournRes = await fetch('http://localhost:3000/api/tournaments', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${coachToken}`
    },
    body: JSON.stringify({
      name: 'Tournament To Be Deleted 2026',
      description: 'Temporary tournament for deletion test',
      format: 'KNOCKOUT',
      venue: 'SkyArc Court 1',
      start_date: '2026-11-01',
      end_date: '2026-11-02',
      timing: '09:00 AM - 05:00 PM',
      food_provided: true,
      categories: ['MENS_SINGLES', 'MENS_DOUBLES']
    })
  });
  const tournData = await createTournRes.json();
  const tournId = tournData.tournamentId;
  console.log(`  ✅ Coach created test tournament: ID ${tournId}`);

  // 5. Test Member cannot delete tournament
  const memberLoginRes = await fetch('http://localhost:3000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'arun_k', password: '2015672754' })
  });
  const memberData = await memberLoginRes.json();
  const unauthorizedDelRes = await fetch(`http://localhost:3000/api/tournaments/${tournId}`, {
    method: 'DELETE',
    headers: { 'Authorization': `Bearer ${memberData.token}` }
  });
  if (unauthorizedDelRes.status !== 403) {
    throw new Error(`Expected 403 Forbidden for member deletion, got ${unauthorizedDelRes.status}`);
  }
  console.log('  ✅ Unauthorized deletion by member correctly rejected with 403 Forbidden');

  // 6. Test Coach successfully deletes tournament
  const delRes = await fetch(`http://localhost:3000/api/tournaments/${tournId}`, {
    method: 'DELETE',
    headers: { 'Authorization': `Bearer ${coachToken}` }
  });
  const delData = await delRes.json();
  if (delRes.status !== 200) throw new Error(`Coach delete tournament failed: ${JSON.stringify(delData)}`);
  console.log(`  ✅ Coach deleted tournament: ${delData.message}`);

  // Verify tournament is gone
  const [rows] = await pool.query('SELECT id FROM tournaments WHERE id = ?', [tournId]);
  if (rows.length !== 0) throw new Error('Tournament still exists in database!');
  console.log('  ✅ Verified tournament and cascades removed from database');

  console.log('\n🎉 ALL TESTS PASSED!');
  process.exit(0);
}

run().catch(err => {
  console.error('❌ Test failed:', err);
  process.exit(1);
});
