'use strict';

require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const path       = require('path');
const { testConnection } = require('./db');

// ── Routes ──────────────────────────────────────────────────
const authRoutes     = require('./routes/auth');
const userRoutes     = require('./routes/users');
const courtRoutes    = require('./routes/courts');
const slotRoutes     = require('./routes/slots');
const bookingRoutes  = require('./routes/bookings');
const timetableRoutes = require('./routes/timetable');
const settingsRoutes = require('./routes/settings');
const guestRoutes    = require('./routes/guests');
const statsRoutes    = require('./routes/stats');
const tournamentRoutes = require('./routes/tournaments');
const refereeRoutes    = require('./routes/referees');
const registrationRoutes = require('./routes/registrations');
const matchRoutes      = require('./routes/matches');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ───────────────────────────────────────────────
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Serve static frontend files
app.use(express.static(path.join(__dirname, '..', 'public')));

// ── API Routes ───────────────────────────────────────────────
app.use('/api/auth',          authRoutes);
app.use('/api/users',         userRoutes);
app.use('/api/courts',        courtRoutes);
app.use('/api/slots',         slotRoutes);
app.use('/api/bookings',      bookingRoutes);
app.use('/api/timetable',     timetableRoutes);
app.use('/api/settings',      settingsRoutes);
app.use('/api/guests',        guestRoutes);
app.use('/api/stats',         statsRoutes);
app.use('/api/tournaments',   tournamentRoutes);
app.use('/api/referees',      refereeRoutes);
app.use('/api/registrations', registrationRoutes);
app.use('/api/matches',       matchRoutes);

// ── Fallback: serve index.html for any non-API route ────────
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
  } else {
    res.status(404).json({ message: 'API endpoint not found' });
  }
});

// ── Global error handler ─────────────────────────────────────
app.use((err, req, res, _next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ message: 'Internal server error' });
});

// ── Start ────────────────────────────────────────────────────
async function start() {
  await testConnection();
  app.listen(PORT, () => {
    console.log(`🚀  SkyArc server running at http://localhost:${PORT}`);
    console.log(`📋  Login at http://localhost:${PORT}`);
  });
}

start();
