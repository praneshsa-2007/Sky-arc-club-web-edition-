'use strict';

const fs = require('fs');
const path = require('path');
const { pool } = require('../db');
const {
  generateKnockoutFixtures,
  generateLeagueFixtures,
  generateNestedLeagueFixtures,
  generateKnockoutToLeagueFixtures,
  generatePoolKnockoutFixtures
} = require('../services/tournamentService');

const CATEGORY_MAP = {
  MENS_SINGLES:   { displayName: "Men's Singles",   type: 'SINGLES' },
  WOMENS_SINGLES: { displayName: "Women's Singles", type: 'SINGLES' },
  MENS_DOUBLES:   { displayName: "Men's Doubles",   type: 'DOUBLES' },
  WOMENS_DOUBLES: { displayName: "Women's Doubles", type: 'DOUBLES' },
  MIXED_DOUBLES:  { displayName: "Mixed Doubles",  type: 'DOUBLES' },
};

/**
 * List tournaments with filtering
 */
async function listTournaments(req, res) {
  try {
    const { status, category, format, search } = req.query;
    let sql = `
      SELECT t.*, u.name as coach_name,
             w.team_name as winner_name,
             ru.team_name as runner_up_name,
             (SELECT COUNT(*) FROM tournament_registrations tr WHERE tr.tournament_id = t.id) as participant_count,
             (SELECT COUNT(*) FROM tournament_matches tm WHERE tm.tournament_id = t.id) as match_count,
             (SELECT COUNT(*) FROM tournament_matches tmc WHERE tmc.tournament_id = t.id AND tmc.status = 'COMPLETED') as completed_match_count
      FROM tournaments t
      LEFT JOIN users u ON t.created_by = u.id
      LEFT JOIN tournament_registrations w ON t.winner_id = w.id
      LEFT JOIN tournament_registrations ru ON t.runner_up_id = ru.id
      WHERE 1=1
    `;
    const params = [];

    if (status) {
      if (status === 'UPCOMING') {
        sql += " AND t.status IN ('REGISTRATION_OPEN', 'REGISTRATION_CLOSED', 'UPCOMING')";
      } else if (status === 'ONGOING') {
        sql += " AND t.status = 'ONGOING'";
      } else if (status === 'COMPLETED') {
        sql += " AND t.status = 'COMPLETED'";
      } else {
        sql += " AND t.status = ?";
        params.push(status);
      }
    }

    if (format) {
      sql += " AND t.format = ?";
      params.push(format);
    }

    if (search) {
      sql += " AND (t.name LIKE ? OR t.venue LIKE ?)";
      params.push(`%${search}%`, `%${search}%`);
    }

    sql += " ORDER BY t.start_date DESC, t.id DESC";
    const [tournaments] = await pool.query(sql, params);

    // Fetch categories for each tournament
    if (tournaments.length > 0) {
      const tIds = tournaments.map(t => t.id);
      const [cats] = await pool.query(`
        SELECT tc.*, w.team_name as winner_name, ru.team_name as runner_up_name
        FROM tournament_categories tc
        LEFT JOIN tournament_registrations w ON tc.winner_team_id = w.id
        LEFT JOIN tournament_registrations ru ON tc.runner_up_team_id = ru.id
        WHERE tc.tournament_id IN (${tIds.join(',')})
      `);

      tournaments.forEach(t => {
        t.categories = cats.filter(c => c.tournament_id === t.id);
      });

      // Filter by category if requested
      if (category) {
        const filtered = tournaments.filter(t => t.categories.some(c => c.category_name === category));
        return res.json(filtered);
      }
    }

    return res.json(tournaments);
  } catch (err) {
    console.error('listTournaments error:', err);
    return res.status(500).json({ message: 'Server error listing tournaments.' });
  }
}

/**
 * Get tournament by ID
 */
async function getTournament(req, res) {
  try {
    const { id } = req.params;
    const [rows] = await pool.query(`
      SELECT t.*, u.name as coach_name,
             w.team_name as winner_name,
             ru.team_name as runner_up_name
      FROM tournaments t
      LEFT JOIN users u ON t.created_by = u.id
      LEFT JOIN tournament_registrations w ON t.winner_id = w.id
      LEFT JOIN tournament_registrations ru ON t.runner_up_id = ru.id
      WHERE t.id = ?
    `, [id]);

    if (rows.length === 0) return res.status(404).json({ message: 'Tournament not found.' });
    const tournament = rows[0];

    const [categories] = await pool.query(`
      SELECT tc.*, w.team_name as winner_name, ru.team_name as runner_up_name,
             (SELECT COUNT(*) FROM tournament_registrations tr WHERE tr.category_id = tc.id) as reg_count
      FROM tournament_categories tc
      LEFT JOIN tournament_registrations w ON tc.winner_team_id = w.id
      LEFT JOIN tournament_registrations ru ON tc.runner_up_team_id = ru.id
      WHERE tc.tournament_id = ?
    `, [id]);
    tournament.categories = categories;

    const [stages] = await pool.query(`
      SELECT * FROM tournament_stages WHERE tournament_id = ? ORDER BY sequence_order ASC
    `, [id]);
    tournament.stages = stages;

    return res.json(tournament);
  } catch (err) {
    console.error('getTournament error:', err);
    return res.status(500).json({ message: 'Server error getting tournament.' });
  }
}

/**
 * Create a new tournament (Coach only)
 */
async function createTournament(req, res) {
  const conn = await pool.getConnection();
  try {
    await conn.query('START TRANSACTION');
    const {
      name, description, format, start_date, end_date, venue, timing,
      food_provided, poster_url, categories, format_config, registration_deadline
    } = req.body;

    if (!name || !format || !start_date || !end_date || !venue || !timing) {
      return res.status(400).json({ message: 'Missing required tournament fields.' });
    }

    if (!categories || !Array.isArray(categories) || categories.length === 0) {
      return res.status(400).json({ message: 'Please select at least one tournament category.' });
    }

    const validFormats = ['LEAGUE', 'KNOCKOUT', 'NESTED_LEAGUE', 'KNOCKOUT_TO_LEAGUE', 'POOL_KNOCKOUT'];
    if (!validFormats.includes(format)) {
      return res.status(400).json({ message: 'Invalid tournament format.' });
    }

    const [tRes] = await conn.query(`
      INSERT INTO tournaments (
        name, description, format, start_date, end_date, venue, timing,
        food_provided, poster_url, status, registration_deadline, format_config, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'DRAFT', ?, ?, ?)
    `, [
      name, description || null, format, start_date, end_date, venue, timing,
      food_provided ? 1 : 0, poster_url || null, registration_deadline || null,
      format_config ? JSON.stringify(format_config) : null, req.user.id
    ]);

    const tournamentId = tRes.insertId;

    // Insert categories
    for (const catKey of categories) {
      const catInfo = CATEGORY_MAP[catKey];
      if (catInfo) {
        await conn.query(`
          INSERT INTO tournament_categories (tournament_id, category_name, display_name, type)
          VALUES (?, ?, ?, ?)
        `, [tournamentId, catKey, catInfo.displayName, catInfo.type]);
      }
    }

    // Audit log
    await conn.query(`
      INSERT INTO audit_logs (user_id, action, entity, entity_id, details)
      VALUES (?, 'CREATE_TOURNAMENT', 'tournaments', ?, ?)
    `, [req.user.id, tournamentId, JSON.stringify({ name, format, categories })]);

    await conn.query('COMMIT');
    return res.status(201).json({ message: 'Tournament created successfully in Draft status.', tournamentId });
  } catch (err) {
    await conn.query('ROLLBACK');
    console.error('createTournament error:', err);
    return res.status(500).json({ message: 'Server error creating tournament.' });
  } finally {
    conn.release();
  }
}

/**
 * Publish tournament as an Event (sets status to REGISTRATION_OPEN)
 */
async function publishTournament(req, res) {
  const conn = await pool.getConnection();
  try {
    const { id } = req.params;
    const [tRows] = await conn.query('SELECT * FROM tournaments WHERE id = ?', [id]);
    if (tRows.length === 0) return res.status(404).json({ message: 'Tournament not found.' });

    await conn.query(`
      UPDATE tournaments SET status = 'REGISTRATION_OPEN' WHERE id = ?
    `, [id]);

    await conn.query(`
      INSERT INTO audit_logs (user_id, action, entity, entity_id, details)
      VALUES (?, 'PUBLISH_TOURNAMENT', 'tournaments', ?, ?)
    `, [req.user.id, id, JSON.stringify({ previousStatus: tRows[0].status, newStatus: 'REGISTRATION_OPEN' })]);

    return res.json({ message: 'Tournament published successfully! Registration is now open.' });
  } catch (err) {
    console.error('publishTournament error:', err);
    return res.status(500).json({ message: 'Server error publishing tournament.' });
  } finally {
    conn.release();
  }
}

/**
 * Close registration or change status
 */
async function setTournamentStatus(req, res) {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const validStatuses = ['DRAFT', 'REGISTRATION_OPEN', 'REGISTRATION_CLOSED', 'UPCOMING', 'ONGOING', 'COMPLETED', 'CANCELLED'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ message: 'Invalid status.' });
    }

    await pool.query('UPDATE tournaments SET status = ? WHERE id = ?', [status, id]);
    await pool.query(`
      INSERT INTO audit_logs (user_id, action, entity, entity_id, details)
      VALUES (?, 'CHANGE_STATUS', 'tournaments', ?, ?)
    `, [req.user.id, id, JSON.stringify({ newStatus: status })]);

    return res.json({ message: `Tournament status updated to ${status}.` });
  } catch (err) {
    console.error('setTournamentStatus error:', err);
    return res.status(500).json({ message: 'Server error updating status.' });
  }
}

/**
 * Upload optional poster image (Base64)
 */
async function uploadPoster(req, res) {
  try {
    const { imageBase64, filename } = req.body;
    if (!imageBase64) return res.status(400).json({ message: 'imageBase64 is required.' });

    const matches = imageBase64.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    if (!matches || matches.length !== 3) {
      return res.status(400).json({ message: 'Invalid base64 image data.' });
    }

    const ext = matches[1].includes('jpeg') || matches[1].includes('jpg') ? 'jpg' : 'png';
    const buffer = Buffer.from(matches[2], 'base64');

    const uploadsDir = path.join(__dirname, '..', '..', 'public', 'uploads', 'posters');
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir, { recursive: true });
    }

    const fname = `poster_${Date.now()}_${Math.floor(Math.random()*1000)}.${ext}`;
    const filePath = path.join(uploadsDir, fname);
    fs.writeFileSync(filePath, buffer);

    const posterUrl = `/uploads/posters/${fname}`;
    return res.json({ posterUrl });
  } catch (err) {
    console.error('uploadPoster error:', err);
    return res.status(500).json({ message: 'Server error uploading poster.' });
  }
}

/**
 * End tournament with 2-step confirmation (Rule 27)
 */
async function endTournament(req, res) {
  const conn = await pool.getConnection();
  try {
    await conn.query('START TRANSACTION');
    const { id } = req.params;
    const { confirm, second_confirm } = req.body;

    if (!confirm || !second_confirm) {
      return res.status(400).json({
        message: 'Two-step confirmation required to end tournament. Both confirm and second_confirm must be true.'
      });
    }

    const [tRows] = await conn.query('SELECT * FROM tournaments WHERE id = ?', [id]);
    if (tRows.length === 0) return res.status(404).json({ message: 'Tournament not found.' });

    // Determine tournament winner & runner up from completed matches
    const [finalMatches] = await conn.query(`
      SELECT m.winner_id, m.loser_id FROM tournament_matches m
      WHERE m.tournament_id = ? AND m.status = 'COMPLETED'
      ORDER BY m.round_number DESC, m.match_number DESC LIMIT 1
    `, [id]);

    const winnerId = finalMatches[0]?.winner_id || tRows[0].winner_id;
    const runnerUpId = finalMatches[0]?.loser_id || tRows[0].runner_up_id;

    await conn.query(`
      UPDATE tournaments
      SET status = 'COMPLETED', winner_id = ?, runner_up_id = ?
      WHERE id = ?
    `, [winnerId, runnerUpId, id]);

    // Mark stages completed
    await conn.query(`
      UPDATE tournament_stages SET status = 'COMPLETED' WHERE tournament_id = ?
    `, [id]);

    // Audit log
    await conn.query(`
      INSERT INTO audit_logs (user_id, action, entity, entity_id, details)
      VALUES (?, 'END_TOURNAMENT', 'tournaments', ?, ?)
    `, [req.user.id, id, JSON.stringify({ winnerId, runnerUpId, finalizedBy: req.user.username })]);

    await conn.query('COMMIT');
    return res.json({ message: 'Tournament finalized and marked COMPLETED. All results are now permanently read-only.' });
  } catch (err) {
    await conn.query('ROLLBACK');
    console.error('endTournament error:', err);
    return res.status(500).json({ message: 'Server error ending tournament.' });
  } finally {
    conn.release();
  }
}

/**
 * Generate random conflict-free fixtures for tournament
 */
async function generateFixtures(req, res) {
  const conn = await pool.getConnection();
  try {
    await conn.query('START TRANSACTION');
    const { id } = req.params;
    const { category_id } = req.body;

    const [tRows] = await conn.query('SELECT * FROM tournaments WHERE id = ?', [id]);
    if (tRows.length === 0) return res.status(404).json({ message: 'Tournament not found.' });
    const tournament = tRows[0];

    // Get courts & referees
    const [courts] = await conn.query('SELECT * FROM courts WHERE active = 1');
    if (courts.length === 0) {
      return res.status(400).json({ message: 'No active courts found. Please add or activate courts first.' });
    }

    const [referees] = await conn.query('SELECT * FROM referees WHERE status = "ACTIVE"');
    if (referees.length === 0) {
      return res.status(400).json({ message: 'No active referees found. Court In-Charge must register at least one referee.' });
    }

    // Get categories to generate
    let catSql = 'SELECT * FROM tournament_categories WHERE tournament_id = ?';
    const catParams = [id];
    if (category_id) {
      catSql += ' AND id = ?';
      catParams.push(category_id);
    }
    const [categories] = await conn.query(catSql, catParams);

    if (categories.length === 0) {
      return res.status(400).json({ message: 'No matching tournament categories found.' });
    }

    let totalCreated = 0;

    for (const cat of categories) {
      // Check if fixtures already generated for this category
      const [existingMatches] = await conn.query(`
        SELECT COUNT(*) as cnt FROM tournament_matches WHERE category_id = ?
      `, [cat.id]);

      if (existingMatches[0].cnt > 0) {
        continue; // Already generated for this category
      }

      // Fetch confirmed registrations
      const [teams] = await conn.query(`
        SELECT * FROM tournament_registrations
        WHERE category_id = ? AND registration_status = 'CONFIRMED'
      `, [cat.id]);

      if (teams.length < 2) {
        if (category_id) {
          throw new Error(`Category "${cat.display_name}" requires at least 2 participants/teams. Currently has ${teams.length}.`);
        }
        continue; // Skip categories without enough participants when generating for whole tournament
      }

      // Generate fixtures based on tournament format
      let result;
      switch (tournament.format) {
        case 'LEAGUE':
          result = await generateLeagueFixtures(tournament, cat, teams, courts, referees, conn);
          break;
        case 'KNOCKOUT':
          result = await generateKnockoutFixtures(tournament, cat, teams, courts, referees, conn);
          break;
        case 'NESTED_LEAGUE':
          result = await generateNestedLeagueFixtures(tournament, cat, teams, courts, referees, conn);
          break;
        case 'KNOCKOUT_TO_LEAGUE':
          result = await generateKnockoutToLeagueFixtures(tournament, cat, teams, courts, referees, conn);
          break;
        case 'POOL_KNOCKOUT':
          result = await generatePoolKnockoutFixtures(tournament, cat, teams, courts, referees, conn);
          break;
        default:
          result = await generateKnockoutFixtures(tournament, cat, teams, courts, referees, conn);
      }

      totalCreated += result.totalMatches;
    }

    if (totalCreated === 0) {
      throw new Error('No categories have at least 2 registered participants to generate fixtures.');
    }

    // Change status to UPCOMING or ONGOING
    if (tournament.status === 'DRAFT' || tournament.status === 'REGISTRATION_OPEN' || tournament.status === 'REGISTRATION_CLOSED') {
      await conn.query("UPDATE tournaments SET status = 'ONGOING' WHERE id = ?", [id]);
    }

    // Audit log
    await conn.query(`
      INSERT INTO audit_logs (user_id, action, entity, entity_id, details)
      VALUES (?, 'GENERATE_FIXTURES', 'tournaments', ?, ?)
    `, [req.user.id, id, JSON.stringify({ totalMatchesCreated: totalCreated, format: tournament.format })]);

    await conn.query('COMMIT');
    return res.json({ message: `Fixtures generated successfully (${totalCreated} matches scheduled).`, totalCreated });
  } catch (err) {
    await conn.query('ROLLBACK');
    console.error('generateFixtures error:', err);
    return res.status(400).json({ message: err.message || 'Error generating fixtures.' });
  } finally {
    conn.release();
  }
}

/**
 * Get tournament fixtures with confidentiality enforcement (Rule 23 & 38)
 */
async function getFixtures(req, res) {
  try {
    const { id } = req.params;
    const { category_id } = req.query;

    let sql = `
      SELECT m.*,
             c.display_name as category_display, c.type as category_type,
             crt.court_number, crt.court_name,
             r.name as referee_name, r.qualification as referee_qualification,
             t1.team_name as team1_name,
             t2.team_name as team2_name,
             w.team_name as winner_name,
             mr.team1_score, mr.team2_score, mr.scores_detail, mr.is_locked, mr.man_of_match as result_mom,
             mr.remarks, mr.duration_minutes
      FROM tournament_matches m
      JOIN tournament_categories c ON m.category_id = c.id
      LEFT JOIN courts crt ON m.court_id = crt.id
      LEFT JOIN referees r ON m.referee_id = r.id
      LEFT JOIN tournament_registrations t1 ON m.team1_id = t1.id
      LEFT JOIN tournament_registrations t2 ON m.team2_id = t2.id
      LEFT JOIN tournament_registrations w ON m.winner_id = w.id
      LEFT JOIN match_results mr ON m.id = mr.match_id
      WHERE m.tournament_id = ?
    `;
    const params = [id];

    if (category_id) {
      sql += ' AND m.category_id = ?';
      params.push(category_id);
    }

    sql += ' ORDER BY m.round_number ASC, m.match_number ASC, m.id ASC';
    const [matches] = await pool.query(sql, params);

    // CONFIDENTIALITY CHECK (Rule 23 & 38)
    // Only authorized roles (COACH, COURT_INCHARGE) or the assigned referee for that match
    // may see referee info BEFORE match is completed.
    let userRole = req.user?.role;
    let userId = req.user?.id;

    if (!userRole) {
      const authHeader = req.headers['authorization'] || '';
      if (authHeader.startsWith('Bearer ')) {
        try {
          const jwt = require('jsonwebtoken');
          const payload = jwt.verify(authHeader.slice(7), process.env.JWT_SECRET || 'dev-secret');
          userRole = payload.role;
          userId = payload.id;
        } catch {}
      }
    }

    let userRefereeId = null;
    if (userRole === 'REFEREE' && userId) {
      const [refRow] = await pool.query('SELECT id FROM referees WHERE user_id = ?', [userId]);
      userRefereeId = refRow[0]?.id || null;
    }

    matches.forEach(m => {
      const isAuthorizedRole = (userRole === 'COACH' || userRole === 'COURT_INCHARGE');
      const isAssignedRef = (userRole === 'REFEREE' && userRefereeId && m.referee_id === userRefereeId);
      const isMatchCompleted = (m.status === 'COMPLETED');

      // If not authorized and match is not completed, redact referee info!
      if (!isAuthorizedRole && !isAssignedRef && !isMatchCompleted) {
        m.referee_id = null;
        m.referee_name = null;
        m.referee_qualification = null;
      }
    });

    return res.json(matches);
  } catch (err) {
    console.error('getFixtures error:', err);
    return res.status(500).json({ message: 'Server error retrieving fixtures.' });
  }
}

/**
 * Get tournament standings
 */
async function getStandings(req, res) {
  try {
    const { id } = req.params;
    const { category_id } = req.query;

    let sql = `
      SELECT s.*, tr.team_name, tc.display_name as category_display, st.stage_name
      FROM tournament_standings s
      JOIN tournament_registrations tr ON s.team_id = tr.id
      JOIN tournament_categories tc ON s.category_id = tc.id
      LEFT JOIN tournament_stages st ON s.stage_id = st.id
      WHERE s.tournament_id = ?
    `;
    const params = [id];

    if (category_id) {
      sql += ' AND s.category_id = ?';
      params.push(category_id);
    }

    sql += ' ORDER BY s.stage_id ASC, s.group_name ASC, s.rank_position ASC, s.points DESC, s.point_diff DESC';
    const [standings] = await pool.query(sql, params);
    return res.json(standings);
  } catch (err) {
    console.error('getStandings error:', err);
    return res.status(500).json({ message: 'Server error retrieving standings.' });
  }
}

/**
 * Get registered participants for a tournament
 */
async function getParticipants(req, res) {
  try {
    const { id } = req.params;
    const { category_id } = req.query;

    let sql = `
      SELECT tr.*, tc.display_name as category_display, tc.type as category_type,
             u1.name as member_name, u1.username as member_username, u1.email as member_email,
             u2.name as partner_name, u2.username as partner_username, u2.email as partner_email
      FROM tournament_registrations tr
      JOIN tournament_categories tc ON tr.category_id = tc.id
      JOIN users u1 ON tr.member_id = u1.id
      LEFT JOIN users u2 ON tr.partner_id = u2.id
      WHERE tr.tournament_id = ?
    `;
    const params = [id];

    if (category_id) {
      sql += ' AND tr.category_id = ?';
      params.push(category_id);
    }

    sql += ' ORDER BY tr.category_id ASC, tr.id ASC';
    const [participants] = await pool.query(sql, params);
    return res.json(participants);
  } catch (err) {
    console.error('getParticipants error:', err);
    return res.status(500).json({ message: 'Server error retrieving participants.' });
  }
}

/**
 * Delete tournament (Coach only)
 */
async function deleteTournament(req, res) {
  const conn = await pool.getConnection();
  try {
    await conn.query('START TRANSACTION');
    const { id } = req.params;

    const [existing] = await conn.query('SELECT id, name FROM tournaments WHERE id = ?', [id]);
    if (!existing.length) {
      await conn.query('ROLLBACK');
      return res.status(404).json({ message: 'Tournament not found.' });
    }

    const tName = existing[0].name;

    await conn.query('DELETE FROM tournament_matches WHERE tournament_id = ?', [id]);
    await conn.query('DELETE FROM tournament_standings WHERE tournament_id = ?', [id]);
    await conn.query('DELETE FROM tournament_stages WHERE tournament_id = ?', [id]);
    await conn.query('DELETE FROM tournament_registrations WHERE tournament_id = ?', [id]);
    await conn.query('DELETE FROM tournament_categories WHERE tournament_id = ?', [id]);
    await conn.query('DELETE FROM tournaments WHERE id = ?', [id]);

    await conn.query(`
      INSERT INTO audit_logs (user_id, action, entity, entity_id, details)
      VALUES (?, 'DELETE_TOURNAMENT', 'tournaments', ?, ?)
    `, [req.user.id, id, JSON.stringify({ name: tName })]);

    await conn.query('COMMIT');
    return res.json({ message: `Tournament "${tName}" and all associated data deleted successfully.` });
  } catch (err) {
    await conn.query('ROLLBACK');
    console.error('deleteTournament error:', err);
    return res.status(500).json({ message: 'Server error deleting tournament.' });
  } finally {
    conn.release();
  }
}

module.exports = {
  listTournaments,
  getTournament,
  createTournament,
  publishTournament,
  setTournamentStatus,
  uploadPoster,
  endTournament,
  generateFixtures,
  getFixtures,
  getStandings,
  getParticipants,
  deleteTournament
};

