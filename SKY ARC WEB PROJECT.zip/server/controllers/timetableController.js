'use strict';
const { pool } = require('../db');

async function getTimetable(req, res) {
  try {
    const date  = req.query.date  || new Date().toISOString().slice(0,10);
    const batch = req.query.batch || null;
    let sql = `
      SELECT s.id as slot_id, s.court_id, s.batch, s.slot_date,
             s.start_time, s.end_time, s.status, s.max_capacity, s.notes,
             c.court_number, c.court_type,
             COUNT(CASE WHEN b.status='CONFIRMED' THEN 1 END) as booked_count
      FROM slots s
      JOIN courts c ON s.court_id=c.id AND c.active=1
      LEFT JOIN bookings b ON b.slot_id=s.id
      WHERE s.slot_date=?`;
    const params = [date];
    if (batch) { sql += ' AND s.batch=?'; params.push(batch); }
    sql += ' GROUP BY s.id ORDER BY s.start_time, c.court_number';
    const [rows] = await pool.execute(sql, params);
    // Enrich each slot with display status
    const enriched = rows.map(r => {
      const count = r.booked_count;
      const max   = r.max_capacity;
      const min   = 4;
      let displayStatus;
      if (r.status === 'COACH_RESERVED')    displayStatus = 'COACH RESERVED';
      else if (r.status === 'INCHARGE_RESERVED') displayStatus = 'RESERVED';
      else if (r.status === 'UNAVAILABLE')  displayStatus = 'UNAVAILABLE';
      else if (r.status === 'CLOSED')       displayStatus = 'CLOSED';
      else if (count >= max)                displayStatus = `FULL ${count}/${max}`;
      else if (count >= min)                displayStatus = `READY ${count}/${max}`;
      else if (count > 0)                   displayStatus = `OPEN ${count}/${max}`;
      else                                  displayStatus = `AVAILABLE 0/${max}`;
      return { ...r, displayStatus, available: max - count };
    });
    return res.json(enriched);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

module.exports = { getTimetable };
