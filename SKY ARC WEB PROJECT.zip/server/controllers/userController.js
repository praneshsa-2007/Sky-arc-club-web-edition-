'use strict';

const bcrypt   = require('bcrypt');
const { pool } = require('../db');

const SALT_ROUNDS = 12;

async function listUsers(req, res) {
  try {
    const role   = req.query.role   || null;
    const active = req.query.active !== undefined ? req.query.active : null;
    let sql    = 'SELECT id, name, username, email, role, age, phone, date_of_joining, active, created_at FROM users';
    const params = [];
    const where  = [];
    if (role)   { where.push('role = ?');   params.push(role); }
    if (active !== null) { where.push('active = ?'); params.push(Number(active)); }
    if (where.length) sql += ' WHERE ' + where.join(' AND ');
    sql += ' ORDER BY created_at DESC';
    const [rows] = await pool.execute(sql, params);
    return res.json(rows);
  } catch (err) {
    console.error('listUsers error:', err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

async function getUser(req, res) {
  try {
    const [rows] = await pool.execute(
      'SELECT id, name, username, email, role, age, phone, date_of_joining, active, created_at FROM users WHERE id = ?',
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ message: 'User not found.' });
    return res.json(rows[0]);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

async function createUser(req, res) {
  try {
    const { name, username, email, password, age, role, phone, date_of_joining } = req.body;
    // Validation
    if (!name || !username || !email || !password || !role) {
      return res.status(400).json({ message: 'name, username, email, password and role are required.' });
    }
    if (!['MEMBER','COACH','COURT_INCHARGE','REFEREE'].includes(role)) {
      return res.status(400).json({ message: 'Invalid role.' });
    }
    if (password.length < 6) {
      return res.status(400).json({ message: 'Password must be at least 6 characters.' });
    }
    const emailRx = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRx.test(email)) {
      return res.status(400).json({ message: 'Invalid email address.' });
    }

    // Check uniqueness
    const [dup] = await pool.execute(
      'SELECT id FROM users WHERE username = ? LIMIT 1',
      [username]
    );
    if (dup.length) return res.status(409).json({ message: 'Username already exists.' });

    const hash = await bcrypt.hash(password, SALT_ROUNDS);
    const [result] = await pool.execute(
      `INSERT INTO users (name, username, email, password_hash, age, role, phone, date_of_joining)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [name, username, email, hash, age || null, role, phone || null, date_of_joining || null]
    );
    return res.status(201).json({ message: 'User created successfully.', userId: result.insertId });
  } catch (err) {
    console.error('createUser error:', err);
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ message: 'Username already exists.' });
    }
    return res.status(500).json({ message: 'Server error.' });
  }
}

async function setUserStatus(req, res) {
  try {
    const { active } = req.body;
    const targetId   = parseInt(req.params.id);
    // Coach can only deactivate members
    if (req.user.role === 'COACH') {
      const [rows] = await pool.execute('SELECT role FROM users WHERE id = ?', [targetId]);
      if (!rows.length) return res.status(404).json({ message: 'User not found.' });
      if (rows[0].role !== 'MEMBER') {
        return res.status(403).json({ message: 'Coaches can only deactivate members.' });
      }
    }
    await pool.execute('UPDATE users SET active = ? WHERE id = ?', [active ? 1 : 0, targetId]);
    return res.json({ message: `User ${active ? 'activated' : 'deactivated'} successfully.` });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

async function updateUser(req, res) {
  try {
    const { name, email, age, phone, date_of_joining } = req.body;
    const [result] = await pool.execute(
      'UPDATE users SET name=?, email=?, age=?, phone=?, date_of_joining=? WHERE id=?',
      [name, email, age||null, phone||null, date_of_joining||null, req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ message: 'User not found.' });
    return res.json({ message: 'User updated.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

module.exports = { listUsers, getUser, createUser, setUserStatus, updateUser };
