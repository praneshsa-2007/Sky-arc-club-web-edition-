'use strict';
const { pool } = require('../db');

async function listSlots(req, res) {
  try {
    const { date, court_id, batch } = req.query;
    let sql = `SELECT s.*, c.court_number, c.court_type,
      (SELECT COUNT(*) FROM bookings b WHERE b.slot_id=s.id AND b.status='CONFIRMED') as booked_count
      FROM slots s JOIN courts c ON s.court_id=c.id WHERE c.active=1`;
    const params = [];
    if (date)     { sql += ' AND s.slot_date=?';  params.push(date); }
    if (court_id) { sql += ' AND s.court_id=?';  params.push(court_id); }
    if (batch)    { sql += ' AND s.batch=?';      params.push(batch); }
    sql += ' ORDER BY s.slot_date, s.start_time';
    const [rows] = await pool.execute(sql, params);
    return res.json(rows);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

async function createSlot(req, res) {
  try {
    const { court_id, batch, slot_date, start_time, end_time, notes } = req.body;
    if (!court_id || !batch || !slot_date || !start_time || !end_time) {
      return res.status(400).json({ message: 'court_id, batch, slot_date, start_time, end_time are required.' });
    }
    if (!['MORNING','EVENING'].includes(batch)) {
      return res.status(400).json({ message: 'batch must be MORNING or EVENING.' });
    }
    if (start_time >= end_time) {
      return res.status(400).json({ message: 'start_time must be before end_time.' });
    }
    // Check for overlap on same court/date
    const [overlap] = await pool.execute(
      `SELECT id FROM slots WHERE court_id=? AND slot_date=?
       AND status NOT IN ('CLOSED','UNAVAILABLE')
       AND NOT (end_time<=? OR start_time>=?)`,
      [court_id, slot_date, start_time, end_time]
    );
    if (overlap.length) {
      return res.status(409).json({ message: 'Slot overlaps with an existing slot for this court.' });
    }
    // Validate batch timing if configured
    const [batches] = await pool.execute('SELECT * FROM batch_timings WHERE batch_name=?', [batch]);
    if (batches.length) {
      const bt = batches[0];
      if (start_time < bt.open_time || end_time > bt.close_time) {
        return res.status(400).json({ message: `Slot time must be within ${batch} batch hours (${bt.open_time}-${bt.close_time}).` });
      }
    }
    const [result] = await pool.execute(
      'INSERT INTO slots (court_id, batch, slot_date, start_time, end_time, created_by, notes) VALUES (?,?,?,?,?,?,?)',
      [court_id, batch, slot_date, start_time, end_time, req.user.id, notes||null]
    );
    return res.status(201).json({ message: 'Slot created.', slotId: result.insertId });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

async function updateSlot(req, res) {
  try {
    const { status, start_time, end_time, notes, batch } = req.body;
    const slotId = req.params.id;
    const [existing] = await pool.execute('SELECT * FROM slots WHERE id=?', [slotId]);
    if (!existing.length) return res.status(404).json({ message: 'Slot not found.' });
    const slot = existing[0];
    const newStart = start_time || slot.start_time;
    const newEnd   = end_time   || slot.end_time;
    const newBatch = batch      || slot.batch;
    const newStatus= status     || slot.status;
    if (newStart >= newEnd) return res.status(400).json({ message: 'start_time must be before end_time.' });
    // Check overlap excluding self
    const [overlap] = await pool.execute(
      `SELECT id FROM slots WHERE court_id=? AND slot_date=? AND id<>?
       AND status NOT IN ('CLOSED','UNAVAILABLE')
       AND NOT (end_time<=? OR start_time>=?)`,
      [slot.court_id, slot.slot_date, slotId, newStart, newEnd]
    );
    if (overlap.length) return res.status(409).json({ message: 'Updated slot overlaps with another slot.' });
    await pool.execute(
      'UPDATE slots SET status=?, start_time=?, end_time=?, batch=?, notes=? WHERE id=?',
      [newStatus, newStart, newEnd, newBatch, notes||slot.notes, slotId]
    );
    return res.json({ message: 'Slot updated.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

async function deleteSlot(req, res) {
  try {
    const [bookings] = await pool.execute(
      "SELECT id FROM bookings WHERE slot_id=? AND status='CONFIRMED' LIMIT 1",
      [req.params.id]
    );
    if (bookings.length) {
      return res.status(409).json({ message: 'Cannot delete slot with confirmed bookings. Mark it as UNAVAILABLE instead.' });
    }
    const [result] = await pool.execute('DELETE FROM slots WHERE id=?', [req.params.id]);
    if (!result.affectedRows) return res.status(404).json({ message: 'Slot not found.' });
    return res.json({ message: 'Slot deleted.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

async function copySlots(req, res) {
  try {
    const { from_date, to_date } = req.body;
    if (!from_date || !to_date) return res.status(400).json({ message: 'from_date and to_date are required.' });
    if (from_date === to_date) return res.status(400).json({ message: 'Dates must differ.' });
    const [sourceSlots] = await pool.execute(
      'SELECT * FROM slots WHERE slot_date=?', [from_date]
    );
    if (!sourceSlots.length) return res.status(404).json({ message: 'No slots found for source date.' });
    let copied = 0;
    for (const s of sourceSlots) {
      const [ov] = await pool.execute(
        `SELECT id FROM slots WHERE court_id=? AND slot_date=? AND NOT (end_time<=? OR start_time>=?)`,
        [s.court_id, to_date, s.start_time, s.end_time]
      );
      if (!ov.length) {
        await pool.execute(
          'INSERT INTO slots (court_id, batch, slot_date, start_time, end_time, created_by, notes) VALUES (?,?,?,?,?,?,?)',
          [s.court_id, s.batch, to_date, s.start_time, s.end_time, req.user.id, s.notes]
        );
        copied++;
      }
    }
    return res.json({ message: `Copied ${copied} slot(s) to ${to_date}.`, copied });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

module.exports = { listSlots, createSlot, updateSlot, deleteSlot, copySlots };
