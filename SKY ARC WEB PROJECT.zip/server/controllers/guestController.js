'use strict';
const { pool } = require('../db');

async function listGuests(req, res) {
  try {
    const [rows] = await pool.execute(
      `SELECT gr.*, s.slot_date, s.start_time, s.end_time, s.batch,
              c.court_number, u.name as reserved_by_name
       FROM guest_reservations gr
       JOIN slots s ON gr.slot_id=s.id
       JOIN courts c ON s.court_id=c.id
       JOIN users u ON gr.reserved_by=u.id
       WHERE gr.status='ACTIVE'
       ORDER BY s.slot_date DESC`
    );
    return res.json(rows);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

async function createGuestReservation(req, res) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const { slot_id, guest_count, guest_info, notes } = req.body;
    if (!slot_id) { await conn.rollback(); return res.status(400).json({ message: 'slot_id required.' }); }
    const [slots] = await conn.execute('SELECT * FROM slots WHERE id=? FOR UPDATE', [slot_id]);
    if (!slots.length) { await conn.rollback(); return res.status(404).json({ message: 'Slot not found.' }); }
    // Cancel member bookings, mark as INCHARGE_RESERVED
    await conn.execute(
      "UPDATE bookings SET status='CANCELLED', cancelled_at=NOW(), cancelled_by=? WHERE slot_id=? AND status='CONFIRMED' AND booking_type='MEMBER'",
      [req.user.id, slot_id]
    );
    await conn.execute("UPDATE slots SET status='INCHARGE_RESERVED' WHERE id=?", [slot_id]);
    const [result] = await conn.execute(
      'INSERT INTO guest_reservations (slot_id, reserved_by, guest_count, guest_info, notes) VALUES (?,?,?,?,?)',
      [slot_id, req.user.id, guest_count||1, guest_info||null, notes||null]
    );
    await conn.commit();
    return res.status(201).json({ message: 'Guest reservation created.', id: result.insertId });
  } catch (err) {
    await conn.rollback();
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  } finally {
    conn.release();
  }
}

async function cancelGuestReservation(req, res) {
  try {
    const [rows] = await pool.execute('SELECT * FROM guest_reservations WHERE id=?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ message: 'Reservation not found.' });
    await pool.execute("UPDATE guest_reservations SET status='CANCELLED' WHERE id=?", [req.params.id]);
    // Reset slot status
    await pool.execute("UPDATE slots SET status='AVAILABLE' WHERE id=?", [rows[0].slot_id]);
    return res.json({ message: 'Guest reservation cancelled.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

module.exports = { listGuests, createGuestReservation, cancelGuestReservation };
