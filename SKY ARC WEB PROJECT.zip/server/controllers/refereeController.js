'use strict';

const bcrypt = require('bcrypt');
const { pool } = require('../db');

const SALT_ROUNDS = 12;

/**
 * List all referees (Court In-Charge & Coach)
 */
async function listReferees(req, res) {
  try {
    const [rows] = await pool.query(`
      SELECT r.*, u.username, u.active as user_active
      FROM referees r
      LEFT JOIN users u ON r.user_id = u.id
      ORDER BY r.name ASC
    `);
    return res.json(rows);
  } catch (err) {
    console.error('listReferees error:', err);
    return res.status(500).json({ message: 'Server error listing referees.' });
  }
}

/**
 * Add a new referee (Court In-Charge only)
 */
async function createReferee(req, res) {
  const conn = await pool.getConnection();
  try {
    await conn.query('START TRANSACTION');
    const { name, email, phone, qualification, experience, username, password } = req.body;

    if (!name) {
      return res.status(400).json({ message: 'Referee name is required.' });
    }

    let userId = null;
    if (username && password) {
      // Check username uniqueness
      const [uCheck] = await conn.query('SELECT id FROM users WHERE username = ?', [username]);
      if (uCheck.length > 0) {
        return res.status(409).json({ message: 'Username already exists.' });
      }

      const hash = await bcrypt.hash(password, SALT_ROUNDS);
      const [uRes] = await conn.query(`
        INSERT INTO users (name, username, email, password_hash, role, phone, active)
        VALUES (?, ?, ?, ?, 'REFEREE', ?, 1)
      `, [name, username, email || `${username}@skyarc.local`, hash, phone || null]);
      userId = uRes.insertId;
    }

    const [rRes] = await conn.query(`
      INSERT INTO referees (user_id, name, email, phone, qualification, experience, availability, status)
      VALUES (?, ?, ?, ?, ?, ?, 'AVAILABLE', 'ACTIVE')
    `, [userId, name, email || null, phone || null, qualification || null, experience || null]);

    // Audit log
    await conn.query(`
      INSERT INTO audit_logs (user_id, action, entity, entity_id, details)
      VALUES (?, 'CREATE_REFEREE', 'referees', ?, ?)
    `, [req.user.id, rRes.insertId, JSON.stringify({ name, qualification, username: username || null })]);

    await conn.query('COMMIT');
    return res.status(201).json({ message: 'Referee created successfully.', refereeId: rRes.insertId });
  } catch (err) {
    await conn.query('ROLLBACK');
    console.error('createReferee error:', err);
    return res.status(500).json({ message: 'Server error creating referee.' });
  } finally {
    conn.release();
  }
}

/**
 * Update referee details (Court In-Charge only)
 */
async function updateReferee(req, res) {
  const conn = await pool.getConnection();
  try {
    const { id } = req.params;
    const { name, email, phone, qualification, experience, availability, status } = req.body;

    const [rows] = await conn.query('SELECT * FROM referees WHERE id = ?', [id]);
    if (rows.length === 0) return res.status(404).json({ message: 'Referee not found.' });

    await conn.query(`
      UPDATE referees
      SET name = ?, email = ?, phone = ?, qualification = ?, experience = ?, availability = ?, status = ?
      WHERE id = ?
    `, [
      name, email || null, phone || null, qualification || null, experience || null,
      availability || 'AVAILABLE', status || 'ACTIVE', id
    ]);

    // Audit log
    await conn.query(`
      INSERT INTO audit_logs (user_id, action, entity, entity_id, details)
      VALUES (?, 'UPDATE_REFEREE', 'referees', ?, ?)
    `, [req.user.id, id, JSON.stringify({ name, qualification, status })]);

    return res.json({ message: 'Referee updated successfully.' });
  } catch (err) {
    console.error('updateReferee error:', err);
    return res.status(500).json({ message: 'Server error updating referee.' });
  } finally {
    conn.release();
  }
}

/**
 * Get assigned matches for the logged-in referee
 */
async function getMyAssignedMatches(req, res) {
  try {
    // Find referee linked to req.user.id
    const [refRows] = await pool.query('SELECT id, name FROM referees WHERE user_id = ?', [req.user.id]);
    if (refRows.length === 0) {
      return res.status(403).json({ message: 'No referee profile associated with this account.' });
    }
    const refereeId = refRows[0].id;

    const [matches] = await pool.query(`
      SELECT m.*,
             t.name as tournament_name, t.status as tournament_status, t.format as tournament_format,
             c.display_name as category_display, c.type as category_type,
             crt.court_number, crt.court_name,
             t1.team_name as team1_name,
             t2.team_name as team2_name,
             w.team_name as winner_name,
             mr.team1_score, mr.team2_score, mr.scores_detail, mr.is_locked, mr.man_of_match as result_mom
      FROM tournament_matches m
      JOIN tournaments t ON m.tournament_id = t.id
      JOIN tournament_categories c ON m.category_id = c.id
      LEFT JOIN courts crt ON m.court_id = crt.id
      LEFT JOIN tournament_registrations t1 ON m.team1_id = t1.id
      LEFT JOIN tournament_registrations t2 ON m.team2_id = t2.id
      LEFT JOIN tournament_registrations w ON m.winner_id = w.id
      LEFT JOIN match_results mr ON m.id = mr.match_id
      WHERE m.referee_id = ?
      ORDER BY m.scheduled_date ASC, m.scheduled_time ASC, m.match_number ASC
    `, [refereeId]);

    return res.json({ referee: refRows[0], matches });
  } catch (err) {
    console.error('getMyAssignedMatches error:', err);
    return res.status(500).json({ message: 'Server error retrieving assigned matches.' });
  }
}

module.exports = {
  listReferees,
  createReferee,
  updateReferee,
  getMyAssignedMatches
};
