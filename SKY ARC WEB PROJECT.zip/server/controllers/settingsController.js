'use strict';
const { pool } = require('../db');

async function getSettings(req, res) {
  try {
    const [rows] = await pool.execute('SELECT setting_key, setting_val FROM academy_settings');
    const settings = {};
    rows.forEach(r => { settings[r.setting_key] = r.setting_val; });
    return res.json(settings);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

async function updateSettings(req, res) {
  try {
    const updates = req.body; // { key: value, ... }
    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();
      for (const [key, val] of Object.entries(updates)) {
        await conn.execute(
          'INSERT INTO academy_settings (setting_key, setting_val, updated_by) VALUES (?,?,?) ON DUPLICATE KEY UPDATE setting_val=VALUES(setting_val), updated_by=VALUES(updated_by)',
          [key, val, req.user.id]
        );
      }
      await conn.commit();
      return res.json({ message: 'Settings updated.' });
    } catch (e) {
      await conn.rollback();
      throw e;
    } finally {
      conn.release();
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

async function getBatches(req, res) {
  try {
    const [rows] = await pool.execute('SELECT * FROM batch_timings ORDER BY batch_name');
    return res.json(rows);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

async function updateBatches(req, res) {
  try {
    const { batch_name, open_time, close_time } = req.body;
    if (!batch_name || !open_time || !close_time) {
      return res.status(400).json({ message: 'batch_name, open_time, close_time required.' });
    }
    if (!['MORNING','EVENING'].includes(batch_name)) {
      return res.status(400).json({ message: 'batch_name must be MORNING or EVENING.' });
    }
    await pool.execute(
      `INSERT INTO batch_timings (batch_name, open_time, close_time, updated_by)
       VALUES (?,?,?,?)
       ON DUPLICATE KEY UPDATE open_time=VALUES(open_time), close_time=VALUES(close_time), updated_by=VALUES(updated_by)`,
      [batch_name, open_time, close_time, req.user.id]
    );
    return res.json({ message: 'Batch timing updated.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

module.exports = { getSettings, updateSettings, getBatches, updateBatches };
