'use strict';

const bcrypt = require('bcrypt');
const jwt    = require('jsonwebtoken');
const { pool } = require('../db');

async function login(req, res) {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ message: 'Username/email and password are required.' });
    }

    // Find by username OR email
    const [rows] = await pool.execute(
      'SELECT * FROM users WHERE (username = ? OR email = ?) AND active = 1 LIMIT 1',
      [username, username]
    );

    if (rows.length === 0) {
      return res.status(401).json({ message: 'Invalid credentials or account is inactive.' });
    }

    const user = rows[0];
    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) {
      return res.status(401).json({ message: 'Invalid credentials.' });
    }

    const token = jwt.sign(
      { id: user.id, username: user.username, name: user.name, role: user.role, email: user.email },
      process.env.JWT_SECRET || 'dev-secret',
      { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
    );

    return res.json({
      token,
      user: {
        id:       user.id,
        name:     user.name,
        username: user.username,
        email:    user.email,
        role:     user.role,
        age:      user.age,
        phone:    user.phone,
        date_of_joining: user.date_of_joining
      }
    });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ message: 'Server error during login.' });
  }
}

async function getMe(req, res) {
  try {
    const [rows] = await pool.execute(
      'SELECT id, name, username, email, role, age, phone, date_of_joining, active, created_at FROM users WHERE id = ?',
      [req.user.id]
    );
    if (rows.length === 0) return res.status(404).json({ message: 'User not found.' });
    return res.json(rows[0]);
  } catch (err) {
    console.error('getMe error:', err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

module.exports = { login, getMe };
