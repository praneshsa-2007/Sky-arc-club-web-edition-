'use strict';

const { pool } = require('../db');

/**
 * Register member for a tournament category
 */
async function registerForTournament(req, res) {
  const conn = await pool.getConnection();
  try {
    await conn.query('START TRANSACTION');
    const tournamentId = parseInt(req.params.id, 10);
    const { category_id, partner_id } = req.body;
    const memberId = req.user.id;

    if (!category_id) {
      return res.status(400).json({ message: 'Category is required.' });
    }

    // 1. Check tournament status & deadline
    const [tRows] = await conn.query('SELECT * FROM tournaments WHERE id = ?', [tournamentId]);
    if (tRows.length === 0) {
      return res.status(404).json({ message: 'Tournament not found.' });
    }
    const tournament = tRows[0];

    if (tournament.status !== 'REGISTRATION_OPEN') {
      return res.status(400).json({
        message: `Registration is not open for this tournament (Current status: ${tournament.status}).`
      });
    }

    if (tournament.registration_deadline) {
      const today = new Date().toISOString().slice(0, 10);
      if (today > tournament.registration_deadline) {
        return res.status(400).json({ message: 'Registration deadline for this tournament has passed.' });
      }
    }

    // 2. Check category
    const [cRows] = await conn.query(`
      SELECT * FROM tournament_categories WHERE id = ? AND tournament_id = ?
    `, [category_id, tournamentId]);
    if (cRows.length === 0) {
      return res.status(400).json({ message: 'Selected category does not exist for this tournament.' });
    }
    const category = cRows[0];

    // Fetch member user details
    const [mUser] = await conn.query('SELECT id, name, username, active, role FROM users WHERE id = ?', [memberId]);
    if (mUser.length === 0 || !mUser[0].active) {
      return res.status(403).json({ message: 'Invalid or inactive member account.' });
    }

    let partnerUser = null;
    let teamName = mUser[0].name || mUser[0].username;
    let pairIdentifier = `S:${memberId}`;

    if (category.type === 'SINGLES') {
      // Check if member already registered in this singles category
      const [existing] = await conn.query(`
        SELECT id FROM tournament_registrations
        WHERE category_id = ? AND member_id = ? AND registration_status = 'CONFIRMED'
      `, [category_id, memberId]);

      if (existing.length > 0) {
        return res.status(409).json({
          message: 'You are already registered for this category in this tournament.'
        });
      }
    } else {
      // DOUBLES VALIDATION (Rule 17)
      if (!partner_id) {
        return res.status(400).json({ message: 'Partner is required for doubles categories.' });
      }

      const pId = parseInt(partner_id, 10);
      if (pId === memberId) {
        return res.status(400).json({ message: 'You cannot select yourself as your partner.' });
      }

      const [pRows] = await conn.query('SELECT id, name, username, active, role FROM users WHERE id = ?', [pId]);
      if (pRows.length === 0 || !pRows[0].active) {
        return res.status(400).json({ message: 'Selected partner is not an active registered member.' });
      }
      partnerUser = pRows[0];

      // Normalize pair identifier
      const minId = Math.min(memberId, pId);
      const maxId = Math.max(memberId, pId);
      pairIdentifier = `D:${minId}_${maxId}`;

      teamName = `${mUser[0].name || mUser[0].username} / ${partnerUser.name || partnerUser.username}`;

      // Check if this exact pair is already registered
      const [existingPair] = await conn.query(`
        SELECT id FROM tournament_registrations
        WHERE category_id = ? AND pair_identifier = ? AND registration_status = 'CONFIRMED'
      `, [category_id, pairIdentifier]);

      if (existingPair.length > 0) {
        return res.status(409).json({ message: 'This doubles pair is already registered for this category.' });
      }

      // Check if either player is already registered in this doubles category with another partner!
      const [playerClash] = await conn.query(`
        SELECT id FROM tournament_registrations
        WHERE category_id = ? AND registration_status = 'CONFIRMED'
          AND (member_id IN (?, ?) OR partner_id IN (?, ?))
      `, [category_id, memberId, pId, memberId, pId]);

      if (playerClash.length > 0) {
        return res.status(409).json({
          message: 'You or your partner are already registered in this doubles category with another team.'
        });
      }
    }

    // Insert registration
    const [regRes] = await conn.query(`
      INSERT INTO tournament_registrations (
        tournament_id, category_id, member_id, partner_id, team_name, pair_identifier, registration_status
      ) VALUES (?, ?, ?, ?, ?, ?, 'CONFIRMED')
    `, [tournamentId, category_id, memberId, partnerUser ? partnerUser.id : null, teamName, pairIdentifier]);

    // Audit log
    await conn.query(`
      INSERT INTO audit_logs (user_id, action, entity, entity_id, details)
      VALUES (?, 'TOURNAMENT_REGISTRATION', 'tournament_registrations', ?, ?)
    `, [memberId, regRes.insertId, JSON.stringify({ tournamentId, category_id, teamName, pairIdentifier })]);

    await conn.query('COMMIT');
    return res.status(201).json({
      message: `Successfully registered for ${category.display_name}!`,
      registrationId: regRes.insertId,
      teamName
    });
  } catch (err) {
    await conn.query('ROLLBACK');
    console.error('registerForTournament error:', err);
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ message: 'Duplicate registration entry detected.' });
    }
    return res.status(500).json({ message: 'Server error during tournament registration.' });
  } finally {
    conn.release();
  }
}

/**
 * Get current member's registrations
 */
async function getMyRegistrations(req, res) {
  try {
    const memberId = req.user.id;
    const [rows] = await pool.query(`
      SELECT tr.*, t.name as tournament_name, t.status as tournament_status,
             t.start_date, t.end_date, t.venue, tc.display_name as category_display,
             tc.type as category_type,
             p.name as partner_name
      FROM tournament_registrations tr
      JOIN tournaments t ON tr.tournament_id = t.id
      JOIN tournament_categories tc ON tr.category_id = tc.id
      LEFT JOIN users p ON tr.partner_id = p.id
      WHERE (tr.member_id = ? OR tr.partner_id = ?) AND tr.registration_status = 'CONFIRMED'
      ORDER BY t.start_date DESC
    `, [memberId, memberId]);

    return res.json(rows);
  } catch (err) {
    console.error('getMyRegistrations error:', err);
    return res.status(500).json({ message: 'Server error retrieving registrations.' });
  }
}

/**
 * Get participant's next scheduled match (Rule 24)
 * Strict Confidentiality: Does NOT expose referee details!
 */
async function getMyNextMatch(req, res) {
  try {
    const memberId = req.user.id;

    // Find teams where user is member or partner
    const [teams] = await pool.query(`
      SELECT id FROM tournament_registrations
      WHERE (member_id = ? OR partner_id = ?) AND registration_status = 'CONFIRMED'
    `, [memberId, memberId]);

    if (teams.length === 0) {
      return res.json({ nextMatch: null });
    }

    const teamIds = teams.map(t => t.id);

    // Find next upcoming match
    const [matches] = await pool.query(`
      SELECT m.id, m.tournament_id, m.category_id, m.round_name, m.round_number, m.match_number,
             m.scheduled_date, m.scheduled_time, m.status,
             m.team1_id, m.team2_id,
             t.name as tournament_name, t.venue,
             c.display_name as category_display,
             crt.court_number, crt.court_name,
             t1.team_name as team1_name,
             t2.team_name as team2_name
      FROM tournament_matches m
      JOIN tournaments t ON m.tournament_id = t.id
      JOIN tournament_categories c ON m.category_id = c.id
      LEFT JOIN courts crt ON m.court_id = crt.id
      LEFT JOIN tournament_registrations t1 ON m.team1_id = t1.id
      LEFT JOIN tournament_registrations t2 ON m.team2_id = t2.id
      WHERE (m.team1_id IN (${teamIds.join(',')}) OR m.team2_id IN (${teamIds.join(',')}))
        AND m.status = 'SCHEDULED'
      ORDER BY m.scheduled_date ASC, m.scheduled_time ASC, m.round_number ASC
      LIMIT 1
    `);

    if (matches.length === 0) {
      return res.json({ nextMatch: null });
    }

    const match = matches[0];
    const isTeam1 = teamIds.includes(match.team1_id);
    const opponentTeamName = isTeam1 ? match.team2_name : match.team1_name;

    const result = {
      matchId: match.id,
      tournament: match.tournament_name,
      venue: match.venue,
      category: match.category_display,
      round: match.round_name,
      date: match.scheduled_date,
      time: match.scheduled_time,
      court: match.court_number ? `Court ${match.court_number}` : 'TBD',
      opponent: opponentTeamName || 'Opponent to be determined',
      status: match.status
    };

    return res.json({ nextMatch: result });
  } catch (err) {
    console.error('getMyNextMatch error:', err);
    return res.status(500).json({ message: 'Server error retrieving next match.' });
  }
}

module.exports = {
  registerForTournament,
  getMyRegistrations,
  getMyNextMatch
};
