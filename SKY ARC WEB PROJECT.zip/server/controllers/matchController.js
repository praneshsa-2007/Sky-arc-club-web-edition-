'use strict';

const { pool } = require('../db');
const { processMatchResult } = require('../services/tournamentService');

/**
 * Submit match result by assigned referee
 * Strictly locks result once submitted!
 */
async function submitMatchResult(req, res) {
  const conn = await pool.getConnection();
  try {
    await conn.query('START TRANSACTION');
    const matchId = parseInt(req.params.id, 10);
    const { team1_score, team2_score, scores_detail, winner_id, man_of_match, duration_minutes, remarks } = req.body;

    if (team1_score === undefined || team2_score === undefined || !winner_id) {
      return res.status(400).json({ message: 'team1_score, team2_score and winner_id are required.' });
    }

    const t1Score = parseInt(team1_score, 10);
    const t2Score = parseInt(team2_score, 10);
    const wId = parseInt(winner_id, 10);

    // Fetch match
    const [mRows] = await conn.query('SELECT * FROM tournament_matches WHERE id = ?', [matchId]);
    if (mRows.length === 0) return res.status(404).json({ message: 'Match not found.' });
    const match = mRows[0];

    // Check if match is already locked
    if (match.status === 'COMPLETED') {
      return res.status(403).json({ message: 'This match result has already been submitted and is LOCKED.' });
    }

    // Verify authorized referee / in-charge
    if (req.user.role === 'REFEREE') {
      const [refRow] = await conn.query('SELECT id FROM referees WHERE user_id = ?', [req.user.id]);
      if (refRow.length === 0 || match.referee_id !== refRow[0].id) {
        return res.status(403).json({ message: 'Access denied. You can only submit results for matches assigned to you.' });
      }
    } else if (req.user.role !== 'COURT_INCHARGE') {
      return res.status(403).json({ message: 'Only the assigned Referee or Court In-Charge can submit match results.' });
    }

    // Verify winner_id matches either team1 or team2
    if (wId !== match.team1_id && wId !== match.team2_id) {
      return res.status(400).json({ message: 'Winner must be one of the participating teams in this match.' });
    }

    // Process result & progression
    await processMatchResult({
      matchId,
      team1Score: t1Score,
      team2Score: t2Score,
      scoresDetail: scores_detail || `${t1Score}-${t2Score}`,
      winnerId: wId,
      refereeUserId: req.user.id,
      manOfMatch: man_of_match || null,
      durationMinutes: duration_minutes || null,
      remarks: remarks || null,
      conn
    });

    // Audit log
    await conn.query(`
      INSERT INTO audit_logs (user_id, action, entity, entity_id, details)
      VALUES (?, 'SUBMIT_MATCH_RESULT', 'tournament_matches', ?, ?)
    `, [req.user.id, matchId, JSON.stringify({ t1Score, t2Score, winnerId: wId, manOfMatch: man_of_match || null })]);

    await conn.query('COMMIT');
    return res.json({ message: 'Match result submitted and LOCKED successfully! Tournament progression updated.' });
  } catch (err) {
    await conn.query('ROLLBACK');
    console.error('submitMatchResult error:', err);
    return res.status(400).json({ message: err.message || 'Error submitting match result.' });
  } finally {
    conn.release();
  }
}

/**
 * Get match details
 */
async function getMatch(req, res) {
  try {
    const matchId = parseInt(req.params.id, 10);
    const [rows] = await pool.query(`
      SELECT m.*,
             t.name as tournament_name, t.status as tournament_status,
             c.display_name as category_display, c.type as category_type,
             crt.court_number, crt.court_name,
             r.name as referee_name, r.qualification as referee_qualification,
             t1.team_name as team1_name,
             t2.team_name as team2_name,
             w.team_name as winner_name,
             mr.team1_score, mr.team2_score, mr.scores_detail, mr.is_locked, mr.man_of_match as result_mom,
             mr.remarks, mr.duration_minutes
      FROM tournament_matches m
      JOIN tournaments t ON m.tournament_id = t.id
      JOIN tournament_categories c ON m.category_id = c.id
      LEFT JOIN courts crt ON m.court_id = crt.id
      LEFT JOIN referees r ON m.referee_id = r.id
      LEFT JOIN tournament_registrations t1 ON m.team1_id = t1.id
      LEFT JOIN tournament_registrations t2 ON m.team2_id = t2.id
      LEFT JOIN tournament_registrations w ON m.winner_id = w.id
      LEFT JOIN match_results mr ON m.id = mr.match_id
      WHERE m.id = ?
    `, [matchId]);

    if (rows.length === 0) return res.status(404).json({ message: 'Match not found.' });
    const match = rows[0];

    // Confidentiality check
    const userRole = req.user?.role;
    const isAuthorizedRole = (userRole === 'COACH' || userRole === 'COURT_INCHARGE');
    const isMatchCompleted = (match.status === 'COMPLETED');

    if (!isAuthorizedRole && !isMatchCompleted) {
      match.referee_id = null;
      match.referee_name = null;
      match.referee_qualification = null;
    }

    return res.json(match);
  } catch (err) {
    console.error('getMatch error:', err);
    return res.status(500).json({ message: 'Server error retrieving match.' });
  }
}

module.exports = {
  submitMatchResult,
  getMatch
};
