'use strict';
const { pool } = require('../db');

async function listCourts(req, res) {
  try {
    const activeOnly = req.query.active !== 'false';
    let sql = 'SELECT c.*, u.name as created_by_name FROM courts c LEFT JOIN users u ON c.created_by = u.id';
    if (activeOnly) sql += ' WHERE c.active = 1';
    sql += ' ORDER BY c.court_number ASC';
    const [rows] = await pool.execute(sql);
    return res.json(rows);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

async function createCourt(req, res) {
  try {
    const { court_number, court_name, court_type } = req.body;
    if (!court_number) return res.status(400).json({ message: 'court_number is required.' });
    const validTypes = ['WOODEN','SYNTHETIC','OTHER'];
    const type = validTypes.includes(court_type) ? court_type : 'WOODEN';
    const [result] = await pool.execute(
      'INSERT INTO courts (court_number, court_name, court_type, created_by) VALUES (?,?,?,?)',
      [court_number, court_name || null, type, req.user.id]
    );
    return res.status(201).json({ message: 'Court created.', courtId: result.insertId });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ message: 'Court number already exists.' });
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

async function updateCourt(req, res) {
  try {
    const { court_number, court_name, court_type, active } = req.body;
    const validTypes = ['WOODEN','SYNTHETIC','OTHER'];
    const type = validTypes.includes(court_type) ? court_type : 'WOODEN';
    const [result] = await pool.execute(
      'UPDATE courts SET court_number=?, court_name=?, court_type=?, active=? WHERE id=?',
      [court_number, court_name||null, type, active!==undefined ? (active?1:0) : 1, req.params.id]
    );
    if (!result.affectedRows) return res.status(404).json({ message: 'Court not found.' });
    return res.json({ message: 'Court updated.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

async function deleteCourt(req, res) {
  try {
    // Soft delete
    const [result] = await pool.execute('UPDATE courts SET active=0 WHERE id=?', [req.params.id]);
    if (!result.affectedRows) return res.status(404).json({ message: 'Court not found.' });
    return res.json({ message: 'Court deactivated.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

module.exports = { listCourts, createCourt, updateCourt, deleteCourt };
