'use strict';
const { pool } = require('../db');

async function listBookings(req, res) {
  try {
    let sql, params = [];
    if (req.user.role === 'MEMBER') {
      sql = `SELECT b.*, s.slot_date, s.start_time, s.end_time, s.batch,
               c.court_number, c.court_type
             FROM bookings b
             JOIN slots s ON b.slot_id=s.id
             JOIN courts c ON s.court_id=c.id
             WHERE b.user_id=?
             ORDER BY b.booked_at DESC`;
      params = [req.user.id];
    } else {
      const slotDate = req.query.date;
      sql = `SELECT b.*, s.slot_date, s.start_time, s.end_time, s.batch,
               c.court_number, c.court_type,
               u.name as member_name, u.username, u.phone
             FROM bookings b
             JOIN slots s ON b.slot_id=s.id
             JOIN courts c ON s.court_id=c.id
             JOIN users u ON b.user_id=u.id`;
      if (slotDate) { sql += ' WHERE s.slot_date=?'; params.push(slotDate); }
      sql += ' ORDER BY b.booked_at DESC';
    }
    const [rows] = await pool.execute(sql, params);
    return res.json(rows);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

async function createBooking(req, res) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const { slot_id } = req.body;
    if (!slot_id) return res.status(400).json({ message: 'slot_id is required.' });

    // Get slot (with lock)
    const [slots] = await conn.execute('SELECT * FROM slots WHERE id=? FOR UPDATE', [slot_id]);
    if (!slots.length) { await conn.rollback(); return res.status(404).json({ message: 'Slot not found.' }); }
    const slot = slots[0];

    // Members cannot book coach/incharge reserved slots
    if (req.user.role === 'MEMBER' && ['COACH_RESERVED','INCHARGE_RESERVED'].includes(slot.status)) {
      await conn.rollback();
      return res.status(403).json({ message: 'This slot is reserved. Members cannot book it.' });
    }

    // Slot must be AVAILABLE
    if (slot.status === 'UNAVAILABLE' || slot.status === 'CLOSED') {
      await conn.rollback();
      return res.status(409).json({ message: 'Slot is not available for booking.' });
    }

    // One-day-before rule for members
    if (req.user.role === 'MEMBER') {
      const today = new Date();
      today.setHours(0,0,0,0);
      const slotDate = new Date(slot.slot_date);
      slotDate.setHours(0,0,0,0);
      const diffDays = (slotDate - today) / 86400000;
      if (diffDays < 1) {
        await conn.rollback();
        return res.status(400).json({ message: 'Members must book at least one day in advance.' });
      }
    }

    // Check capacity
    const [countRows] = await conn.execute(
      "SELECT COUNT(*) as cnt FROM bookings WHERE slot_id=? AND status='CONFIRMED'",
      [slot_id]
    );
    const booked = countRows[0].cnt;
    if (booked >= slot.max_capacity) {
      await conn.rollback();
      return res.status(409).json({ message: 'Slot is full (max capacity reached).' });
    }

    // Check if user already booked this slot
    const [existing] = await conn.execute(
      "SELECT id FROM bookings WHERE slot_id=? AND user_id=? AND status='CONFIRMED'",
      [slot_id, req.user.id]
    );
    if (existing.length) {
      await conn.rollback();
      return res.status(409).json({ message: 'You have already booked this slot.' });
    }

    // Check user doesn't have overlapping confirmed booking on same date
    const [overlap] = await conn.execute(
      `SELECT b.id FROM bookings b
       JOIN slots s2 ON b.slot_id=s2.id
       WHERE b.user_id=? AND b.status='CONFIRMED'
       AND s2.slot_date=?
       AND NOT (s2.end_time<=? OR s2.start_time>=?)`,
      [req.user.id, slot.slot_date, slot.start_time, slot.end_time]
    );
    if (overlap.length) {
      await conn.rollback();
      return res.status(409).json({ message: 'You already have an overlapping booking on this date.' });
    }

    const bookingType = req.user.role === 'MEMBER' ? 'MEMBER' : req.user.role;
    const [result] = await conn.execute(
      'INSERT INTO bookings (slot_id, user_id, booking_type) VALUES (?,?,?)',
      [slot_id, req.user.id, bookingType]
    );
    await conn.commit();

    return res.status(201).json({
      message: 'Booking confirmed!',
      bookingId: result.insertId,
      slotDate: slot.slot_date,
      startTime: slot.start_time,
      endTime: slot.end_time,
      currentCount: booked + 1,
      maxCapacity: slot.max_capacity
    });
  } catch (err) {
    await conn.rollback();
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ message: 'You have already booked this slot.' });
    }
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  } finally {
    conn.release();
  }
}

async function cancelBooking(req, res) {
  try {
    const bookingId = req.params.id;
    const [rows] = await pool.execute('SELECT * FROM bookings WHERE id=?', [bookingId]);
    if (!rows.length) return res.status(404).json({ message: 'Booking not found.' });
    const booking = rows[0];
    // Only the owner, a coach, or incharge can cancel
    if (req.user.role === 'MEMBER' && booking.user_id !== req.user.id) {
      return res.status(403).json({ message: 'You can only cancel your own bookings.' });
    }
    await pool.execute(
      "UPDATE bookings SET status='CANCELLED', cancelled_at=NOW(), cancelled_by=? WHERE id=?",
      [req.user.id, bookingId]
    );
    return res.json({ message: 'Booking cancelled.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

async function reserveWholeCourt(req, res) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const { slot_id, reason, guest_count } = req.body;
    if (!slot_id) { await conn.rollback(); return res.status(400).json({ message: 'slot_id required.' }); }
    const [slots] = await conn.execute('SELECT * FROM slots WHERE id=? FOR UPDATE', [slot_id]);
    if (!slots.length) { await conn.rollback(); return res.status(404).json({ message: 'Slot not found.' }); }
    const slot = slots[0];
    const newStatus = req.user.role === 'COACH' ? 'COACH_RESERVED' : 'INCHARGE_RESERVED';
    // Cancel all existing member bookings
    await conn.execute(
      "UPDATE bookings SET status='CANCELLED', cancelled_at=NOW(), cancelled_by=? WHERE slot_id=? AND status='CONFIRMED'",
      [req.user.id, slot_id]
    );
    await conn.execute('UPDATE slots SET status=?, notes=? WHERE id=?', [newStatus, reason||null, slot_id]);
    // Insert a single reservation booking
    await conn.execute(
      'INSERT INTO bookings (slot_id, user_id, booking_type, guest_count, notes) VALUES (?,?,?,?,?)',
      [slot_id, req.user.id, req.user.role==='COACH'?'COACH':'INCHARGE', guest_count||0, reason||null]
    );
    await conn.commit();
    return res.json({ message: 'Court reserved successfully.' });
  } catch (err) {
    await conn.rollback();
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  } finally {
    conn.release();
  }
}

module.exports = { listBookings, createBooking, cancelBooking, reserveWholeCourt };
