'use strict';
const { pool } = require('../db');

async function getStats(req, res) {
  try {
    const today = new Date().toISOString().slice(0,10);
    const tomorrow = new Date(Date.now()+86400000).toISOString().slice(0,10);
    const stats = {};

    if (req.user.role === 'MEMBER') {
      const [myBookings] = await pool.execute(
        "SELECT COUNT(*) as cnt FROM bookings WHERE user_id=? AND status='CONFIRMED'", [req.user.id]);
      const [upcoming] = await pool.execute(
        `SELECT COUNT(*) as cnt FROM bookings b JOIN slots s ON b.slot_id=s.id
         WHERE b.user_id=? AND b.status='CONFIRMED' AND s.slot_date>=?`, [req.user.id, today]);
      const [available] = await pool.execute(
        `SELECT COUNT(*) as cnt FROM slots WHERE slot_date>? AND status='AVAILABLE'`, [today]);
      stats.myBookings = myBookings[0].cnt;
      stats.upcomingBookings = upcoming[0].cnt;
      stats.availableSlots = available[0].cnt;
    } else if (req.user.role === 'COACH') {
      const [totalCourts] = await pool.execute("SELECT COUNT(*) as cnt FROM courts WHERE active=1");
      const [totalMembers] = await pool.execute("SELECT COUNT(*) as cnt FROM users WHERE role='MEMBER' AND active=1");
      const [todaySlots] = await pool.execute("SELECT COUNT(*) as cnt FROM slots WHERE slot_date=?", [today]);
      const [tomorrowSlots] = await pool.execute("SELECT COUNT(*) as cnt FROM slots WHERE slot_date=?", [tomorrow]);
      const [todayBookings] = await pool.execute(
        `SELECT COUNT(*) as cnt FROM bookings b JOIN slots s ON b.slot_id=s.id
         WHERE s.slot_date=? AND b.status='CONFIRMED'`, [today]);
      stats.totalCourts = totalCourts[0].cnt;
      stats.totalMembers = totalMembers[0].cnt;
      stats.todaySlots = todaySlots[0].cnt;
      stats.tomorrowSlots = tomorrowSlots[0].cnt;
      stats.todayBookings = todayBookings[0].cnt;
    } else if (req.user.role === 'COURT_INCHARGE') {
      const [totalMembers] = await pool.execute("SELECT COUNT(*) as cnt FROM users WHERE role='MEMBER' AND active=1");
      const [todayBookings] = await pool.execute(
        `SELECT COUNT(*) as cnt FROM bookings b JOIN slots s ON b.slot_id=s.id
         WHERE s.slot_date=? AND b.status='CONFIRMED'`, [today]);
      const [available] = await pool.execute(
        `SELECT COUNT(*) as cnt FROM slots WHERE slot_date>? AND status='AVAILABLE'`, [today]);
      const [guests] = await pool.execute("SELECT COUNT(*) as cnt FROM guest_reservations WHERE status='ACTIVE'");
      stats.totalMembers = totalMembers[0].cnt;
      stats.todayBookings = todayBookings[0].cnt;
      stats.availableSlots = available[0].cnt;
      stats.guestReservations = guests[0].cnt;
    }

    return res.json(stats);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error.' });
  }
}

module.exports = { getStats };
