# SkyArc Badminton Academy — Online Court Slot Booking System

A complete full-stack web application for **SkyArc Badminton Academy** to manage courts, time slots, member bookings, and staff administration.

---

## 🌟 Tech Stack
- **Frontend:** Vanilla HTML5, CSS3, JavaScript (Responsive, modern sports academy theme)
- **Backend:** Node.js, Express.js
- **Database:** MySQL (via `mysql2/promise` with transactions & connection pooling)
- **Authentication:** JWT (JSON Web Tokens) with `bcrypt` (12 rounds) salted password hashing
- **Security:** Parameterized SQL queries, role-based backend authorization, collision prevention, transactional locks

---

## 📁 Project Structure

```text
skyarc-badminton/
├── package.json               # Dependencies and start scripts
├── .env.example               # Template for environment variables
├── .env                       # Local environment variables (create this)
├── README.md                  # Complete documentation and setup guide
│
├── database/
│   └── schema.sql             # MySQL schema with tables, keys & constraints
│
├── server/
│   ├── server.js              # Express app entry point & static server
│   ├── db.js                  # MySQL pool & connection health check
│   ├── middleware/
│   │   └── auth.js            # JWT verification & role-based authorization
│   ├── controllers/
│   │   ├── authController.js      # Login & current user profile
│   │   ├── userController.js      # User management (members, coaches)
│   │   ├── courtController.js     # Court creation, editing & deactivation
│   │   ├── slotController.js      # Slot designer, time checks & copy utility
│   │   ├── bookingController.js   # Slot booking, 7-player capacity, 1-day rule
│   │   ├── timetableController.js # Timetable aggregation by court & time
│   │   ├── guestController.js     # Incharge whole-court guest reservations
│   │   ├── settingsController.js  # Academy settings & batch timings
│   │   └── statsController.js     # Role-specific dashboard statistics
│   ├── routes/
│   │   ├── auth.js            # /api/auth
│   │   ├── users.js           # /api/users
│   │   ├── courts.js          # /api/courts
│   │   ├── slots.js           # /api/slots
│   │   ├── bookings.js        # /api/bookings
│   │   ├── timetable.js       # /api/timetable
│   │   ├── guests.js          # /api/guests
│   │   ├── settings.js        # /api/settings
│   │   └── stats.js           # /api/stats
│   └── seed/
│       └── seed.js            # Creates default development accounts with bcrypt
│
└── public/
    ├── index.html             # Login page with SkyArc branding
    ├── member.html            # Member dashboard, timetable & booking flow
    ├── coach.html             # Coach dashboard & slot designer
    ├── incharge.html          # Court Incharge dashboard, member registration
    ├── css/
    │   └── style.css          # Clean dark green sports academy styling
    ├── js/
    │   ├── common.js          # Shared token auth, modal & format utilities
    │   ├── login.js           # Authentication & role-based redirection
    │   ├── member.js          # Member timetable & booking confirmation
    │   ├── coach.js           # Coach court & slot designer controller
    │   └── incharge.js        # Incharge member & guest management
    └── assets/
        ├── logo.png           # SkyArc official academy logo
        └── court.jpg          # Badminton court background photograph
```

---

## 📋 System Requirements

1. **Node.js** (version 18+ or 20+ recommended) — [Download Node.js](https://nodejs.org/)
2. **MySQL Server** (version 8.0+ recommended) — [Download MySQL Community Server](https://dev.mysql.com/downloads/mysql/) or via XAMPP.

---

## 🚀 Setup Instructions (Step-by-Step for Windows)

### Step 1: Open Terminal in Project Folder
Open PowerShell or Command Prompt, and navigate to the project directory:
```powershell
cd C:\project\skyarc-badminton
```

### Step 2: Install Node Dependencies
Run:
```powershell
npm install
```
This installs `express`, `mysql2`, `bcrypt`, `jsonwebtoken`, `dotenv`, and `cors`.

### Step 3: Configure Environment Variables
Copy `.env.example` to `.env`:
```powershell
Copy-Item .env.example .env
```
Open `.env` in Notepad or VS Code and set your MySQL password:
```ini
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=YOUR_ACTUAL_MYSQL_PASSWORD
DB_NAME=skyarc_db
PORT=3000
JWT_SECRET=skyarc_secret_key_change_in_production
JWT_EXPIRES_IN=8h
```

### Step 4: Create MySQL Database & Run Schema
Open **MySQL Workbench** or your MySQL command line client and execute:
```sql
CREATE DATABASE skyarc_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Then, import the schema file:
- **In MySQL Workbench:** File -> Open SQL Script -> choose `database/schema.sql` -> click the ⚡ Execute button.
- **Or via Command Prompt / PowerShell:**
```powershell
mysql -u root -p skyarc_db < database\schema.sql
```

### Step 5: Seed Default Test Accounts
Populate the development accounts with bcrypt-hashed passwords:
```powershell
node server/seed/seed.js
```
You should see:
```text
✅  Database connected successfully
✅  Seeded user: pranesh_sa (COURT_INCHARGE)
✅  Seeded user: Venkatesh (COACH)
🎉  Seed complete!
```

### Step 6: Start the Server
Run:
```powershell
npm start
```
You should see:
```text
✅  Database connected successfully
🚀  SkyArc server running at http://localhost:3000
📋  Login at http://localhost:3000
```

### Step 7: Access the Website
Open your web browser (Google Chrome, Edge, etc.) and visit:
👉 **[http://localhost:3000](http://localhost:3000)**

---

## 🔑 Test Accounts & Credentials

| Role | Username / Identifier | Password | Access Dashboard |
| :--- | :--- | :--- | :--- |
| **Court Incharge** | `pranesh_sa` *(or praneshsajey@gmail.com)* | `2015672754` | `/incharge.html` |
| **Coach** | `Venkatesh` | `2015672754` | `/coach.html` |

> ⚠️ **Note:** These are test credentials. Always update passwords in production. Passwords are never stored in plaintext — only 12-round bcrypt hashes exist in MySQL.

---

## 🏸 How the System Works

### 1. Initial Academy Configuration (Coach Dashboard)
1. Log in as **Coach** (`Venkatesh` / `2015672754`).
2. Go to **Courts** tab -> Click `+ Add Court` -> e.g. Court Number: `1`, Court Type: `WOODEN`. Add Court `2` (`SYNTHETIC`), etc.
3. Go to **Batch Timings** tab -> Configure morning batch (e.g. `06:00` to `10:00`) and evening batch (e.g. `16:00` to `21:00`).
4. Go to **Slot Designer** tab:
   - Pick tomorrow's date, select Court 1, batch, start time, and end time (e.g. `06:00` to `07:00`).
   - Click `+ Add Slot`.
   - You can copy slots across dates using the **"Copy Slots to Another Date"** feature.

### 2. Member Registration (Court Incharge Dashboard)
1. Log in as **Court Incharge** (`pranesh_sa` / `2015672754`).
2. Go to **Add Member/Coach** tab.
3. Fill in Member details (e.g. Name, unique username, email, password, age, phone).
4. Click **Create Member**.

### 3. Member Slot Booking Flow (Member Dashboard)
1. Log in using the created Member credentials.
2. Go to **Book a Slot** tab.
3. Select tomorrow's date (or any future date). *Note: Same-day booking is automatically rejected by business rules.*
4. The timetable displays each court and time slot with status:
   - `AVAILABLE 0/7`
   - `OPEN 1/7 - Needs 3 more for minimum group`
   - `READY 4/7`
   - `FULL 7/7`
5. Click on an available slot -> Modal opens displaying court details, existing player count, and remaining capacity.
6. Click **[BOOK THE SLOT]** -> Backend acquires a row lock, validates capacity $\le 7$, enforces no time collisions, records first-come-first-served timestamp, and confirms the booking immediately.

### 4. Staff Reservations
- **Coach:** Can reserve whole courts for training or priority sessions. Supersedes member slots.
- **Court Incharge:** Can reserve whole courts for guest groups from the **Guests** tab.

---

## 🛠️ Where to Change or Replace Images
The images are located in:
```text
public/assets/
├── logo.png     <-- SkyArc Badminton Academy logo
└── court.jpg    <-- Badminton court photograph
```
To update the logo or court background, simply replace these two files in `public/assets/`. Ensure file names match or update references in `index.html`, `member.html`, `coach.html`, `incharge.html`, and `style.css`.

---

## 🛑 How to Stop the Server
In PowerShell / Command Prompt, press:
```powershell
Ctrl + C
```
Type `Y` and press Enter when prompted.
