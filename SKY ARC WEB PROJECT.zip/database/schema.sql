-- ============================================================
-- SkyArc Badminton Academy - Database Schema
-- Run this file in MySQL after creating the database:
--   CREATE DATABASE skyarc_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
--   USE skyarc_db;
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;

-- Drop tables if they exist (for re-runs)
DROP TABLE IF EXISTS tournament_standings;
DROP TABLE IF EXISTS match_results;
DROP TABLE IF EXISTS tournament_matches;
DROP TABLE IF EXISTS tournament_stages;
DROP TABLE IF EXISTS tournament_registrations;
DROP TABLE IF EXISTS tournament_categories;
DROP TABLE IF EXISTS tournaments;
DROP TABLE IF EXISTS referees;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS guest_reservations;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS slots;
DROP TABLE IF EXISTS batch_timings;
DROP TABLE IF EXISTS courts;
DROP TABLE IF EXISTS academy_settings;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- USERS
-- ============================================================
CREATE TABLE users (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    username    VARCHAR(50)  NOT NULL,
    email       VARCHAR(150) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    age         TINYINT UNSIGNED,
    role        ENUM('MEMBER','COACH','COURT_INCHARGE','REFEREE') NOT NULL DEFAULT 'MEMBER',
    phone       VARCHAR(20),
    date_of_joining DATE,
    active      TINYINT(1) NOT NULL DEFAULT 1,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_username (username),
    INDEX idx_email (email),
    INDEX idx_role  (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- ACADEMY SETTINGS (key-value store)
-- ============================================================
CREATE TABLE academy_settings (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL,
    setting_val TEXT,
    updated_by  INT UNSIGNED,
    updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_key (setting_key),
    FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- COURTS
-- ============================================================
CREATE TABLE courts (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    court_number VARCHAR(20) NOT NULL,
    court_name  VARCHAR(100),
    court_type  ENUM('WOODEN','SYNTHETIC','OTHER') NOT NULL DEFAULT 'WOODEN',
    active      TINYINT(1) NOT NULL DEFAULT 1,
    created_by  INT UNSIGNED,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_court_number (court_number),
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- BATCH TIMINGS
-- ============================================================
CREATE TABLE batch_timings (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    batch_name  ENUM('MORNING','EVENING') NOT NULL,
    open_time   TIME NOT NULL,
    close_time  TIME NOT NULL,
    active      TINYINT(1) NOT NULL DEFAULT 1,
    updated_by  INT UNSIGNED,
    updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_batch (batch_name),
    FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- SLOTS
-- ============================================================
CREATE TABLE slots (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    court_id    INT UNSIGNED NOT NULL,
    batch       ENUM('MORNING','EVENING') NOT NULL,
    slot_date   DATE NOT NULL,
    start_time  TIME NOT NULL,
    end_time    TIME NOT NULL,
    max_capacity TINYINT UNSIGNED NOT NULL DEFAULT 7,
    status      ENUM('AVAILABLE','UNAVAILABLE','CLOSED','COACH_RESERVED','INCHARGE_RESERVED') NOT NULL DEFAULT 'AVAILABLE',
    created_by  INT UNSIGNED,
    notes       VARCHAR(255),
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (court_id)   REFERENCES courts(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id)  ON DELETE SET NULL,
    -- Prevent overlapping slots for same court on same date
    INDEX idx_slot_lookup (court_id, slot_date, batch),
    INDEX idx_slot_date   (slot_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- BOOKINGS
-- ============================================================
CREATE TABLE bookings (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    slot_id       INT UNSIGNED NOT NULL,
    user_id       INT UNSIGNED NOT NULL,
    booking_type  ENUM('MEMBER','COACH','GUEST','INCHARGE') NOT NULL DEFAULT 'MEMBER',
    status        ENUM('CONFIRMED','CANCELLED','WAITLISTED') NOT NULL DEFAULT 'CONFIRMED',
    guest_count   TINYINT UNSIGNED DEFAULT 0,
    notes         VARCHAR(255),
    booked_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    cancelled_at  DATETIME,
    cancelled_by  INT UNSIGNED,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (slot_id)      REFERENCES slots(id)  ON DELETE CASCADE,
    FOREIGN KEY (user_id)      REFERENCES users(id)  ON DELETE CASCADE,
    FOREIGN KEY (cancelled_by) REFERENCES users(id)  ON DELETE SET NULL,
    -- A user can only have ONE active booking per slot
    UNIQUE KEY uq_user_slot (user_id, slot_id),
    INDEX idx_slot_bookings (slot_id, status),
    INDEX idx_user_bookings (user_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- GUEST RESERVATIONS
-- ============================================================
CREATE TABLE guest_reservations (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    slot_id     INT UNSIGNED NOT NULL,
    reserved_by INT UNSIGNED NOT NULL,
    guest_count TINYINT UNSIGNED NOT NULL DEFAULT 1,
    guest_info  VARCHAR(255),
    notes       VARCHAR(255),
    status      ENUM('ACTIVE','CANCELLED') NOT NULL DEFAULT 'ACTIVE',
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (slot_id)     REFERENCES slots(id) ON DELETE CASCADE,
    FOREIGN KEY (reserved_by) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- AUDIT LOGS
-- ============================================================
CREATE TABLE audit_logs (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED,
    action      VARCHAR(100) NOT NULL,
    entity      VARCHAR(50),
    entity_id   INT UNSIGNED,
    details     TEXT,
    ip_address  VARCHAR(45),
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_audit_user   (user_id),
    INDEX idx_audit_action (action),
    INDEX idx_audit_date   (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- DEFAULT SETTINGS
-- ============================================================
INSERT INTO academy_settings (setting_key, setting_val) VALUES
('booking_advance_days', '1'),
('max_court_capacity',   '7'),
('min_court_capacity',   '4'),
('academy_name',         'SkyArc Badminton Academy'),
('academy_tagline',      'Building Tomorrows Athletes Today');

-- ============================================================
-- REFEREES (Rule 9 & 10)
-- ============================================================
CREATE TABLE IF NOT EXISTS referees (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id       INT UNSIGNED NULL,
    name          VARCHAR(100) NOT NULL,
    email         VARCHAR(150),
    phone         VARCHAR(20),
    qualification VARCHAR(150),
    experience    VARCHAR(100),
    availability  VARCHAR(255) DEFAULT 'AVAILABLE',
    status        ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TOURNAMENTS (Rule 1 & 29)
-- ============================================================
CREATE TABLE IF NOT EXISTS tournaments (
    id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name                  VARCHAR(200) NOT NULL,
    description           TEXT,
    format                ENUM('LEAGUE','KNOCKOUT','NESTED_LEAGUE','KNOCKOUT_TO_LEAGUE','POOL_KNOCKOUT') NOT NULL DEFAULT 'KNOCKOUT',
    start_date            DATE NOT NULL,
    end_date              DATE NOT NULL,
    venue                 VARCHAR(150) NOT NULL,
    timing                VARCHAR(100) NOT NULL,
    food_provided         TINYINT(1) NOT NULL DEFAULT 0,
    poster_url            VARCHAR(255) NULL,
    status                ENUM('DRAFT','REGISTRATION_OPEN','REGISTRATION_CLOSED','UPCOMING','ONGOING','COMPLETED','CANCELLED') NOT NULL DEFAULT 'DRAFT',
    registration_deadline DATE NULL,
    format_config         JSON NULL,
    winner_id             INT UNSIGNED NULL,
    runner_up_id          INT UNSIGNED NULL,
    created_by            INT UNSIGNED NOT NULL,
    created_at            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TOURNAMENT CATEGORIES (Singles & Doubles)
-- ============================================================
CREATE TABLE IF NOT EXISTS tournament_categories (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    tournament_id     INT UNSIGNED NOT NULL,
    category_name     ENUM('MENS_SINGLES','WOMENS_SINGLES','MENS_DOUBLES','WOMENS_DOUBLES','MIXED_DOUBLES') NOT NULL,
    display_name      VARCHAR(100) NOT NULL,
    type              ENUM('SINGLES','DOUBLES') NOT NULL,
    winner_team_id    INT UNSIGNED NULL,
    runner_up_team_id INT UNSIGNED NULL,
    created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
    UNIQUE KEY uq_tourn_cat (tournament_id, category_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TOURNAMENT REGISTRATIONS (Duplicate & Doubles validation)
-- ============================================================
CREATE TABLE IF NOT EXISTS tournament_registrations (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    tournament_id       INT UNSIGNED NOT NULL,
    category_id         INT UNSIGNED NOT NULL,
    member_id           INT UNSIGNED NOT NULL,
    partner_id          INT UNSIGNED NULL,
    team_name           VARCHAR(255) NOT NULL,
    pair_identifier     VARCHAR(100) NOT NULL,
    registration_status ENUM('CONFIRMED','CANCELLED') NOT NULL DEFAULT 'CONFIRMED',
    group_name          VARCHAR(50) NULL,
    seed                INT NULL,
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES tournament_categories(id) ON DELETE CASCADE,
    FOREIGN KEY (member_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (partner_id) REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE KEY uq_cat_pair (category_id, pair_identifier),
    INDEX idx_member (member_id),
    INDEX idx_partner (partner_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TOURNAMENT STAGES (Knockout, League, Pool)
-- ============================================================
CREATE TABLE IF NOT EXISTS tournament_stages (
    id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    tournament_id  INT UNSIGNED NOT NULL,
    category_id    INT UNSIGNED NOT NULL,
    stage_name     VARCHAR(100) NOT NULL,
    stage_type     ENUM('KNOCKOUT','LEAGUE','POOL') NOT NULL,
    group_name     VARCHAR(50) NULL,
    sequence_order INT NOT NULL DEFAULT 1,
    status         ENUM('UPCOMING','ONGOING','COMPLETED') NOT NULL DEFAULT 'UPCOMING',
    created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES tournament_categories(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TOURNAMENT MATCHES (Fixtures, Courts, Referees)
-- ============================================================
CREATE TABLE IF NOT EXISTS tournament_matches (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    tournament_id   INT UNSIGNED NOT NULL,
    category_id     INT UNSIGNED NOT NULL,
    stage_id        INT UNSIGNED NULL,
    round_name      VARCHAR(100) NOT NULL,
    round_number    INT NOT NULL DEFAULT 1,
    match_number    INT NOT NULL,
    team1_id        INT UNSIGNED NULL,
    team2_id        INT UNSIGNED NULL,
    is_bye          TINYINT(1) NOT NULL DEFAULT 0,
    scheduled_date  DATE NULL,
    scheduled_time  TIME NULL,
    court_id        INT UNSIGNED NULL,
    referee_id      INT UNSIGNED NULL,
    status          ENUM('SCHEDULED','ONGOING','COMPLETED','CANCELLED','BYE') NOT NULL DEFAULT 'SCHEDULED',
    winner_id       INT UNSIGNED NULL,
    loser_id        INT UNSIGNED NULL,
    man_of_match    VARCHAR(100) NULL,
    next_match_id   INT UNSIGNED NULL,
    next_match_slot ENUM('TEAM1','TEAM2') NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at    DATETIME NULL,
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES tournament_categories(id) ON DELETE CASCADE,
    FOREIGN KEY (stage_id) REFERENCES tournament_stages(id) ON DELETE SET NULL,
    FOREIGN KEY (team1_id) REFERENCES tournament_registrations(id) ON DELETE SET NULL,
    FOREIGN KEY (team2_id) REFERENCES tournament_registrations(id) ON DELETE SET NULL,
    FOREIGN KEY (court_id) REFERENCES courts(id) ON DELETE SET NULL,
    FOREIGN KEY (referee_id) REFERENCES referees(id) ON DELETE SET NULL,
    FOREIGN KEY (winner_id) REFERENCES tournament_registrations(id) ON DELETE SET NULL,
    FOREIGN KEY (loser_id) REFERENCES tournament_registrations(id) ON DELETE SET NULL,
    FOREIGN KEY (next_match_id) REFERENCES tournament_matches(id) ON DELETE SET NULL,
    INDEX idx_sched_court (court_id, scheduled_date, scheduled_time),
    INDEX idx_sched_ref (referee_id, scheduled_date, scheduled_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- MATCH RESULTS (Locked Result System)
-- ============================================================
CREATE TABLE IF NOT EXISTS match_results (
    id                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    match_id             INT UNSIGNED NOT NULL,
    team1_score          INT NOT NULL DEFAULT 0,
    team2_score          INT NOT NULL DEFAULT 0,
    scores_detail        VARCHAR(100) NULL,
    winner_id            INT UNSIGNED NOT NULL,
    submitted_by_user_id INT UNSIGNED NOT NULL,
    submitted_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    locked_at            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_locked            TINYINT(1) NOT NULL DEFAULT 1,
    man_of_match         VARCHAR(100) NULL,
    duration_minutes     INT NULL,
    remarks              TEXT NULL,
    FOREIGN KEY (match_id) REFERENCES tournament_matches(id) ON DELETE CASCADE,
    FOREIGN KEY (winner_id) REFERENCES tournament_registrations(id) ON DELETE CASCADE,
    FOREIGN KEY (submitted_by_user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uq_match_res (match_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TOURNAMENT STANDINGS (League, Pool, Hybrid)
-- ============================================================
CREATE TABLE IF NOT EXISTS tournament_standings (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    tournament_id   INT UNSIGNED NOT NULL,
    category_id     INT UNSIGNED NOT NULL,
    stage_id        INT UNSIGNED NULL,
    group_name      VARCHAR(50) NOT NULL DEFAULT 'MAIN',
    team_id         INT UNSIGNED NOT NULL,
    played          INT NOT NULL DEFAULT 0,
    won             INT NOT NULL DEFAULT 0,
    lost            INT NOT NULL DEFAULT 0,
    points          INT NOT NULL DEFAULT 0,
    points_scored   INT NOT NULL DEFAULT 0,
    points_conceded INT NOT NULL DEFAULT 0,
    point_diff      INT NOT NULL DEFAULT 0,
    rank_position   INT NOT NULL DEFAULT 0,
    qualified       TINYINT(1) NOT NULL DEFAULT 0,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES tournament_categories(id) ON DELETE CASCADE,
    FOREIGN KEY (stage_id) REFERENCES tournament_stages(id) ON DELETE CASCADE,
    FOREIGN KEY (team_id) REFERENCES tournament_registrations(id) ON DELETE CASCADE,
    UNIQUE KEY uq_group_team (stage_id, group_name, team_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
