/**
 * tournament-details.js — Dedicated standalone Tournament Details & Fixtures Page
 */

let currentTournament = null;
let currentTournamentId = null;
let currentCategoryFilter = '';
let tournamentFixtures = [];
let tournamentParticipants = [];
let tournamentStandings = [];

document.addEventListener('DOMContentLoaded', async () => {
  const urlParams = new URLSearchParams(window.location.search);
  currentTournamentId = urlParams.get('id');

  if (!currentTournamentId) {
    alert('No tournament specified.');
    window.location.href = '/events.html';
    return;
  }

  setupNavAndAuth();
  await loadTournamentAll();

  // Check URL hash for direct tab navigation (e.g. #participants or #fixtures)
  const hash = window.location.hash.replace('#', '');
  if (hash && ['fixtures', 'standings', 'participants', 'results'].includes(hash)) {
    const btn = document.querySelector(`.t-tab-btn[data-tab="${hash}"]`);
    if (btn) switchMainTab(hash, btn);
  }
});

function setupNavAndAuth() {
  const user = getUser();
  const navUser = document.getElementById('navUserName');
  const authBtn = document.getElementById('authBtn');
  const navDash = document.getElementById('navDashboardLink');
  const coachNav = document.getElementById('coachNavTournaments');

  if (user) {
    if (navUser) navUser.textContent = `${user.name || user.username} (${user.role})`;
    if (authBtn) {
      authBtn.textContent = 'Logout';
      authBtn.onclick = logout;
    }
    if (navDash) {
      if (user.role === 'COACH') navDash.href = '/coach.html';
      else if (user.role === 'COURT_INCHARGE') navDash.href = '/incharge.html';
      else if (user.role === 'REFEREE') navDash.href = '/referee.html';
      else navDash.href = '/member.html';
    }
    if (user.role === 'COACH' && coachNav) {
      coachNav.classList.remove('hidden');
    }
  } else {
    if (navUser) navUser.textContent = 'Guest';
    if (authBtn) {
      authBtn.textContent = 'Login';
      authBtn.onclick = () => window.location.href = '/';
    }
    if (navDash) navDash.href = '/';
  }
}

async function loadTournamentAll() {
  const alertBox = 'detailsAlert';
  hideAlert(alertBox);

  try {
    currentTournament = await apiFetch(`/api/tournaments/${currentTournamentId}`);
    renderTournamentHero(currentTournament);
    setupRoleControls(currentTournament);
    renderCategoryTabs(currentTournament.categories || []);

    // Load sub-resources in parallel
    await Promise.all([
      loadFixtures(),
      loadStandings(),
      loadParticipants()
    ]);

    document.getElementById('loadingTournament').classList.add('hidden');
    document.getElementById('tournamentContent').classList.remove('hidden');

  } catch (err) {
    console.error('Failed to load tournament:', err);
    document.getElementById('loadingTournament').innerHTML = `
      <div class="alert alert-danger" style="max-width: 600px; margin: 0 auto;">
        ${err.message || 'Unable to load tournament details.'}
        <div style="margin-top: 1rem;">
          <a href="/events.html" class="btn btn-secondary btn-sm">Return to Events</a>
        </div>
      </div>
    `;
  }
}

function renderTournamentHero(t) {
  document.getElementById('tHeroTitle').textContent = t.name;
  document.getElementById('tHeroDesc').textContent = t.description || 'Official SkyArc Badminton Academy Tournament.';
  document.getElementById('tHeroFormat').textContent = t.format.replace(/_/g, ' ');
  document.getElementById('tHeroVenue').textContent = t.venue;
  document.getElementById('tHeroDates').textContent = `${fmtDate(t.start_date)} – ${fmtDate(t.end_date)}`;
  document.getElementById('tHeroTiming').textContent = t.timing;

  const foodEl = document.getElementById('tHeroFood');
  if (foodEl) {
    foodEl.textContent = t.food_provided ? '🥗 Refreshments Provided' : '🥤 Water Provided';
  }

  const statusBadge = document.getElementById('tHeroStatus');
  if (statusBadge) {
    const statusMap = {
      DRAFT: 'badge-gray',
      REGISTRATION_OPEN: 'badge-green',
      REGISTRATION_CLOSED: 'badge-gold',
      ONGOING: 'badge-blue',
      COMPLETED: 'badge-gold',
      CANCELLED: 'badge-red'
    };
    statusBadge.className = `badge ${statusMap[t.status] || 'badge-gray'}`;
    statusBadge.textContent = t.status.replace(/_/g, ' ');
  }

  // Poster image
  const posterCol = document.getElementById('tHeroPosterCol');
  const posterImg = document.getElementById('tHeroPoster');
  if (t.poster_url && posterCol && posterImg) {
    posterImg.src = t.poster_url;
    posterCol.classList.remove('hidden');
  }
}

function setupRoleControls(t) {
  const user = getUser();
  const coachCard = document.getElementById('coachControlsCard');
  const memberCTA = document.getElementById('memberRegCTA');

  if (user && user.role === 'COACH') {
    if (coachCard) coachCard.classList.remove('hidden');

    const pubBtn = document.getElementById('coachPublishBtn');
    if (pubBtn) {
      if (t.status === 'DRAFT') pubBtn.classList.remove('hidden');
      else pubBtn.classList.add('hidden');
    }

    const endBtn = document.getElementById('coachEndBtn');
    if (endBtn) {
      if (t.status === 'COMPLETED') endBtn.classList.add('hidden');
      else endBtn.classList.remove('hidden');
    }
  }

  if (user && user.role === 'MEMBER' && t.status === 'REGISTRATION_OPEN') {
    if (memberCTA) memberCTA.classList.remove('hidden');
  }
}

function renderCategoryTabs(categories) {
  const container = document.getElementById('categoryPillTabs');
  if (!container) return;

  let html = `
    <button class="btn btn-sm ${currentCategoryFilter === '' ? 'btn-primary' : 'btn-secondary'}" onclick="filterByCategory('')">
      All Categories
    </button>
  `;

  categories.forEach(c => {
    const active = currentCategoryFilter === String(c.id);
    html += `
      <button class="btn btn-sm ${active ? 'btn-primary' : 'btn-secondary'}" onclick="filterByCategory('${c.id}')">
        ${c.display_name}
      </button>
    `;
  });

  container.innerHTML = html;
}

function filterByCategory(catId) {
  currentCategoryFilter = catId;
  renderCategoryTabs(currentTournament.categories || []);
  renderFixtures();
  renderStandings();
  renderParticipants();
  renderResults();
}

function switchMainTab(tabName, btn) {
  document.querySelectorAll('.t-tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.t-tab-pane').forEach(p => p.classList.remove('active'));

  if (btn) btn.classList.add('active');
  const pane = document.getElementById(`pane-${tabName}`);
  if (pane) pane.classList.add('active');

  // Update hash without jumping
  history.replaceState(null, null, `#${tabName}`);
}

// ── 1. Fixtures ────────────────────────────────────────────
async function loadFixtures() {
  try {
    tournamentFixtures = await apiFetch(`/api/tournaments/${currentTournamentId}/fixtures`);
    renderFixtures();
    renderResults();
  } catch (err) {
    console.error('loadFixtures error:', err);
    document.getElementById('fixturesContainer').innerHTML = `<p class="alert alert-danger">${err.message}</p>`;
  }
}

function renderFixtures() {
  const container = document.getElementById('fixturesContainer');
  if (!container) return;

  let matches = tournamentFixtures;
  if (currentCategoryFilter) {
    matches = matches.filter(m => String(m.category_id) === String(currentCategoryFilter));
  }

  if (!matches.length) {
    container.innerHTML = `
      <div class="card text-center text-muted" style="padding: 2.5rem;">
        <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">🏸</div>
        <h3>No Fixtures Generated Yet</h3>
        <p>Fixtures will appear once participant registration completes and the coach generates the schedule.</p>
      </div>
    `;
    return;
  }

  // Group by category, then by round
  const byCat = {};
  matches.forEach(m => {
    const catName = m.category_display || m.category_name;
    if (!byCat[catName]) byCat[catName] = {};
    if (!byCat[catName][m.round_name]) byCat[catName][m.round_name] = [];
    byCat[catName][m.round_name].push(m);
  });

  let html = '';
  Object.keys(byCat).forEach(catName => {
    html += `
      <div class="card mb-2">
        <div class="card-header" style="background: var(--off-white);">
          <h3>${catName} — Matches &amp; Brackets</h3>
        </div>
        <div class="d-flex gap-2 flex-wrap" style="padding: 1rem; align-items: flex-start; overflow-x: auto;">
    `;

    const rounds = byCat[catName];
    Object.keys(rounds).forEach(roundName => {
      html += `
        <div class="bracket-round-col">
          <div class="bracket-round-header">
            <span>${roundName}</span>
            <span>${rounds[roundName].length} Match${rounds[roundName].length > 1 ? 'es' : ''}</span>
          </div>
      `;

      rounds[roundName].forEach(m => {
        const isCompleted = m.status === 'COMPLETED';
        const isBye = m.is_bye;
        const team1Winner = m.winner_id && m.winner_id === m.team1_id;
        const team2Winner = m.winner_id && m.winner_id === m.team2_id;

        html += `
          <div class="match-card ${isCompleted ? 'is-completed' : ''} ${isBye ? 'is-bye' : ''}">
            <div style="display:flex; justify-content:space-between; margin-bottom:0.35rem;">
              <small class="badge badge-gray" style="font-size:0.7rem;">Match #${m.match_number}</small>
              <small class="badge ${isCompleted ? 'badge-green' : (isBye ? 'badge-blue' : 'badge-gold')}" style="font-size:0.7rem;">
                ${m.status}
              </small>
            </div>

            <div class="match-team-row ${team1Winner ? 'winner' : ''}">
              <span>${team1Winner ? '🏆 ' : ''}${m.team1_name || 'TBD'}</span>
              <span><strong>${m.team1_score !== null && m.team1_score !== undefined ? m.team1_score : '—'}</strong></span>
            </div>

            <div class="match-team-row ${team2Winner ? 'winner' : ''}">
              <span>${team2Winner ? '🏆 ' : ''}${m.team2_name || (isBye ? 'BYE' : 'TBD')}</span>
              <span><strong>${m.team2_score !== null && m.team2_score !== undefined ? m.team2_score : '—'}</strong></span>
            </div>

            <div class="match-meta-footer">
              <span>🏟️ ${m.court_name ? 'Court ' + m.court_name : 'Court TBD'}</span>
              <span>${m.scheduled_date ? fmtDate(m.scheduled_date) : 'Date TBD'}${m.scheduled_time ? ' • ' + fmtTime(m.scheduled_time) : ''}</span>
            </div>
            ${m.referee_name ? `<div style="font-size:0.72rem; color:var(--green-mid); margin-top:0.25rem;">⚖️ Referee: ${m.referee_name}</div>` : ''}
          </div>
        `;
      });

      html += `</div>`; // bracket-round-col
    });

    html += `
        </div>
      </div>
    `;
  });

  container.innerHTML = html;
}

// ── 2. Standings ───────────────────────────────────────────
async function loadStandings() {
  try {
    tournamentStandings = await apiFetch(`/api/tournaments/${currentTournamentId}/standings`);
    renderStandings();
  } catch (err) {
    console.error('loadStandings error:', err);
    document.getElementById('standingsContainer').innerHTML = `<p class="alert alert-danger">${err.message}</p>`;
  }
}

function renderStandings() {
  const container = document.getElementById('standingsContainer');
  const tabBtn = document.getElementById('standingsTabBtn');
  if (!container) return;

  let list = tournamentStandings;
  if (currentCategoryFilter) {
    list = list.filter(s => String(s.category_id) === String(currentCategoryFilter));
  }

  if (!list.length) {
    container.innerHTML = `
      <div class="card text-center text-muted" style="padding: 2rem;">
        <p>No league or pool standings available for this tournament format/category.</p>
      </div>
    `;
    return;
  }

  // Group by category and stage/group
  const byGroup = {};
  list.forEach(row => {
    const key = `${row.category_display || row.category_name} — ${row.group_name || 'Group A'}`;
    if (!byGroup[key]) byGroup[key] = [];
    byGroup[key].push(row);
  });

  let html = '';
  Object.keys(byGroup).forEach(groupTitle => {
    html += `
      <div class="standings-table-wrap">
        <div class="group-title-header">
          <span>${groupTitle}</span>
          <span style="font-size:0.85rem; font-weight:normal; opacity:0.85;">Official Points Table</span>
        </div>
        <div class="table-wrapper" style="margin:0;">
          <table>
            <thead>
              <tr>
                <th>Rank</th>
                <th>Team / Player</th>
                <th>Played</th>
                <th>Won</th>
                <th>Lost</th>
                <th>Points</th>
                <th>Score Diff</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
    `;

    byGroup[groupTitle].forEach((row, i) => {
      const isQual = row.qualified || i < 2;
      html += `
        <tr>
          <td><strong>#${row.rank_position || i + 1}</strong></td>
          <td><strong>${row.team_name}</strong></td>
          <td>${row.played}</td>
          <td><span class="text-green">${row.won}</span></td>
          <td><span class="text-danger">${row.lost}</span></td>
          <td><span class="badge badge-green">${row.points} pts</span></td>
          <td>${row.point_diff > 0 ? '+' + row.point_diff : row.point_diff}</td>
          <td>${isQual ? '<span class="badge badge-gold">⭐ Qualified</span>' : '—'}</td>
        </tr>
      `;
    });

    html += `
            </tbody>
          </table>
        </div>
      </div>
    `;
  });

  container.innerHTML = html;
}

// ── 3. Participants ────────────────────────────────────────
async function loadParticipants() {
  try {
    tournamentParticipants = await apiFetch(`/api/tournaments/${currentTournamentId}/participants`);
    const countEl = document.getElementById('tabPartCount');
    if (countEl) countEl.textContent = tournamentParticipants.length;
    renderParticipants();
  } catch (err) {
    console.error('loadParticipants error:', err);
    document.getElementById('participantsTableBody').innerHTML = `<tr><td colspan="7" class="alert alert-danger">${err.message}</td></tr>`;
  }
}

function renderParticipants() {
  const tbody = document.getElementById('participantsTableBody');
  const badge = document.getElementById('partCategoryBadge');
  if (!tbody) return;

  let list = tournamentParticipants;
  if (currentCategoryFilter) {
    list = list.filter(p => String(p.category_id) === String(currentCategoryFilter));
    if (badge && currentTournament.categories) {
      const c = currentTournament.categories.find(x => String(x.id) === String(currentCategoryFilter));
      badge.textContent = c ? c.display_name : 'Filtered Category';
    }
  } else {
    if (badge) badge.textContent = 'All Categories';
  }

  if (!list.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No participants registered in this category yet.</td></tr>';
    return;
  }

  let html = '';
  list.forEach((p, i) => {
    html += `
      <tr>
        <td>${i + 1}</td>
        <td><span class="badge badge-blue">${p.category_display || p.category_name}</span></td>
        <td><strong>${p.team_name}</strong></td>
        <td>${p.player1_name || '—'}</td>
        <td>${p.player2_name ? p.player2_name : '<span class="text-muted">— (Singles)</span>'}</td>
        <td>${p.group_name ? `<span class="badge badge-gray">${p.group_name}</span>` : '—'}</td>
        <td><span class="badge badge-green">${p.registration_status || 'CONFIRMED'}</span></td>
      </tr>
    `;
  });

  tbody.innerHTML = html;
}

// ── 4. Completed Results ───────────────────────────────────
function renderResults() {
  const tbody = document.getElementById('resultsTableBody');
  if (!tbody) return;

  let completed = tournamentFixtures.filter(m => m.status === 'COMPLETED');
  if (currentCategoryFilter) {
    completed = completed.filter(m => String(m.category_id) === String(currentCategoryFilter));
  }

  if (!completed.length) {
    tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">No completed matches recorded yet.</td></tr>';
    return;
  }

  let html = '';
  completed.forEach((m, i) => {
    const winnerName = m.winner_id === m.team1_id ? m.team1_name : (m.winner_id === m.team2_id ? m.team2_name : '—');
    const scoreStr = m.scores_detail || `${m.team1_score || 0} - ${m.team2_score || 0}`;

    html += `
      <tr>
        <td>${i + 1}</td>
        <td><span class="badge badge-blue">${m.category_display || m.category_name}</span></td>
        <td>${m.round_name}</td>
        <td><strong>${m.team1_name}</strong></td>
        <td><span class="badge badge-gold">${scoreStr}</span></td>
        <td><strong>${m.team2_name}</strong></td>
        <td><strong class="text-green">🏆 ${winnerName}</strong></td>
        <td>${m.completed_at ? fmtDateTime(m.completed_at) : (m.scheduled_date ? fmtDate(m.scheduled_date) : '—')}</td>
      </tr>
    `;
  });

  tbody.innerHTML = html;
}

// ── Coach Actions ──────────────────────────────────────────
async function actionPublishTournament() {
  if (!confirm('Publish this tournament? It will immediately appear in Events and open for registration.')) return;
  try {
    const res = await apiFetch(`/api/tournaments/${currentTournamentId}/publish`, { method: 'POST' });
    showAlert('detailsAlert', res.message || 'Tournament published successfully!', 'success');
    await loadTournamentAll();
  } catch (err) {
    showAlert('detailsAlert', err.message || 'Failed to publish tournament.', 'danger');
  }
}

async function actionGenerateFixtures() {
  if (!confirm('Generate fixtures and brackets for this tournament? Courts and referees will be scheduled automatically.')) return;
  try {
    const res = await apiFetch(`/api/tournaments/${currentTournamentId}/generate-fixtures`, { method: 'POST' });
    showAlert('detailsAlert', res.message || 'Fixtures generated successfully!', 'success');
    await loadFixtures();
    await loadStandings();
  } catch (err) {
    showAlert('detailsAlert', err.message || 'Failed to generate fixtures.', 'danger');
  }
}

async function actionEndTournament() {
  const c1 = confirm('Step 1 of 2: Are you sure you want to officially END this tournament?');
  if (!c1) return;
  const c2 = confirm('Step 2 of 2: Final Confirmation: End tournament, declare final standings and lock all results?');
  if (!c2) return;

  try {
    const res = await apiFetch(`/api/tournaments/${currentTournamentId}/end`, {
      method: 'POST',
      body: JSON.stringify({ confirm: true, second_confirm: true })
    });
    showAlert('detailsAlert', res.message || 'Tournament concluded successfully!', 'success');
    await loadTournamentAll();
  } catch (err) {
    showAlert('detailsAlert', err.message || 'Failed to conclude tournament.', 'danger');
  }
}

async function actionDeleteTournament() {
  const c1 = confirm(`⚠️ DANGER: Are you sure you want to permanently DELETE the tournament "${currentTournament.name}"?\n\nThis will remove all fixtures, registrations, standings and results!`);
  if (!c1) return;

  const c2 = confirm(`Final confirmation: Really delete "${currentTournament.name}"? This action cannot be undone.`);
  if (!c2) return;

  try {
    const res = await apiFetch(`/api/tournaments/${currentTournamentId}`, {
      method: 'DELETE'
    });
    alert(res.message || 'Tournament deleted successfully.');
    window.location.href = '/events.html';
  } catch (err) {
    showAlert('detailsAlert', err.message || 'Failed to delete tournament.', 'danger');
  }
}

// ── Member Registration ────────────────────────────────────
function openMemberRegistrationModal() {
  const user = getUser();
  if (!user) {
    alert('Please log in to register.');
    window.location.href = '/';
    return;
  }

  document.getElementById('regMemberName').value = user.name || user.username;
  const catSelect = document.getElementById('regCategorySelect');
  catSelect.innerHTML = '<option value="">Select category...</option>';

  (currentTournament.categories || []).forEach(c => {
    catSelect.innerHTML += `<option value="${c.id}" data-type="${c.type}">${c.display_name}</option>`;
  });

  hideAlert('regAlert');
  document.getElementById('regPartnerGroup').classList.add('hidden');
  openModal('registrationModal');
}

async function onCategorySelectChange() {
  const select = document.getElementById('regCategorySelect');
  const partnerGroup = document.getElementById('regPartnerGroup');
  const partnerSelect = document.getElementById('regPartnerSelect');
  const opt = select.options[select.selectedIndex];
  const type = opt ? opt.getAttribute('data-type') : '';

  if (type === 'DOUBLES') {
    partnerGroup.classList.remove('hidden');
    partnerSelect.innerHTML = '<option value="">Loading academy members...</option>';
    try {
      const members = await apiFetch('/api/users?role=MEMBER&active=1');
      const currentUser = getUser();
      partnerSelect.innerHTML = '<option value="">Select partner member...</option>';
      members.filter(m => m.id !== currentUser.id).forEach(m => {
        partnerSelect.innerHTML += `<option value="${m.id}">${m.name || m.username} (${m.username})</option>`;
      });
    } catch (err) {
      partnerSelect.innerHTML = '<option value="">Failed to load members</option>';
    }
  } else {
    partnerGroup.classList.add('hidden');
  }
}

async function submitTournamentRegistration() {
  hideAlert('regAlert');
  const category_id = document.getElementById('regCategorySelect').value;
  const partnerSelect = document.getElementById('regPartnerSelect');
  const partner_id = !document.getElementById('regPartnerGroup').classList.contains('hidden') ? partnerSelect.value : null;

  if (!category_id) {
    showAlert('regAlert', 'Please select a tournament category.');
    return;
  }

  const btn = document.getElementById('submitRegBtn');
  btn.disabled = true;
  btn.textContent = 'Registering...';

  try {
    const res = await apiFetch(`/api/tournaments/${currentTournamentId}/register`, {
      method: 'POST',
      body: JSON.stringify({ category_id, partner_id })
    });
    alert(res.message || 'Registration confirmed!');
    closeModal('registrationModal');
    await loadParticipants();
  } catch (err) {
    showAlert('regAlert', err.message || 'Registration failed.');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Submit Entry';
  }
}
