/**
 * login.js — Login controller
 */

(function () {
  const token = localStorage.getItem('skyarc_token');
  const user = JSON.parse(localStorage.getItem('skyarc_user') || 'null');
  if (token && user) {
    redirectByRole(user.role);
  }
})();

function redirectByRole(role) {
  if (role === 'COURT_INCHARGE') window.location.href = '/incharge.html';
  else if (role === 'COACH') window.location.href = '/coach.html';
  else if (role === 'REFEREE') window.location.href = '/referee.html';
  else window.location.href = '/member.html';
}

document.getElementById('loginForm').addEventListener('submit', async function (e) {
  e.preventDefault();
  const btn = document.getElementById('loginBtn');
  const identifier = document.getElementById('identifier').value.trim();
  const password = document.getElementById('password').value;

  hideAlert('loginAlert');

  if (!identifier || !password) {
    showAlert('loginAlert', 'Please enter username/email and password.');
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Logging in...';

  try {
    const data = await apiFetch('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username: identifier, password })
    });

    saveAuth(data.token, data.user);
    redirectByRole(data.user.role);
  } catch (err) {
    showAlert('loginAlert', err.message || 'Login failed. Please check credentials.');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Login';
  }
});
