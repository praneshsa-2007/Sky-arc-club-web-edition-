/**
 * incharge.js — Court Incharge Dashboard Controller
 */

let allUsersList = [];
let currentRoleFilter = 'MEMBER';

document.addEventListener('DOMContentLoaded', async () => {
  const user = requireAuth('COURT_INCHARGE');
  if (!user) return;

  const today = todayStr();
  const tomorrow = tomorrowStr();
  if (document.getElementById('iTTDate')) document.getElementById('iTTDate').value = tomorrow;
  if (document.getElementById('iBookingDate')) document.getElementById('iBookingDate').value = today;
  if (document.getElementById('guestDate')) document.getElementById('guestDate').value = tomorrow;
  if (document.getElementById('addDOJ')) document.getElementById('addDOJ').value = today;

  await Promise.all([loadInchargeStats(), loadAllUsers()]);
  await loadGuests();

  document.addEventListener('tabChange', e => {
    if (e.detail === 'dashboard') loadInchargeStats();
    if (e.detail === 'referees') loadReferees();
    if (e.detail === 'timetable') loadInchargeTimetable();
    if (e.detail === 'members') loadAllUsers();
    if (e.detail === 'bookings') loadInchargeBookings();
    if (e.detail === 'guests') loadGuests();
    if (e.detail === 'courtinfo') renderCourtInfo('iCourtInfoDetail');
  });

  const guestDateInput = document.getElementById('guestDate');
  if (guestDateInput) {
    guestDateInput.addEventListener('change', loadSlotsForGuestModal);
  }
});

async function loadInchargeStats() {
  try {
    const s = await apiFetch('/api/stats');
    if (document.getElementById('iStatMembers')) document.getElementById('iStatMembers').textContent = s.totalMembers ?? 0;
    if (document.getElementById('iStatBookings')) document.getElementById('iStatBookings').textContent = s.todayBookings ?? 0;
    if (document.getElementById('iStatSlots')) document.getElementById('iStatSlots').textContent = s.availableSlots ?? 0;
    if (document.getElementById('iStatGuests')) document.getElementById('iStatGuests').textContent = s.guestReservations ?? 0;
  } catch (e) {
    console.error(e);
  }
}

// ── Timetable ──────────────────────────────────────────────
async function loadInchargeTimetable() {
  const date = document.getElementById('iTTDate').value;
  const container = document.getElementById('inchargeTTContainer');
  if (!container || !date) return;
  container.innerHTML = '<div class="loading"><div class="spinner"></div> Loading timetable...</div>';

  try {
    const slots = await apiFetch(`/api/timetable?date=${date}`);
    if (!slots.length) {
      container.innerHTML = `<div class="empty-state"><p>No slots found for ${fmtDate(date)}.</p></div>`;
      return;
    }

    const courts = [...new Set(slots.map(s => s.court_number))].sort();
    const times = [...new Set(slots.map(s => s.start_time))].sort();

    let html = `<div class="timetable-wrapper"><table class="timetable"><thead><tr><th>Time</th>`;
    courts.forEach(c => { html += `<th>Court ${c}</th>`; });
    html += '</tr></thead><tbody>';

    times.forEach(t => {
      const timeSlots = slots.filter(s => s.start_time === t);
      html += `<tr><td>${fmtTime(t)} - ${fmtTime(timeSlots[0].end_time)}</td>`;
      courts.forEach(c => {
        const slot = timeSlots.find(s => s.court_number === c);
        if (!slot) {
          html += '<td><span class="slot-cell slot-unavailable">No Slot</span></td>';
        } else {
          html += `<td><span class="slot-cell slot-open">${slot.displayStatus}</span></td>`;
        }
      });
      html += '</tr>';
    });
    html += '</tbody></table></div>';
    container.innerHTML = html;
  } catch (e) {
    container.innerHTML = `<div class="alert alert-danger">${e.message}</div>`;
  }
}

// ── User Management (Members & Coaches) ────────────────────
async function loadAllUsers() {
  const tbody = document.getElementById('iMemberTableBody');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">Loading users...</td></tr>';
  try {
    allUsersList = await apiFetch('/api/users');
    renderUserTable();
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="10" class="alert alert-danger">${e.message}</td></tr>`;
  }
}

function filterUserRole(role, btn) {
  currentRoleFilter = role;
  const parent = btn.parentElement;
  if (parent) {
    parent.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  }
  renderUserTable();
}

function renderUserTable() {
  const tbody = document.getElementById('iMemberTableBody');
  if (!tbody) return;
  let filtered = allUsersList;
  if (currentRoleFilter) {
    filtered = allUsersList.filter(u => u.role === currentRoleFilter);
  }

  if (!filtered.length) {
    tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">No users found.</td></tr>';
    return;
  }

  let html = '';
  filtered.forEach((u, i) => {
    html += `
      <tr>
        <td>${i + 1}</td>
        <td><strong>${u.name}</strong></td>
        <td>${u.username}</td>
        <td>${roleBadge(u.role)}</td>
        <td>${u.email}</td>
        <td>${u.phone || '—'}</td>
        <td>${u.age || '—'}</td>
        <td>${fmtDate(u.date_of_joining)}</td>
        <td>${statusBadge(u.active)}</td>
        <td>
          ${u.role !== 'COURT_INCHARGE' ? (
            u.active
              ? `<button class="btn btn-danger btn-sm" onclick="toggleUserStatus(${u.id}, 0)">Deactivate</button>`
              : `<button class="btn btn-primary btn-sm" onclick="toggleUserStatus(${u.id}, 1)">Activate</button>`
          ) : '—'}
        </td>
      </tr>`;
  });
  tbody.innerHTML = html;
}

async function toggleUserStatus(id, active) {
  const action = active ? 'activate' : 'deactivate';
  if (!confirm(`Are you sure you want to ${action} this user?`)) return;
  try {
    await apiFetch(`/api/users/${id}/status`, { method: 'PUT', body: JSON.stringify({ active }) });
    showAlert('iMemberAlert', `User ${action}d successfully.`, 'success');
    loadAllUsers();
    loadInchargeStats();
  } catch (e) {
    showAlert('iMemberAlert', e.message, 'danger');
  }
}

// ── Add Member, Coach, or Referee ──────────────────────────
function setAddUserRole(role, btn) {
  document.getElementById('addUserRole').value = role;
  const roleName = role === 'MEMBER' ? 'Member' : (role === 'COACH' ? 'Coach' : 'Referee');
  document.getElementById('addUserBtn').textContent = `Create ${roleName}`;
  const parent = btn.parentElement;
  if (parent) {
    parent.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  }

  const refFields = document.getElementById('refereeSpecificFields');
  const ageGroup = document.getElementById('userAgeGroup');
  const dojGroup = document.getElementById('userDojGroup');

  if (role === 'REFEREE') {
    if (refFields) refFields.classList.remove('hidden');
    if (ageGroup) ageGroup.classList.add('hidden');
    if (dojGroup) dojGroup.classList.add('hidden');
  } else {
    if (refFields) refFields.classList.add('hidden');
    if (ageGroup) ageGroup.classList.remove('hidden');
    if (dojGroup) dojGroup.classList.remove('hidden');
  }
}

async function submitAddUser(e) {
  e.preventDefault();
  hideAlert('addUserAlert');
  const role = document.getElementById('addUserRole').value;
  const name = document.getElementById('addName').value.trim();
  const username = document.getElementById('addUsername').value.trim();
  const email = document.getElementById('addEmail').value.trim();
  const password = document.getElementById('addPassword').value;
  const phone = document.getElementById('addPhone').value.trim() || null;

  if (!name || !username || !email || !password) {
    showAlert('addUserAlert', 'Please fill in Name, Username, Email, and Password.', 'warning');
    return;
  }

  const btn = document.getElementById('addUserBtn');
  btn.disabled = true;
  btn.textContent = 'Creating...';

  try {
    if (role === 'REFEREE') {
      const qualification = document.getElementById('addRefQual').value.trim() || 'Certified Referee';
      const experience = document.getElementById('addRefExp').value.trim() || null;
      await apiFetch('/api/referees', {
        method: 'POST',
        body: JSON.stringify({ name, username, email, password, phone, qualification, experience })
      });
      showAlert('addUserAlert', `✅ Referee "${name}" added successfully and login account created!`, 'success');
      loadReferees();
    } else {
      const ageVal = document.getElementById('addAge').value;
      const age = ageVal ? parseInt(ageVal, 10) : null;
      const date_of_joining = document.getElementById('addDOJ').value || null;
      await apiFetch('/api/users', {
        method: 'POST',
        body: JSON.stringify({ name, username, email, password, age, role, phone, date_of_joining })
      });
      showAlert('addUserAlert', `✅ ${role === 'MEMBER' ? 'Member' : 'Coach'} "${name}" created successfully!`, 'success');
    }

    document.getElementById('addUserForm').reset();
    document.getElementById('addDOJ').value = todayStr();
    loadAllUsers();
    loadInchargeStats();
  } catch (err) {
    showAlert('addUserAlert', err.message, 'danger');
  } finally {
    btn.disabled = false;
    btn.textContent = `Create ${role === 'MEMBER' ? 'Member' : (role === 'COACH' ? 'Coach' : 'Referee')}`;
  }
}

// ── Bookings ───────────────────────────────────────────────
async function loadInchargeBookings() {
  const tbody = document.getElementById('iBookingTableBody');
  const date = document.getElementById('iBookingDate').value;
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">Loading bookings...</td></tr>';
  try {
    let url = '/api/bookings';
    if (date) url += `?date=${date}`;
    const bookings = await apiFetch(url);
    if (!bookings.length) {
      tbody.innerHTML = `<tr><td colspan="9" class="text-center text-muted">No bookings found${date ? ' for ' + fmtDate(date) : ''}.</td></tr>`;
      return;
    }
    let html = '';
    bookings.forEach((b, i) => {
      html += `
        <tr>
          <td>${i + 1}</td>
          <td><strong>${b.member_name || b.username || '—'}</strong></td>
          <td>Court ${b.court_number}</td>
          <td>${fmtDate(b.slot_date)}</td>
          <td>${fmtTime(b.start_time)}–${fmtTime(b.end_time)}</td>
          <td>${b.batch}</td>
          <td>${roleBadge(b.booking_type)}</td>
          <td>${bookingStatusBadge(b.status)}</td>
          <td>
            ${b.status === 'CONFIRMED' ? `<button class="btn btn-danger btn-sm" onclick="cancelBookingAsIncharge(${b.id})">Cancel</button>` : '—'}
          </td>
        </tr>`;
    });
    tbody.innerHTML = html;
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="9" class="alert alert-danger">${e.message}</td></tr>`;
  }
}

async function cancelBookingAsIncharge(id) {
  if (!confirm('Cancel this booking as Court Incharge?')) return;
  try {
    await apiFetch(`/api/bookings/${id}`, { method: 'DELETE' });
    loadInchargeBookings();
    loadInchargeStats();
  } catch (e) { alert(e.message); }
}

// ── Guest Reservations ─────────────────────────────────────
async function loadGuests() {
  const tbody = document.getElementById('guestTableBody');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">Loading guest reservations...</td></tr>';
  try {
    const guests = await apiFetch('/api/guests');
    if (!guests.length) {
      tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No active guest reservations.</td></tr>';
      return;
    }
    let html = '';
    guests.forEach((g, i) => {
      html += `
        <tr>
          <td>${i + 1}</td>
          <td>Court ${g.court_number}</td>
          <td>${fmtDate(g.slot_date)}</td>
          <td>${fmtTime(g.start_time)}–${fmtTime(g.end_time)}</td>
          <td>${g.batch}</td>
          <td>${g.guest_count}</td>
          <td>${g.guest_info || '—'}</td>
          <td>${g.reserved_by_name || 'Incharge'}</td>
          <td>
            <button class="btn btn-danger btn-sm" onclick="cancelGuest(${g.id})">Cancel</button>
          </td>
        </tr>`;
    });
    tbody.innerHTML = html;
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="9" class="alert alert-danger">${e.message}</td></tr>`;
  }
}

function openGuestModal() {
  openModal('guestModal');
  loadSlotsForGuestModal();
}

async function loadSlotsForGuestModal() {
  const date = document.getElementById('guestDate').value;
  const sel = document.getElementById('guestSlotId');
  if (!date || !sel) return;
  sel.innerHTML = '<option value="">Loading slots...</option>';
  try {
    const slots = await apiFetch(`/api/slots?date=${date}`);
    sel.innerHTML = '<option value="">Select a slot to reserve</option>';
    slots.filter(s => s.status === 'AVAILABLE').forEach(s => {
      sel.innerHTML += `<option value="${s.id}">Court ${s.court_number} (${s.batch}: ${fmtTime(s.start_time)} - ${fmtTime(s.end_time)})</option>`;
    });
  } catch (e) {
    showAlert('guestModalAlert', e.message, 'danger');
  }
}

async function submitGuestReservation() {
  hideAlert('guestModalAlert');
  const slot_id = document.getElementById('guestSlotId').value;
  const guest_count = parseInt(document.getElementById('guestCount').value, 10) || 1;
  const guest_info = document.getElementById('guestInfo').value.trim();
  const notes = document.getElementById('guestNotes').value.trim();

  if (!slot_id) {
    showAlert('guestModalAlert', 'Please select a slot.', 'warning');
    return;
  }

  try {
    await apiFetch('/api/guests', {
      method: 'POST',
      body: JSON.stringify({ slot_id, guest_count, guest_info, notes })
    });
    closeModal('guestModal');
    showAlert('guestAlert', 'Court reserved for guests successfully! Confirmed slot is now protected.', 'success');
    loadGuests();
    loadInchargeStats();
  } catch (e) {
    showAlert('guestModalAlert', e.message, 'danger');
  }
}

async function cancelGuest(id) {
  if (!confirm('Cancel this guest reservation? The court slot will become AVAILABLE again.')) return;
  try {
    await apiFetch(`/api/guests/${id}`, { method: 'DELETE' });
    loadGuests();
    loadInchargeStats();
  } catch (e) { alert(e.message); }
}

// ── Referee Management (Rules 9 & 10) ────────────────────────
let refereesList = [];

async function loadReferees() {
  const tbody = document.getElementById('refereeTableBody');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted"><div class="spinner"></div> Loading referees...</td></tr>';

  try {
    refereesList = await apiFetch('/api/referees');
    if (!refereesList.length) {
      tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">No referees registered yet. Click "+ Add Referee" to register one.</td></tr>';
      return;
    }

    let html = '';
    refereesList.forEach((r, idx) => {
      const isAct = (r.status === 'ACTIVE');
      html += `
        <tr>
          <td>${idx + 1}</td>
          <td><strong>${r.name}</strong> ${r.username ? `<br><small class="text-muted">@${r.username}</small>` : ''}</td>
          <td>${r.qualification || '—'}</td>
          <td>${r.experience || '—'}</td>
          <td>${r.phone || '—'}<br><small class="text-muted">${r.email || ''}</small></td>
          <td><span class="badge ${r.availability === 'AVAILABLE' ? 'badge-green' : 'badge-gold'}">${r.availability}</span></td>
          <td><span class="badge ${isAct ? 'badge-green' : 'badge-red'}">${r.status}</span></td>
          <td>
            <button class="btn btn-secondary btn-sm" onclick="editReferee(${r.id})">Edit</button>
            <button class="btn ${isAct ? 'btn-danger' : 'btn-primary'} btn-sm" onclick="toggleRefereeStatus(${r.id}, '${r.status}')">
              ${isAct ? 'Deactivate' : 'Activate'}
            </button>
          </td>
        </tr>
      `;
    });
    tbody.innerHTML = html;
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="8" class="alert alert-danger">${err.message}</td></tr>`;
  }
}

function openRefereeModal() {
  hideAlert('refModalAlert');
  document.getElementById('refModalTitle').textContent = 'Add Referee';
  document.getElementById('refModalId').value = '';
  document.getElementById('refName').value = '';
  document.getElementById('refEmail').value = '';
  document.getElementById('refPhone').value = '';
  document.getElementById('refQual').value = '';
  document.getElementById('refExp').value = '';
  document.getElementById('refAvail').value = 'AVAILABLE';
  document.getElementById('refStatus').value = 'ACTIVE';
  document.getElementById('refUsername').value = '';
  document.getElementById('refPassword').value = '';
  document.getElementById('refAccountSection').classList.remove('hidden');

  openModal('refereeModal');
}

function editReferee(id) {
  const ref = refereesList.find(r => r.id === id);
  if (!ref) return;

  hideAlert('refModalAlert');
  document.getElementById('refModalTitle').textContent = 'Edit Referee';
  document.getElementById('refModalId').value = ref.id;
  document.getElementById('refName').value = ref.name;
  document.getElementById('refEmail').value = ref.email || '';
  document.getElementById('refPhone').value = ref.phone || '';
  document.getElementById('refQual').value = ref.qualification || '';
  document.getElementById('refExp').value = ref.experience || '';
  document.getElementById('refAvail').value = ref.availability || 'AVAILABLE';
  document.getElementById('refStatus').value = ref.status || 'ACTIVE';
  document.getElementById('refAccountSection').classList.add('hidden'); // don't re-create account on edit

  openModal('refereeModal');
}

async function saveReferee() {
  const id = document.getElementById('refModalId').value;
  const name = document.getElementById('refName').value.trim();
  const email = document.getElementById('refEmail').value.trim();
  const phone = document.getElementById('refPhone').value.trim();
  const qualification = document.getElementById('refQual').value.trim();
  const experience = document.getElementById('refExp').value.trim();
  const availability = document.getElementById('refAvail').value;
  const status = document.getElementById('refStatus').value;
  const username = document.getElementById('refUsername').value.trim();
  const password = document.getElementById('refPassword').value;
  const btn = document.getElementById('saveRefBtn');

  hideAlert('refModalAlert');

  if (!name || !qualification) {
    showAlert('refModalAlert', 'Referee Name and Qualification are required.');
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Saving...';

  try {
    if (id) {
      // Edit
      await apiFetch(`/api/referees/${id}`, {
        method: 'PUT',
        body: JSON.stringify({ name, email, phone, qualification, experience, availability, status })
      });
      showAlert('refModalAlert', 'Referee updated successfully!', 'success');
    } else {
      // Create
      await apiFetch('/api/referees', {
        method: 'POST',
        body: JSON.stringify({
          name, email, phone, qualification, experience, availability, status,
          username: username || null,
          password: password || null
        })
      });
      showAlert('refModalAlert', 'Referee created successfully!', 'success');
    }

    setTimeout(() => {
      closeModal('refereeModal');
      loadReferees();
    }, 1000);
  } catch (err) {
    showAlert('refModalAlert', err.message || 'Error saving referee.');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Save Referee';
  }
}

async function toggleRefereeStatus(id, currentStatus) {
  const newStatus = (currentStatus === 'ACTIVE') ? 'INACTIVE' : 'ACTIVE';
  if (!confirm(`Are you sure you want to mark this referee as ${newStatus}?`)) return;

  try {
    const ref = refereesList.find(r => r.id === id);
    if (!ref) return;
    await apiFetch(`/api/referees/${id}`, {
      method: 'PUT',
      body: JSON.stringify({
        name: ref.name,
        qualification: ref.qualification,
        status: newStatus
      })
    });
    loadReferees();
  } catch (err) {
    alert('Error toggling status: ' + err.message);
  }
}

