/**
 * create-tournament.js — Dedicated Tournament Creation logic for Coach
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Guard: Coach only
  const user = requireAuth('COACH');
  if (!user) return;
  setNavUser();

  // 2. Set default dates
  initDefaultDates();

  // 3. Set format description
  updateFormatDescription();
});

function initDefaultDates() {
  const d = new Date();
  // Start date in 3 days
  d.setDate(d.getDate() + 3);
  const startStr = d.toISOString().split('T')[0];
  document.getElementById('tStartDate').value = startStr;

  // End date in 4 days
  d.setDate(d.getDate() + 1);
  const endStr = d.toISOString().split('T')[0];
  document.getElementById('tEndDate').value = endStr;

  // Registration deadline tomorrow
  const regD = new Date();
  regD.setDate(regD.getDate() + 2);
  document.getElementById('tRegDeadline').value = regD.toISOString().split('T')[0];
}

const formatDescriptions = {
  KNOCKOUT: `<strong>Format B – Single Elimination Knockout:</strong> Traditional bracket structure (Round 1 → Quarter Finals → Semi Finals → Finals). Participants are eliminated upon losing a match. Supports automatic bye allocation for non-power-of-2 participant counts.`,
  LEAGUE: `<strong>Format A – League (Round Robin):</strong> Every registered participant or pair plays against every other participant in the group. Points, wins, losses, and score differentials are tracked in an official league table. Top ranked participants emerge as champions.`,
  NESTED_LEAGUE: `<strong>Format C – Nested League:</strong> Participants are divided into balanced group stages (Group A, Group B, etc.) operating as round-robin leagues. Top qualifying seeds from each group advance to an automatic knockout championship bracket.`,
  KNOCKOUT_TO_LEAGUE: `<strong>Format D – Knockout until Quarter Finals → League Stage:</strong> Hybrid format where participants compete in single elimination knockout rounds until the top 4 or 8 reach the Quarter Finals, where they transition into a round-robin league playoff stage.`,
  POOL_KNOCKOUT: `<strong>Format E – Pool / Group System → Knockout:</strong> Participants are organized into pools/groups. Group stage winners and runners-up automatically qualify for the knockout playoffs (Semi Finals and Finals).`
};

function updateFormatDescription() {
  const format = document.getElementById('tFormat').value;
  const descBox = document.getElementById('formatDescriptionBox');
  if (descBox && formatDescriptions[format]) {
    descBox.innerHTML = formatDescriptions[format];
  }
}

function updateCatStyle(checkbox) {
  const label = checkbox.closest('.category-card-check');
  if (label) {
    if (checkbox.checked) {
      label.classList.add('active');
    } else {
      label.classList.remove('active');
    }
  }
}

function toggleAllCategories(select) {
  const cbs = document.querySelectorAll('input[name="tCats"]');
  cbs.forEach(cb => {
    cb.checked = select;
    updateCatStyle(cb);
  });
}

function handlePosterSelection(event) {
  const file = event.target.files[0];
  if (!file) return;

  // Client preview
  const reader = new FileReader();
  const statusEl = document.getElementById('posterUploadStatus');
  reader.onload = async function (e) {
    const base64Data = e.target.result;
    document.getElementById('posterPreviewImg').src = base64Data;
    document.getElementById('posterPreviewContainer').classList.remove('hidden');
    if (statusEl) statusEl.textContent = '⏳ Uploading poster...';

    try {
      const res = await apiFetch('/api/tournaments/upload-poster', {
        method: 'POST',
        body: JSON.stringify({
          imageBase64: base64Data,
          filename: file.name
        })
      });
      document.getElementById('tPosterUrl').value = res.posterUrl;
      if (statusEl) statusEl.textContent = '✅ Poster uploaded successfully!';
    } catch (err) {
      console.warn('Poster server upload fallback:', err);
      // Fallback: keep base64 as poster url if endpoint has issues
      document.getElementById('tPosterUrl').value = base64Data;
      if (statusEl) statusEl.textContent = '✅ Poster ready to save.';
    }
  };
  reader.readAsDataURL(file);
}

function removePosterPreview() {
  document.getElementById('tPosterFile').value = '';
  document.getElementById('tPosterUrl').value = '';
  document.getElementById('posterPreviewImg').src = '';
  document.getElementById('posterPreviewContainer').classList.add('hidden');
}

async function handleTournamentSubmit(event) {
  event.preventDefault();

  const alertBox = 'pageAlert';
  hideAlert(alertBox);

  const name = document.getElementById('tName').value.trim();
  const description = document.getElementById('tDesc').value.trim();
  const format = document.getElementById('tFormat').value;
  const venue = document.getElementById('tVenue').value.trim();
  const start_date = document.getElementById('tStartDate').value;
  const end_date = document.getElementById('tEndDate').value;
  const timing = document.getElementById('tTiming').value.trim();
  const registration_deadline = document.getElementById('tRegDeadline').value;
  const food_provided = document.getElementById('tFoodProvided').checked;
  const poster_url = document.getElementById('tPosterUrl').value;
  const autoPublish = document.getElementById('autoPublishCheck').checked;

  const btn = document.getElementById('submitTournamentBtn');

  // Selected categories
  const catCheckboxes = document.querySelectorAll('input[name="tCats"]:checked');
  const categories = Array.from(catCheckboxes).map(cb => cb.value);

  if (!name || !venue || !start_date || !end_date || !timing) {
    showAlert(alertBox, 'Please complete all required fields.', 'danger');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    return;
  }

  if (new Date(end_date) < new Date(start_date)) {
    showAlert(alertBox, 'Tournament end date cannot be earlier than start date.', 'danger');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    return;
  }

  if (categories.length === 0) {
    showAlert(alertBox, 'Please select at least one category (Singles or Doubles).', 'danger');
    window.scrollTo({ top: 300, behavior: 'smooth' });
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Creating Tournament...';

  try {
    const res = await apiFetch('/api/tournaments', {
      method: 'POST',
      body: JSON.stringify({
        name,
        description,
        format,
        venue,
        start_date,
        end_date,
        timing,
        registration_deadline: registration_deadline || null,
        food_provided,
        poster_url: poster_url || null,
        categories
      })
    });

    const tournamentId = res.tournamentId;

    if (autoPublish && tournamentId) {
      btn.textContent = 'Publishing Tournament...';
      try {
        await apiFetch(`/api/tournaments/${tournamentId}/publish`, { method: 'POST' });
      } catch (pubErr) {
        console.warn('Auto publish warning:', pubErr);
      }
    }

    showAlert(
      alertBox,
      `🎉 Tournament "${name}" created successfully! ${autoPublish ? 'It is now published and open for registrations.' : 'Saved as Draft.'}`,
      'success'
    );
    window.scrollTo({ top: 0, behavior: 'smooth' });

    btn.textContent = 'Created!';

    // Return to the dedicated tournament listing after creation.
    setTimeout(() => {
      window.location.href = '/events.html';
    }, 1200);

  } catch (err) {
    showAlert(alertBox, err.message || 'Failed to create tournament. Please try again.', 'danger');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    btn.disabled = false;
    btn.textContent = 'Create Tournament';
  }
}
