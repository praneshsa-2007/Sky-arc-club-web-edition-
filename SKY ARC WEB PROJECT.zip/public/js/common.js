/**
 * common.js — Shared utilities for SkyArc frontend
 */

const API = '';

// ── Token management ───────────────────────────────────────
function getToken() { return localStorage.getItem('skyarc_token'); }
function getUser() {
  try { return JSON.parse(localStorage.getItem('skyarc_user')); }
  catch { return null; }
}
function saveAuth(token, user) {
  localStorage.setItem('skyarc_token', token);
  localStorage.setItem('skyarc_user', JSON.stringify(user));
}
function clearAuth() {
  localStorage.removeItem('skyarc_token');
  localStorage.removeItem('skyarc_user');
}

// ── API helper ─────────────────────────────────────────────
async function apiFetch(path, options = {}) {
  const token = getToken();
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (token) headers['Authorization'] = 'Bearer ' + token;
  const res = await fetch(API + path, { ...options, headers });
  const data = await res.json().catch(() => ({ message: 'Unknown error' }));
  if (!res.ok) throw Object.assign(new Error(data.message || 'Request failed'), { status: res.status, data });
  return data;
}

// ── Auth guard ─────────────────────────────────────────────
function requireAuth(expectedRole) {
  const token = getToken();
  const user = getUser();
  if (!token || !user) {
    window.location.href = '/';
    return false;
  }
  if (expectedRole && user.role !== expectedRole) {
    alert('Access denied. Redirecting to login.');
    clearAuth();
    window.location.href = '/';
    return false;
  }
  return user;
}

function logout() {
  if (confirm('Are you sure you want to logout?')) {
    clearAuth();
    window.location.href = '/';
  }
}

// ── Navbar user name ───────────────────────────────────────
function setNavUser() {
  const user = getUser();
  const el = document.getElementById('navUserName');
  if (el && user) el.textContent = `${user.name || user.username} (${user.role})`;
}

// ── Alert helpers ──────────────────────────────────────────
function showAlert(elOrId, msg, type = 'danger') {
  const el = typeof elOrId === 'string' ? document.getElementById(elOrId) : elOrId;
  if (!el) return;
  el.className = `alert alert-${type}`;
  el.textContent = msg;
  el.classList.remove('hidden');
}
function hideAlert(elOrId) {
  const el = typeof elOrId === 'string' ? document.getElementById(elOrId) : elOrId;
  if (el) el.classList.add('hidden');
}

// ── Modal helpers ──────────────────────────────────────────
function openModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.add('active');
}
function closeModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.remove('active');
}

document.addEventListener('click', event => {
  const target = event.target;
  if (target instanceof Element && target.matches('.modal-overlay.active')) {
    closeModal(target.id);
  }
});

document.addEventListener('keydown', event => {
  if (event.key !== 'Escape') return;

  document.querySelectorAll('.modal-overlay.active, div.modal.active:not(.modal-overlay)').forEach(modal => {
    closeModal(modal.id);
  });
});

// ── Date & Time helpers ────────────────────────────────────
function todayStr() {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function tomorrowStr() {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function fmtDate(d) {
  if (!d) return 'N/A';
  // Handle ISO string or YYYY-MM-DD
  const dateStr = typeof d === 'string' ? d.split('T')[0] : d;
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    const dt = new Date(parts[0], parts[1] - 1, parts[2]);
    return dt.toLocaleDateString('en-IN', { year: 'numeric', month: 'short', day: 'numeric' });
  }
  return new Date(d).toLocaleDateString('en-IN', { year: 'numeric', month: 'short', day: 'numeric' });
}

function fmtTime(t) {
  if (!t) return 'N/A';
  const parts = t.split(':');
  const hour = parseInt(parts[0], 10);
  const min = parts[1] || '00';
  const ampm = hour >= 12 ? 'PM' : 'AM';
  const h12 = hour % 12 || 12;
  return `${h12}:${min} ${ampm}`;
}

function fmtDateTime(dt) {
  if (!dt) return 'N/A';
  return new Date(dt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });
}

// ── Tab navigation ─────────────────────────────────────────
function initTabs() {
  const links = document.querySelectorAll('.tab-link');
  const panels = document.querySelectorAll('.tab-panel');
  links.forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      const tab = link.dataset.tab;
      links.forEach(l => l.classList.remove('active'));
      panels.forEach(p => p.classList.remove('active'));
      link.classList.add('active');
      const panel = document.getElementById('tab-' + tab);
      if (panel) panel.classList.add('active');
      document.dispatchEvent(new CustomEvent('tabChange', { detail: tab }));
    });
  });
}

// ── Badge helpers ──────────────────────────────────────────
function roleBadge(role) {
  const map = { MEMBER: 'badge-blue', COACH: 'badge-green', COURT_INCHARGE: 'badge-gold', REFEREE: 'badge-info' };
  return `<span class="badge ${map[role] || 'badge-gray'}">${role}</span>`;
}
function statusBadge(active) {
  return active
    ? '<span class="badge badge-green">Active</span>'
    : '<span class="badge badge-red">Inactive</span>';
}
function bookingStatusBadge(status) {
  const map = { CONFIRMED: 'badge-green', CANCELLED: 'badge-red', WAITLISTED: 'badge-gold' };
  return `<span class="badge ${map[status] || 'badge-gray'}">${status}</span>`;
}

// ── Court info display helper ──────────────────────────────
async function renderCourtInfo(containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;
  try {
    const [courts, batches] = await Promise.all([
      apiFetch('/api/courts'),
      apiFetch('/api/settings/batches')
    ]);

    let html = '';
    if (!courts || courts.length === 0) {
      html += '<p class="text-muted">Courts: Not configured yet</p>';
    } else {
      courts.forEach(c => {
        html += `
          <div class="info-row">
            <span class="info-label">Court ${c.court_number}</span>
            <span class="info-value"><strong>${c.court_name || 'Court ' + c.court_number}</strong> (${c.court_type}) — ${statusBadge(c.active)}</span>
          </div>`;
      });
    }

    const morningBatch = batches.find(b => b.batch_name === 'MORNING');
    const eveningBatch = batches.find(b => b.batch_name === 'EVENING');

    html += '<hr style="margin:1rem 0; border:0; border-top:1px solid #e0e0e0;">';
    html += `
      <div class="info-row">
        <span class="info-label">Morning Batch</span>
        <span class="info-value">${morningBatch ? fmtTime(morningBatch.open_time) + ' – ' + fmtTime(morningBatch.close_time) : 'Not configured yet'}</span>
      </div>
      <div class="info-row">
        <span class="info-label">Evening Batch</span>
        <span class="info-value">${eveningBatch ? fmtTime(eveningBatch.open_time) + ' – ' + fmtTime(eveningBatch.close_time) : 'Not configured yet'}</span>
      </div>
    `;

    // Fetch Court Incharge contact info
    try {
      const users = await apiFetch('/api/users?role=COURT_INCHARGE&active=1');
      if (users && users.length > 0) {
        const incharge = users[0];
        html += `
          <div class="info-row">
            <span class="info-label">Current Court Incharge</span>
            <span class="info-value">${incharge.name || incharge.username}</span>
          </div>
          <div class="info-row">
            <span class="info-label">Incharge Contact</span>
            <span class="info-value">${incharge.phone || incharge.email || 'Not configured'}</span>
          </div>`;
      } else {
        html += `
          <div class="info-row">
            <span class="info-label">Current Court Incharge</span>
            <span class="info-value">Not configured yet</span>
          </div>`;
      }
    } catch {
      // Incase members don't have user list permission or not configured
    }

    el.innerHTML = html;
  } catch (e) {
    el.innerHTML = '<p class="text-muted">Unable to load court information.</p>';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  setNavUser();
});
