/**
 * referee.js — Referee Dashboard Controller
 */

let assignedMatches = [];
let currentReferee = null;

document.addEventListener('DOMContentLoaded', async () => {
  const user = requireAuth('REFEREE');
  if (!user) return;

  await loadRefereeMatches();
});

async function loadRefereeMatches() {
  const tbody = document.getElementById('refereeMatchesTableBody');
  tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted"><div class="spinner"></div> Loading assigned matches...</td></tr>';

  try {
    const data = await apiFetch('/api/referees/my-matches');
    currentReferee = data.referee;
    assignedMatches = data.matches || [];

    // Profile header
    if (currentReferee) {
      document.getElementById('refereeWelcome').textContent = `Welcome, ${currentReferee.name}`;
      document.getElementById('refereeProfileDetails').textContent = `${currentReferee.qualification || 'Certified Referee'} • ${assignedMatches.length} Assigned Match(es)`;
    }

    // Stats
    const total = assignedMatches.length;
    const completed = assignedMatches.filter(m => m.status === 'COMPLETED').length;
    const pending = total - completed;

    document.getElementById('refStatTotalMatches').textContent = total;
    document.getElementById('refStatCompletedMatches').textContent = completed;
    document.getElementById('refStatPendingMatches').textContent = pending;

    if (total === 0) {
      tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">No matches currently assigned to you.</td></tr>';
      return;
    }

    let html = '';
    assignedMatches.forEach((m, idx) => {
      const isCompleted = (m.status === 'COMPLETED');
      const team1Display = m.team1_name || 'TBD';
      const team2Display = m.is_bye ? '<em class="text-muted">BYE</em>' : (m.team2_name || 'TBD');
      const scoreDisplay = m.scores_detail || (isCompleted ? `${m.team1_score} - ${m.team2_score}` : '—');
      const statusBadgeClass = isCompleted ? 'badge-green' : (m.status === 'BYE' ? 'badge-gray' : 'badge-blue');

      let actionBtn = '';
      if (isCompleted) {
        actionBtn = `<button class="btn btn-secondary btn-sm" onclick="openScoreModal(${m.id}, true)">🔒 View Locked</button>`;
      } else if (m.status === 'BYE') {
        actionBtn = `<span class="badge badge-gray">BYE</span>`;
      } else if (!m.team1_id || !m.team2_id) {
        actionBtn = `<span class="text-muted" style="font-size:0.8rem;">Awaiting teams</span>`;
      } else {
        actionBtn = `<button class="btn btn-primary btn-sm" onclick="openScoreModal(${m.id}, false)">Enter Result</button>`;
      }

      html += `
        <tr>
          <td>${idx + 1}</td>
          <td><strong>${m.tournament_name}</strong></td>
          <td>${m.category_display}</td>
          <td><span class="badge badge-gray">${m.round_name}</span></td>
          <td>
            <strong>${team1Display}</strong> vs <strong>${team2Display}</strong>
            ${m.winner_name ? `<br><small style="color:var(--green-accent);">Winner: ${m.winner_name}</small>` : ''}
          </td>
          <td>${m.scheduled_date ? fmtDate(m.scheduled_date) + '<br><small>' + fmtTime(m.scheduled_time) + '</small>' : '—'}</td>
          <td>${m.court_number ? 'Court ' + m.court_number : '—'}</td>
          <td><strong>${scoreDisplay}</strong></td>
          <td><span class="badge ${statusBadgeClass}">${m.status}</span></td>
          <td>${actionBtn}</td>
        </tr>
      `;
    });

    tbody.innerHTML = html;
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="10" class="alert alert-danger">${err.message}</td></tr>`;
  }
}

// ── Open Score Modal (Rules 21, 22) ──────────────────────────
function openScoreModal(matchId, isReadOnly = false) {
  const match = assignedMatches.find(m => m.id === matchId);
  if (!match) return;

  hideAlert('scoreAlert');
  document.getElementById('scoreMatchId').value = match.id;
  document.getElementById('scoreModalInfo').textContent = `${match.tournament_name} • ${match.category_display} • ${match.round_name}`;
  document.getElementById('scoreTeam1Name').textContent = match.team1_name || 'Team 1';
  document.getElementById('scoreTeam2Name').textContent = match.team2_name || 'Team 2';
  document.getElementById('scoreTeam1Label').textContent = `${match.team1_name || 'Team 1'} Score`;
  document.getElementById('scoreTeam2Label').textContent = `${match.team2_name || 'Team 2'} Score`;

  // Winner dropdown
  const winnerSelect = document.getElementById('winnerSelect');
  winnerSelect.innerHTML = `
    <option value="">Select Winner...</option>
    <option value="${match.team1_id}">${match.team1_name || 'Team 1'}</option>
    <option value="${match.team2_id}">${match.team2_name || 'Team 2'}</option>
  `;

  // Populate existing data if completed
  document.getElementById('team1Score').value = match.team1_score ?? '';
  document.getElementById('team2Score').value = match.team2_score ?? '';
  document.getElementById('scoresDetail').value = match.scores_detail ?? '';
  document.getElementById('winnerSelect').value = match.winner_id ?? '';
  document.getElementById('manOfMatch').value = match.result_mom || match.man_of_match || '';

  const lockNotice = document.getElementById('scoreLockNotice');
  const saveBtn = document.getElementById('saveScoreBtn');

  if (isReadOnly || match.status === 'COMPLETED') {
    lockNotice.innerHTML = '🔒 <strong>This match result is LOCKED and permanently finalized.</strong> Normal users and referees cannot modify locked match records.';
    lockNotice.style.background = '#eafaf1';
    lockNotice.style.borderColor = 'var(--green-accent)';
    lockNotice.style.color = 'var(--green-dark)';
    document.getElementById('team1Score').disabled = true;
    document.getElementById('team2Score').disabled = true;
    document.getElementById('scoresDetail').disabled = true;
    document.getElementById('winnerSelect').disabled = true;
    document.getElementById('manOfMatch').disabled = true;
    document.getElementById('durationMinutes').disabled = true;
    document.getElementById('matchRemarks').disabled = true;
    saveBtn.classList.add('hidden');
  } else {
    lockNotice.innerHTML = '🔒 <strong>Result Locking Policy:</strong> Once submitted, this match result is permanently locked and cannot be edited by anyone.';
    lockNotice.style.background = '#fef9e7';
    lockNotice.style.borderColor = 'var(--gold)';
    lockNotice.style.color = '#7d6608';
    document.getElementById('team1Score').disabled = false;
    document.getElementById('team2Score').disabled = false;
    document.getElementById('scoresDetail').disabled = false;
    document.getElementById('winnerSelect').disabled = false;
    document.getElementById('manOfMatch').disabled = false;
    document.getElementById('durationMinutes').disabled = false;
    document.getElementById('matchRemarks').disabled = false;
    saveBtn.classList.remove('hidden');
  }

  openModal('scoreModal');
}

// ── Submit Score (Strictly Locked!) ──────────────────────────
async function submitMatchScore() {
  const matchId = document.getElementById('scoreMatchId').value;
  const team1Score = document.getElementById('team1Score').value;
  const team2Score = document.getElementById('team2Score').value;
  const scoresDetail = document.getElementById('scoresDetail').value.trim();
  const winnerId = document.getElementById('winnerSelect').value;
  const manOfMatch = document.getElementById('manOfMatch').value.trim();
  const durationMinutes = document.getElementById('durationMinutes').value;
  const remarks = document.getElementById('matchRemarks').value.trim();
  const btn = document.getElementById('saveScoreBtn');

  hideAlert('scoreAlert');

  if (team1Score === '' || team2Score === '') {
    showAlert('scoreAlert', 'Please enter scores for both teams.');
    return;
  }

  if (!winnerId) {
    showAlert('scoreAlert', 'Please declare the match winner.');
    return;
  }

  if (!confirm('Are you sure you want to submit this result? This action will permanently LOCK the match result and advance tournament progression.')) {
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Submitting & Locking...';

  try {
    const res = await apiFetch(`/api/matches/${matchId}/result`, {
      method: 'POST',
      body: JSON.stringify({
        team1_score: parseInt(team1Score, 10),
        team2_score: parseInt(team2Score, 10),
        scores_detail: scoresDetail || `${team1Score}-${team2Score}`,
        winner_id: parseInt(winnerId, 10),
        man_of_match: manOfMatch || null,
        duration_minutes: durationMinutes ? parseInt(durationMinutes, 10) : null,
        remarks: remarks || null
      })
    });

    showAlert('scoreAlert', res.message || 'Result submitted and locked successfully!', 'success');
    setTimeout(() => {
      closeModal('scoreModal');
      loadRefereeMatches();
    }, 1200);
  } catch (err) {
    showAlert('scoreAlert', err.message || 'Failed to submit match result.');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Submit & Lock Result';
  }
}
