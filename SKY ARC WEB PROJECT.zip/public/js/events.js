/**
 * events.js — Events & Tournament Page Controller
 */

let allTournaments = [];
let currentFilterStatus = 'ALL';
let activeTournament = null;
let activeCategory = null;
let membersList = [];

document.addEventListener('DOMContentLoaded', async () => {
  setupNavbar();
  setupFilterListeners();
  await Promise.all([loadTournaments(), checkMyNextMatch()]);
});

function setupNavbar() {
  const user = getUser();
  const navDash = document.getElementById('navDashboardLink');
  const authBtn = document.getElementById('authBtn');
  const coachActions = document.getElementById('coachActions');

  if (user) {
    if (user.role === 'COACH') {
      navDash.href = '/coach.html';
      if (coachActions) coachActions.classList.remove('hidden');
    } else if (user.role === 'COURT_INCHARGE') {
      navDash.href = '/incharge.html';
    } else if (user.role === 'REFEREE') {
      navDash.href = '/referee.html';
    } else {
      navDash.href = '/member.html';
    }
    authBtn.textContent = 'Logout';
  } else {
    navDash.href = '/';
    authBtn.textContent = 'Login';
  }
}

function handleAuthAction() {
  const user = getUser();
  if (user) {
    logout();
  } else {
    window.location.href = '/';
  }
}

function setupFilterListeners() {
  // Status filter buttons
  document.querySelectorAll('.filter-status-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-status-btn').forEach(b => {
        b.classList.remove('btn-primary');
        b.classList.add('btn-secondary');
      });
      btn.classList.remove('btn-secondary');
      btn.classList.add('btn-primary');
      currentFilterStatus = btn.dataset.status;
      renderEvents();
    });
  });

  // Search and select filters
  document.getElementById('searchInput').addEventListener('input', renderEvents);
  document.getElementById('categoryFilter').addEventListener('change', renderEvents);
  document.getElementById('formatFilter').addEventListener('change', renderEvents);
}

// ── Next Match Banner (Rule 24) ──────────────────────────────
async function checkMyNextMatch() {
  const user = getUser();
  const container = document.getElementById('nextMatchContainer');
  if (!user || user.role !== 'MEMBER') return;

  try {
    const data = await apiFetch('/api/registrations/my-next-match');
    if (data && data.nextMatch) {
      const m = data.nextMatch;
      container.className = 'next-match-card';
      container.innerHTML = `
        <div class="next-match-header">
          <div>
            <span class="badge badge-gold">MY NEXT MATCH</span>
            <strong style="margin-left:0.5rem; font-size:1.1rem;">${m.tournament}</strong>
          </div>
          <span class="badge badge-blue">${m.round}</span>
        </div>
        <div class="next-match-vs">
          <div class="next-match-player">${user.name || user.username}</div>
          <div class="next-match-vs-tag">VS</div>
          <div class="next-match-player" style="color:var(--gold);">${m.opponent}</div>
        </div>
        <div class="next-match-details">
          <span>📅 <strong>Date:</strong> ${fmtDate(m.date)}</span>
          <span>⏰ <strong>Time:</strong> ${fmtTime(m.time)}</span>
          <span>🏸 <strong>Court:</strong> ${m.court}</span>
          <span>🏆 <strong>Category:</strong> ${m.category}</span>
          <span>📍 <strong>Venue:</strong> ${m.venue || 'Main Stadium'}</span>
        </div>
      `;
      container.classList.remove('hidden');
    } else {
      container.classList.add('hidden');
    }
  } catch (err) {
    console.error('Error checking next match:', err);
  }
}

// ── Load Tournaments ─────────────────────────────────────────
async function loadTournaments() {
  const container = document.getElementById('eventsContainer');
  try {
    allTournaments = await apiFetch('/api/tournaments');
    renderEvents();
  } catch (err) {
    container.innerHTML = `<div class="alert alert-danger" style="grid-column:1/-1;">${err.message}</div>`;
  }
}

function renderEvents() {
  const container = document.getElementById('eventsContainer');
  const search = document.getElementById('searchInput').value.trim().toLowerCase();
  const categoryFilter = document.getElementById('categoryFilter').value;
  const formatFilter = document.getElementById('formatFilter').value;

  let filtered = allTournaments.filter(t => {
    // Status filter
    if (currentFilterStatus === 'UPCOMING') {
      if (!['REGISTRATION_OPEN', 'REGISTRATION_CLOSED', 'UPCOMING'].includes(t.status)) return false;
    } else if (currentFilterStatus === 'ONGOING') {
      if (t.status !== 'ONGOING') return false;
    } else if (currentFilterStatus === 'COMPLETED') {
      if (t.status !== 'COMPLETED') return false;
    }

    // Search filter
    if (search) {
      const matchName = t.name.toLowerCase().includes(search);
      const matchVenue = (t.venue || '').toLowerCase().includes(search);
      if (!matchName && !matchVenue) return false;
    }

    // Category filter
    if (categoryFilter && t.categories) {
      if (!t.categories.some(c => c.category_name === categoryFilter)) return false;
    }

    // Format filter
    if (formatFilter && t.format !== formatFilter) return false;

    return true;
  });

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="empty-state" style="grid-column: 1/-1; padding: 3rem; text-align: center;">
        <h3>No tournaments found</h3>
        <p class="text-muted">No tournaments match the selected filters.</p>
      </div>`;
    return;
  }

  let html = '';
  filtered.forEach(t => {
    const posterHtml = t.poster_url
      ? `<img src="${t.poster_url}" alt="${t.name}" onerror="this.parentElement.innerHTML='<div class=\\'event-poster-placeholder\\'><span>🏸 SKYARC BADMINTON</span></div>'" />`
      : `<div class="event-poster-placeholder">
           <span style="font-size:2rem;">🏸</span>
           <span>SKYARC BADMINTON</span>
         </div>`;

    const statusBadgeMap = {
      DRAFT: 'badge-gray',
      REGISTRATION_OPEN: 'badge-green',
      REGISTRATION_CLOSED: 'badge-gold',
      UPCOMING: 'badge-blue',
      ONGOING: 'badge-green',
      COMPLETED: 'badge-gold',
      CANCELLED: 'badge-red'
    };

    const formatBadgeMap = {
      LEAGUE: 'League',
      KNOCKOUT: 'Knockout',
      NESTED_LEAGUE: 'Nested League',
      KNOCKOUT_TO_LEAGUE: 'Knockout → League',
      POOL_KNOCKOUT: 'Pool → Knockout'
    };

    let categoriesPills = '';
    if (t.categories && t.categories.length > 0) {
      t.categories.forEach(c => {
        categoriesPills += `<span class="cat-pill">${c.display_name}</span>`;
      });
    }

    const canRegister = (t.status === 'REGISTRATION_OPEN');

    html += `
      <div class="event-card">
        <div class="event-poster">
          ${posterHtml}
          <div class="event-badge-overlay">
            <span class="badge ${statusBadgeMap[t.status] || 'badge-gray'}">${t.status.replace('_', ' ')}</span>
            <span class="badge badge-blue">${formatBadgeMap[t.format] || t.format}</span>
          </div>
        </div>

        <div class="event-body">
          <h3 class="event-title">${t.name}</h3>
          
          <div class="event-meta">
            <div class="event-meta-item">📅 <strong>Date:</strong> ${fmtDate(t.start_date)} – ${fmtDate(t.end_date)}</div>
            <div class="event-meta-item">📍 <strong>Venue:</strong> ${t.venue}</div>
            <div class="event-meta-item">⏰ <strong>Timing:</strong> ${t.timing}</div>
            <div class="event-meta-item">🍽️ <strong>Food Provided:</strong> ${t.food_provided ? 'Yes' : 'No'}</div>
            ${t.status === 'COMPLETED' && t.winner_name ? `<div class="event-meta-item" style="color:var(--gold); font-weight:700;">🏆 <strong>Champion:</strong> ${t.winner_name}</div>` : ''}
          </div>

          <div>
            <div style="font-size:0.78rem; font-weight:700; color:var(--gray-600); margin-bottom:0.2rem;">CATEGORIES:</div>
            <div class="event-categories">${categoriesPills}</div>
          </div>
        </div>

        <div class="event-footer">
          <a href="/tournament-details.html?id=${t.id}" class="btn btn-secondary btn-sm">
            ${t.status === 'COMPLETED' ? 'View Results' : 'View Tournament'}
          </a>
          ${canRegister ? `<button class="btn btn-primary btn-sm" onclick="openRegisterModal(${t.id})">Register</button>` : ''}
        </div>
      </div>
    `;
  });

  container.innerHTML = html;
}

// ── Open Tournament Detail Page ──────────────────────────────
function openTournamentDetails(tournamentId) {
  window.location.href = `/tournament-details.html?id=${tournamentId}`;
}

// Member Tournament Registration Modal (Rules 15, 16, 17)
async function openRegisterModal(tournamentId) {
  const user = getUser();
  if (!user) {
    alert('Please log in as a member to register for tournaments.');
    window.location.href = '/';
    return;
  }

  const tournament = allTournaments.find(t => t.id === tournamentId);
  if (!tournament) return;

  hideAlert('regAlert');
  document.getElementById('regTournamentId').value = tournamentId;
  document.getElementById('regModalTitle').textContent = `Register: ${tournament.name}`;
  document.getElementById('regMemberName').value = user.name || user.username;

  // Populate categories
  const catSelect = document.getElementById('regCategorySelect');
  catSelect.innerHTML = '<option value="">Select category...</option>';
  tournament.categories.forEach(c => {
    catSelect.innerHTML += `<option value="${c.id}" data-type="${c.type}">${c.display_name} (${c.type})</option>`;
  });

  document.getElementById('regPartnerGroup').classList.add('hidden');
  document.getElementById('submitRegBtn').disabled = false;
  openModal('registrationModal');

  // Load members for partner selection
  if (membersList.length === 0) {
    try {
      const users = await apiFetch('/api/users?role=MEMBER&active=1');
      membersList = users.filter(u => u.id !== user.id);
    } catch {
      // If user list API restricted, will be empty
    }
  }

  const partnerSelect = document.getElementById('regPartnerSelect');
  partnerSelect.innerHTML = '<option value="">Select partner member...</option>';
  membersList.forEach(m => {
    partnerSelect.innerHTML += `<option value="${m.id}">${m.name || m.username}</option>`;
  });
}

function onRegCategoryChange() {
  const select = document.getElementById('regCategorySelect');
  const selectedOpt = select.options[select.selectedIndex];
  const type = selectedOpt ? selectedOpt.dataset.type : null;
  const partnerGroup = document.getElementById('regPartnerGroup');

  if (type === 'DOUBLES') {
    partnerGroup.classList.remove('hidden');
  } else {
    partnerGroup.classList.add('hidden');
  }
}

async function submitRegistration() {
  const tournamentId = document.getElementById('regTournamentId').value;
  const categoryId = document.getElementById('regCategorySelect').value;
  const partnerSelect = document.getElementById('regPartnerSelect');
  const partnerId = partnerSelect.value;
  const isDoubles = !document.getElementById('regPartnerGroup').classList.contains('hidden');
  const btn = document.getElementById('submitRegBtn');

  hideAlert('regAlert');

  if (!categoryId) {
    showAlert('regAlert', 'Please select a tournament category.');
    return;
  }

  if (isDoubles && !partnerId) {
    showAlert('regAlert', 'Please select a partner member for doubles.');
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Registering...';

  try {
    const res = await apiFetch(`/api/tournaments/${tournamentId}/register`, {
      method: 'POST',
      body: JSON.stringify({
        category_id: categoryId,
        partner_id: isDoubles ? partnerId : null
      })
    });

    showAlert('regAlert', res.message || 'Registration successful!', 'success');
    setTimeout(() => {
      closeModal('registrationModal');
      loadTournaments();
      checkMyNextMatch();
    }, 1200);
  } catch (err) {
    showAlert('regAlert', err.message || 'Registration failed.');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Submit Registration';
  }
}

// ── Coach Actions in Modal ───────────────────────────────────
async function triggerGenerateFixtures(tournamentId) {
  if (!confirm('Generate fixtures and schedule all matches across available courts and referees?')) return;
  try {
    const res = await apiFetch(`/api/tournaments/${tournamentId}/generate-fixtures`, {
      method: 'POST',
      body: JSON.stringify({})
    });
    alert(res.message);
    openTournamentDetails(tournamentId);
    loadTournaments();
  } catch (err) {
    alert('Error: ' + err.message);
  }
}

async function triggerEndTournament(tournamentId) {
  // Step 1 confirmation
  const step1 = confirm('Are you sure you want to end this tournament?');
  if (!step1) return;

  // Step 2 confirmation (Rule 27)
  const step2 = confirm('This action will finalize the tournament and prevent further result modifications. Do you really want to continue?');
  if (!step2) return;

  try {
    const res = await apiFetch(`/api/tournaments/${tournamentId}/end`, {
      method: 'POST',
      body: JSON.stringify({ confirm: true, second_confirm: true })
    });
    alert(res.message);
    openTournamentDetails(tournamentId);
    loadTournaments();
  } catch (err) {
    alert('Error: ' + err.message);
  }
}
