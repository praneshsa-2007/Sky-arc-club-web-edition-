/**
 * member.js — Member Dashboard Controller
 */

let selectedSlot = null;

document.addEventListener('DOMContentLoaded', async () => {
  const user = requireAuth('MEMBER');
  if (!user) return;

  const tomorrow = tomorrowStr();
  const ttDate = document.getElementById('ttDate');
  if (ttDate) {
    ttDate.value = tomorrow;
    ttDate.min = tomorrow;
  }

  await Promise.all([loadStats(), loadCourtInfoSummary(), loadMemberNextMatch()]);
  await loadMyBookings();

  document.addEventListener('tabChange', e => {
    if (e.detail === 'dashboard') { loadStats(); loadCourtInfoSummary(); loadMemberNextMatch(); }
    if (e.detail === 'timetable') { loadTimetable(); }
    if (e.detail === 'mybookings') { loadMyBookings(); }
    if (e.detail === 'courtinfo') { renderCourtInfo('courtInfoDetail'); }
  });
});

async function loadMemberNextMatch() {
  const container = document.getElementById('mNextMatchBanner');
  if (!container) return;
  try {
    const data = await apiFetch('/api/registrations/my-next-match');
    if (data && data.nextMatch) {
      const m = data.nextMatch;
      container.className = 'next-match-card mb-2';
      container.innerHTML = `
        <div class="next-match-header">
          <div>
            <span class="badge badge-gold">MY NEXT MATCH</span>
            <strong style="margin-left:0.5rem; font-size:1.1rem;">${m.tournament}</strong>
          </div>
          <span class="badge badge-blue">${m.round}</span>
        </div>
        <div class="next-match-vs">
          <div class="next-match-player">You</div>
          <div class="next-match-vs-tag">VS</div>
          <div class="next-match-player" style="color:var(--gold);">${m.opponent}</div>
        </div>
        <div class="next-match-details">
          <span>📅 <strong>Date:</strong> ${fmtDate(m.date)}</span>
          <span>⏰ <strong>Time:</strong> ${fmtTime(m.time)}</span>
          <span>🏸 <strong>Court:</strong> ${m.court}</span>
          <span>🏆 <strong>Category:</strong> ${m.category}</span>
          <span>📍 <strong>Venue:</strong> ${m.venue || 'Main Stadium'}</span>
        </div>
      `;
      container.classList.remove('hidden');
    } else {
      container.classList.add('hidden');
    }
  } catch (err) {
    console.error('Error loading member next match:', err);
  }
}

async function loadStats() {
  try {
    const s = await apiFetch('/api/stats');
    if (document.getElementById('statAvailable')) document.getElementById('statAvailable').textContent = s.availableSlots ?? 0;
    if (document.getElementById('statMyBookings')) document.getElementById('statMyBookings').textContent = s.myBookings ?? 0;
    if (document.getElementById('statUpcoming')) document.getElementById('statUpcoming').textContent = s.upcomingBookings ?? 0;
  } catch (e) {
    console.error(e);
  }
}

async function loadCourtInfoSummary() {
  await renderCourtInfo('courtInfoSummary');
}

function setTimetableBatch(batch) {
  const el = document.getElementById('ttBatch');
  if (el) el.value = batch;
  loadTimetable();
}

async function loadTimetable() {
  const dateInput = document.getElementById('ttDate');
  const date = dateInput ? dateInput.value : '';
  const batchInput = document.getElementById('ttBatch');
  const batch = batchInput ? batchInput.value : '';
  const container = document.getElementById('timetableContainer');
  if (!container) return;

  hideAlert('ttAlert');

  if (!date) {
    showAlert('ttAlert', 'Please select a date.', 'warning');
    return;
  }

  // One-day-before rule check
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const parts = date.split('-');
  const sel = new Date(parts[0], parts[1] - 1, parts[2]);
  if (sel <= today) {
    showAlert('ttAlert', 'Bookings can only be made at least 1 day in advance. Same-day bookings are not permitted for members.', 'warning');
    container.innerHTML = '<div class="alert alert-warning">Same-day booking is rejected for normal members. Please select tomorrow or a future date.</div>';
    return;
  }

  container.innerHTML = '<div class="loading"><div class="spinner"></div> Loading timetable...</div>';
  try {
    let url = `/api/timetable?date=${date}`;
    if (batch) url += `&batch=${batch}`;
    const slots = await apiFetch(url);

    if (!slots || slots.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <p>No slots configured for ${fmtDate(date)}.</p>
          <p class="text-muted">The coach has not designed or made slots available for this date yet.</p>
        </div>`;
      return;
    }

    container.innerHTML = buildTimetableHTML(slots, date);
  } catch (e) {
    container.innerHTML = `<div class="alert alert-danger">${e.message}</div>`;
  }
}

function buildTimetableHTML(slots, date) {
  const courts = [...new Set(slots.map(s => s.court_number))].sort();
  const times = [...new Set(slots.map(s => s.start_time))].sort();

  let html = `<p class="text-muted mb-2">Showing slots for <strong>${fmtDate(date)}</strong>. Click any available slot to book.</p>`;
  html += '<div class="timetable-wrapper"><table class="timetable">';
  html += '<thead><tr><th>Time Slot</th>';
  courts.forEach(c => { html += `<th>Court ${c}</th>`; });
  html += '</tr></thead><tbody>';

  times.forEach(time => {
    const timeSlots = slots.filter(s => s.start_time === time);
    html += '<tr>';
    const endT = timeSlots.length > 0 ? timeSlots[0].end_time : '';
    html += `<td>${fmtTime(time)} - ${fmtTime(endT)}</td>`;

    courts.forEach(court => {
      const slot = timeSlots.find(s => s.court_number === court);
      if (!slot) {
        html += '<td><span class="slot-cell slot-unavailable">No Slot</span></td>';
      } else {
        const cls = getSlotClass(slot);
        const canBook = isBookable(slot);
        const clickAttr = canBook ? `onclick="openBookingModal(${slot.slot_id})"` : '';
        const cursor = canBook ? 'cursor:pointer;' : 'cursor:not-allowed; opacity:0.8;';
        html += `
          <td ${clickAttr} style="${cursor}">
            <div class="slot-cell ${cls}" title="${slot.notes || ''}">
              ${slot.displayStatus}
            </div>
          </td>`;
      }
    });
    html += '</tr>';
  });

  html += '</tbody></table></div>';
  return html;
}

function getSlotClass(slot) {
  const s = slot.status;
  const count = slot.booked_count;
  const max = slot.max_capacity || 7;
  if (s === 'COACH_RESERVED' || s === 'INCHARGE_RESERVED') return 'slot-reserved';
  if (s === 'UNAVAILABLE' || s === 'CLOSED') return 'slot-unavailable';
  if (count >= max) return 'slot-full';
  if (count >= 4) return 'slot-ready';
  if (count > 0) return 'slot-open';
  return 'slot-available';
}

function isBookable(slot) {
  if (slot.status !== 'AVAILABLE') return false;
  if (slot.booked_count >= (slot.max_capacity || 7)) return false;
  return true;
}

async function openBookingModal(slotId) {
  selectedSlot = null;
  openModal('bookingModal');
  const detailsEl = document.getElementById('bookingDetails');
  const alertEl = document.getElementById('bookingAlert');
  const btn = document.getElementById('confirmBookBtn');
  btn.disabled = false;
  btn.textContent = 'Book The Slot';
  detailsEl.innerHTML = '<div class="loading"><div class="spinner"></div> Loading slot details...</div>';
  alertEl.innerHTML = '';

  try {
    const dateInput = document.getElementById('ttDate');
    const slots = await apiFetch(`/api/timetable?date=${dateInput.value}`);
    const slot = slots.find(s => s.slot_id === slotId);
    if (!slot) throw new Error('Slot details not found.');
    selectedSlot = slot;

    const count = slot.booked_count;
    const max = slot.max_capacity || 7;
    const remaining = max - count;

    let statusHtml = '';
    if (count >= max) {
      statusHtml = `<span class="badge badge-red">FULL - ${count}/${max}</span>`;
    } else if (count >= 4) {
      statusHtml = `<span class="badge badge-gold">READY - ${count}/${max}</span>`;
    } else {
      const needed = 4 - count;
      statusHtml = `<span class="badge badge-blue">OPEN - ${count}/${max} - Needs ${needed} more player${needed > 1 ? 's' : ''} for minimum group</span>`;
    }

    detailsEl.innerHTML = `
      <div class="info-row"><span class="info-label">Date</span><span class="info-value"><strong>${fmtDate(slot.slot_date)}</strong></span></div>
      <div class="info-row"><span class="info-label">Batch</span><span class="info-value">${slot.batch}</span></div>
      <div class="info-row"><span class="info-label">Time</span><span class="info-value">${fmtTime(slot.start_time)} – ${fmtTime(slot.end_time)}</span></div>
      <div class="info-row"><span class="info-label">Court Number</span><span class="info-value">Court ${slot.court_number} (${slot.court_type})</span></div>
      <div class="info-row"><span class="info-label">Current Player Count</span><span class="info-value">${count} / ${max}</span></div>
      <div class="info-row"><span class="info-label">Remaining Capacity</span><span class="info-value">${remaining} spots available</span></div>
      <div class="info-row"><span class="info-label">Group Status</span><span class="info-value">${statusHtml}</span></div>
      ${slot.notes ? `<div class="info-row"><span class="info-label">Notes</span><span class="info-value">${slot.notes}</span></div>` : ''}
    `;
  } catch (e) {
    detailsEl.innerHTML = `<div class="alert alert-danger">${e.message}</div>`;
  }
}

async function confirmBooking() {
  if (!selectedSlot) return;
  const btn = document.getElementById('confirmBookBtn');
  btn.disabled = true;
  btn.textContent = 'Processing Booking...';
  const alertEl = document.getElementById('bookingAlert');
  alertEl.innerHTML = '';

  try {
    const result = await apiFetch('/api/bookings', {
      method: 'POST',
      body: JSON.stringify({ slot_id: selectedSlot.slot_id })
    });

    alertEl.innerHTML = `
      <div class="alert alert-success">
        <div>
          <h4>🎉 Booking Confirmed!</h4>
          <p>Your slot has been reserved successfully on first-come-first-served priority.</p>
          <small>Court: Court ${selectedSlot.court_number} | Date: ${fmtDate(result.slotDate)} | Time: ${fmtTime(result.startTime)}–${fmtTime(result.endTime)}</small>
        </div>
      </div>`;
    btn.textContent = 'Confirmed!';
    loadStats();
    loadTimetable();
  } catch (e) {
    alertEl.innerHTML = `<div class="alert alert-danger">❌ ${e.message}</div>`;
    btn.disabled = false;
    btn.textContent = 'Book The Slot';
  }
}

async function loadMyBookings() {
  const container = document.getElementById('myBookingsContainer');
  if (!container) return;
  container.innerHTML = '<div class="loading"><div class="spinner"></div> Loading bookings...</div>';

  try {
    const bookings = await apiFetch('/api/bookings');
    if (!bookings || bookings.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <p>You have no active or previous bookings.</p>
          <p class="text-muted">Use the "Book a Slot" tab to reserve a court slot.</p>
        </div>`;
      return;
    }

    let html = `
      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Court</th>
              <th>Date</th>
              <th>Time</th>
              <th>Batch</th>
              <th>Type</th>
              <th>Status</th>
              <th>Booked At</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>`;

    bookings.forEach((b, i) => {
      html += `
        <tr>
          <td>${i + 1}</td>
          <td>Court ${b.court_number}</td>
          <td>${fmtDate(b.slot_date)}</td>
          <td>${fmtTime(b.start_time)}–${fmtTime(b.end_time)}</td>
          <td>${b.batch}</td>
          <td>${roleBadge(b.booking_type)}</td>
          <td>${bookingStatusBadge(b.status)}</td>
          <td>${fmtDateTime(b.booked_at)}</td>
          <td>
            ${b.status === 'CONFIRMED' ? `<button class="btn btn-danger btn-sm" onclick="cancelMyBooking(${b.id})">Cancel</button>` : '—'}
          </td>
        </tr>`;
    });

    html += '</tbody></table></div>';
    container.innerHTML = html;
  } catch (e) {
    container.innerHTML = `<div class="alert alert-danger">${e.message}</div>`;
  }
}

async function cancelMyBooking(id) {
  if (!confirm('Are you sure you want to cancel this booking?')) return;
  try {
    await apiFetch(`/api/bookings/${id}`, { method: 'DELETE' });
    loadMyBookings();
    loadStats();
    loadTimetable();
  } catch (e) {
    alert(e.message);
  }
}
