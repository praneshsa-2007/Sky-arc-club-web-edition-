/**
 * coach.js — Coach Dashboard Controller
 */

let allCourts = [];

document.addEventListener('DOMContentLoaded', async () => {
  const user = requireAuth('COACH');
  if (!user) return;

  const today = todayStr();
  const tomorrow = tomorrowStr();
  if (document.getElementById('slotDate')) document.getElementById('slotDate').value = tomorrow;
  if (document.getElementById('viewSlotDate')) document.getElementById('viewSlotDate').value = tomorrow;
  if (document.getElementById('coachTTDate')) document.getElementById('coachTTDate').value = tomorrow;
  if (document.getElementById('bookingFilterDate')) document.getElementById('bookingFilterDate').value = today;

  await Promise.all([loadStats(), loadCourts(), loadCourtsForDropdown()]);
  await loadBatchTimings();

  document.addEventListener('tabChange', e => {
    if (e.detail === 'dashboard') loadStats();
    if (e.detail === 'courts') loadCourts();
    if (e.detail === 'slots') { loadCourtsForDropdown(); loadSlots(); }
    if (e.detail === 'timetable') loadCoachTimetable();
    if (e.detail === 'members') loadMembers();
    if (e.detail === 'bookings') loadAllBookings();
    if (e.detail === 'batches') loadBatchTimings();
  });
});

async function loadStats() {
  try {
    const s = await apiFetch('/api/stats');
    if (document.getElementById('sTotalCourts')) document.getElementById('sTotalCourts').textContent = s.totalCourts ?? 0;
    if (document.getElementById('sTodaySlots')) document.getElementById('sTodaySlots').textContent = s.todaySlots ?? 0;
    if (document.getElementById('sTomorrowSlots')) document.getElementById('sTomorrowSlots').textContent = s.tomorrowSlots ?? 0;
    if (document.getElementById('sTotalMembers')) document.getElementById('sTotalMembers').textContent = s.totalMembers ?? 0;
    if (document.getElementById('sTodayBookings')) document.getElementById('sTodayBookings').textContent = s.todayBookings ?? 0;
  } catch (e) {
    console.error(e);
  }
}

// ── Court Management ───────────────────────────────────────
async function loadCourts() {
  const tbody = document.getElementById('courtTableBody');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">Loading courts...</td></tr>';
  try {
    allCourts = await apiFetch('/api/courts?active=all');
    if (!allCourts.length) {
      tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No courts configured yet. Click "+ Add Court" to create one.</td></tr>';
      return;
    }
    let html = '';
    allCourts.forEach((c, i) => {
      html += `
        <tr>
          <td>${i + 1}</td>
          <td><strong>Court ${c.court_number}</strong></td>
          <td>${c.court_name || '—'}</td>
          <td>${c.court_type}</td>
          <td>${statusBadge(c.active)}</td>
          <td>
            <button class="btn btn-secondary btn-sm" onclick="editCourt(${c.id})">Edit</button>
            ${c.active ? `<button class="btn btn-danger btn-sm" onclick="deactivateCourt(${c.id})">Deactivate</button>` : ''}
          </td>
        </tr>`;
    });
    tbody.innerHTML = html;
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="6" class="alert alert-danger">${e.message}</td></tr>`;
  }
}

function openCourtModal(isEdit = false) {
  hideAlert('courtAlert');
  if (!isEdit) {
    document.getElementById('courtModalTitle').textContent = 'Add New Court';
    document.getElementById('courtModalId').value = '';
    document.getElementById('courtNumber').value = '';
    document.getElementById('courtName').value = '';
    document.getElementById('courtType').value = 'WOODEN';
  }
  openModal('courtModal');
}

function editCourt(id) {
  const court = allCourts.find(c => c.id === id);
  if (!court) return;
  document.getElementById('courtModalTitle').textContent = 'Edit Court';
  document.getElementById('courtModalId').value = court.id;
  document.getElementById('courtNumber').value = court.court_number;
  document.getElementById('courtName').value = court.court_name || '';
  document.getElementById('courtType').value = court.court_type;
  openCourtModal(true);
}

async function saveCourt() {
  const id = document.getElementById('courtModalId').value;
  const court_number = document.getElementById('courtNumber').value.trim();
  const court_name = document.getElementById('courtName').value.trim();
  const court_type = document.getElementById('courtType').value;

  if (!court_number) {
    alert('Court number is required.');
    return;
  }

  try {
    if (id) {
      await apiFetch(`/api/courts/${id}`, {
        method: 'PUT',
        body: JSON.stringify({ court_number, court_name, court_type, active: 1 })
      });
    } else {
      await apiFetch('/api/courts', {
        method: 'POST',
        body: JSON.stringify({ court_number, court_name, court_type })
      });
    }
    closeModal('courtModal');
    showAlert('courtAlert', `Court ${court_number} saved successfully!`, 'success');
    loadCourts();
    loadStats();
  } catch (e) {
    alert(e.message);
  }
}

async function deactivateCourt(id) {
  if (!confirm('Deactivate this court? It will no longer appear for slot booking.')) return;
  try {
    await apiFetch(`/api/courts/${id}`, { method: 'DELETE' });
    loadCourts();
    loadStats();
  } catch (e) {
    alert(e.message);
  }
}

// ── Slot Designer ──────────────────────────────────────────
async function loadCourtsForDropdown() {
  const sel = document.getElementById('slotCourt');
  if (!sel) return;
  try {
    const courts = await apiFetch('/api/courts');
    sel.innerHTML = '<option value="">Select court</option>';
    courts.forEach(c => {
      sel.innerHTML += `<option value="${c.id}">Court ${c.court_number} (${c.court_type})</option>`;
    });
  } catch (e) { console.error(e); }
}

async function createSlot() {
  hideAlert('slotAlert');
  const court_id = document.getElementById('slotCourt').value;
  const slot_date = document.getElementById('slotDate').value;
  const batch = document.getElementById('slotBatch').value;
  const start_time = document.getElementById('slotStart').value;
  const end_time = document.getElementById('slotEnd').value;
  const notes = document.getElementById('slotNotes').value.trim();

  if (!court_id || !slot_date || !batch || !start_time || !end_time) {
    showAlert('slotAlert', 'Please fill in date, court, batch, start time, and end time.', 'warning');
    return;
  }

  try {
    await apiFetch('/api/slots', {
      method: 'POST',
      body: JSON.stringify({ court_id, slot_date, batch, start_time: start_time + ':00', end_time: end_time + ':00', notes })
    });
    showAlert('slotAlert', '✅ Slot created successfully!', 'success');
    document.getElementById('viewSlotDate').value = slot_date;
    loadSlots();
    loadStats();
  } catch (e) {
    showAlert('slotAlert', e.message, 'danger');
  }
}

async function loadSlots() {
  const date = document.getElementById('viewSlotDate').value;
  const tbody = document.getElementById('slotTableBody');
  if (!tbody || !date) return;
  tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">Loading slots...</td></tr>';

  try {
    const slots = await apiFetch(`/api/slots?date=${date}`);
    if (!slots.length) {
      tbody.innerHTML = `<tr><td colspan="8" class="text-center text-muted">No slots created for ${fmtDate(date)}.</td></tr>`;
      return;
    }
    let html = '';
    slots.forEach(s => {
      html += `
        <tr>
          <td>Court ${s.court_number}</td>
          <td>${s.batch}</td>
          <td>${fmtDate(s.slot_date)}</td>
          <td>${fmtTime(s.start_time)}</td>
          <td>${fmtTime(s.end_time)}</td>
          <td>${roleBadge(s.status)}</td>
          <td><strong>${s.booked_count}</strong> / ${s.max_capacity}</td>
          <td>
            ${s.status === 'AVAILABLE' ? `<button class="btn btn-warning btn-sm" onclick="toggleSlotStatus(${s.id}, 'UNAVAILABLE')">Mark Unavailable</button>` : ''}
            ${s.status === 'UNAVAILABLE' ? `<button class="btn btn-primary btn-sm" onclick="toggleSlotStatus(${s.id}, 'AVAILABLE')">Mark Available</button>` : ''}
            <button class="btn btn-danger btn-sm" onclick="deleteSlot(${s.id})">Delete</button>
          </td>
        </tr>`;
    });
    tbody.innerHTML = html;
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="8" class="alert alert-danger">${e.message}</td></tr>`;
  }
}

async function toggleSlotStatus(id, newStatus) {
  try {
    await apiFetch(`/api/slots/${id}`, { method: 'PUT', body: JSON.stringify({ status: newStatus }) });
    loadSlots();
  } catch (e) { alert(e.message); }
}

async function deleteSlot(id) {
  if (!confirm('Delete this slot?')) return;
  try {
    await apiFetch(`/api/slots/${id}`, { method: 'DELETE' });
    loadSlots();
    loadStats();
  } catch (e) { alert(e.message); }
}

// ── Copy Slots ─────────────────────────────────────────────
function openCopyModal() {
  const viewD = document.getElementById('viewSlotDate').value;
  document.getElementById('copyFromDate').value = viewD || todayStr();
  document.getElementById('copyToDate').value = tomorrowStr();
  hideAlert('copyAlert');
  openModal('copyModal');
}

async function copySlots() {
  const from_date = document.getElementById('copyFromDate').value;
  const to_date = document.getElementById('copyToDate').value;
  if (!from_date || !to_date) {
    showAlert('copyAlert', 'Please select both from and to dates.', 'warning');
    return;
  }
  try {
    const res = await apiFetch('/api/slots/copy', { method: 'POST', body: JSON.stringify({ from_date, to_date }) });
    closeModal('copyModal');
    showAlert('slotAlert', res.message, 'success');
    document.getElementById('viewSlotDate').value = to_date;
    loadSlots();
    loadStats();
  } catch (e) {
    showAlert('copyAlert', e.message, 'danger');
  }
}

// ── Coach Timetable ────────────────────────────────────────
async function loadCoachTimetable() {
  const date = document.getElementById('coachTTDate').value;
  const container = document.getElementById('coachTimetableContainer');
  if (!container || !date) return;
  container.innerHTML = '<div class="loading"><div class="spinner"></div> Loading timetable...</div>';

  try {
    const slots = await apiFetch(`/api/timetable?date=${date}`);
    if (!slots.length) {
      container.innerHTML = `<div class="empty-state"><p>No slots found for ${fmtDate(date)}.</p></div>`;
      return;
    }

    const courts = [...new Set(slots.map(s => s.court_number))].sort();
    const times = [...new Set(slots.map(s => s.start_time))].sort();

    let html = `<div class="timetable-wrapper"><table class="timetable"><thead><tr><th>Time</th>`;
    courts.forEach(c => { html += `<th>Court ${c}</th>`; });
    html += '</tr></thead><tbody>';

    times.forEach(t => {
      const timeSlots = slots.filter(s => s.start_time === t);
      html += `<tr><td>${fmtTime(t)} - ${fmtTime(timeSlots[0].end_time)}</td>`;
      courts.forEach(c => {
        const slot = timeSlots.find(s => s.court_number === c);
        if (!slot) {
          html += '<td><span class="slot-cell slot-unavailable">No Slot</span></td>';
        } else {
          html += `<td><span class="slot-cell slot-open">${slot.displayStatus}</span></td>`;
        }
      });
      html += '</tr>';
    });
    html += '</tbody></table></div>';
    container.innerHTML = html;
  } catch (e) {
    container.innerHTML = `<div class="alert alert-danger">${e.message}</div>`;
  }
}

// ── Whole-court Reservation ────────────────────────────────
async function openReserveModal() {
  const date = document.getElementById('coachTTDate').value;
  const sel = document.getElementById('reserveSlotId');
  sel.innerHTML = '<option value="">Loading slots...</option>';
  openModal('reserveModal');
  try {
    const slots = await apiFetch(`/api/slots?date=${date}`);
    sel.innerHTML = '<option value="">Select a slot to reserve</option>';
    slots.filter(s => s.status === 'AVAILABLE').forEach(s => {
      sel.innerHTML += `<option value="${s.id}">Court ${s.court_number} (${fmtTime(s.start_time)} - ${fmtTime(s.end_time)})</option>`;
    });
  } catch (e) {
    showAlert('reserveAlert', e.message, 'danger');
  }
}

async function reserveWholeCourt() {
  const slot_id = document.getElementById('reserveSlotId').value;
  const reason = document.getElementById('reserveReason').value.trim();
  if (!slot_id) {
    showAlert('reserveAlert', 'Please select a slot.', 'warning');
    return;
  }
  try {
    await apiFetch('/api/bookings/reserve', {
      method: 'POST',
      body: JSON.stringify({ slot_id, reason: reason || 'Coach Reservation' })
    });
    closeModal('reserveModal');
    loadCoachTimetable();
    loadStats();
    alert('Court reserved successfully! All existing member bookings were superseded.');
  } catch (e) {
    showAlert('reserveAlert', e.message, 'danger');
  }
}

// ── Member Management ──────────────────────────────────────
async function loadMembers() {
  const tbody = document.getElementById('memberTableBody');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">Loading members...</td></tr>';
  try {
    const members = await apiFetch('/api/users?role=MEMBER');
    if (!members.length) {
      tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No members found.</td></tr>';
      return;
    }
    let html = '';
    members.forEach((m, i) => {
      html += `
        <tr>
          <td>${i + 1}</td>
          <td><strong>${m.name}</strong></td>
          <td>${m.username}</td>
          <td>${m.email}</td>
          <td>${m.phone || '—'}</td>
          <td>${m.age || '—'}</td>
          <td>${fmtDate(m.date_of_joining)}</td>
          <td>${statusBadge(m.active)}</td>
          <td>
            ${m.active ? `<button class="btn btn-danger btn-sm" onclick="deactivateMember(${m.id})">Deactivate</button>` : `<button class="btn btn-primary btn-sm" onclick="activateMember(${m.id})">Activate</button>`}
          </td>
        </tr>`;
    });
    tbody.innerHTML = html;
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="9" class="alert alert-danger">${e.message}</td></tr>`;
  }
}

async function deactivateMember(id) {
  if (!confirm('Deactivate this member? They will not be able to log in or book slots.')) return;
  try {
    await apiFetch(`/api/users/${id}/status`, { method: 'PUT', body: JSON.stringify({ active: 0 }) });
    loadMembers();
    loadStats();
  } catch (e) { alert(e.message); }
}

async function activateMember(id) {
  try {
    await apiFetch(`/api/users/${id}/status`, { method: 'PUT', body: JSON.stringify({ active: 1 }) });
    loadMembers();
    loadStats();
  } catch (e) { alert(e.message); }
}

// ── All Bookings ───────────────────────────────────────────
async function loadAllBookings() {
  const tbody = document.getElementById('bookingTableBody');
  const date = document.getElementById('bookingFilterDate').value;
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">Loading bookings...</td></tr>';
  try {
    let url = '/api/bookings';
    if (date) url += `?date=${date}`;
    const bookings = await apiFetch(url);
    if (!bookings.length) {
      tbody.innerHTML = `<tr><td colspan="10" class="text-center text-muted">No bookings found${date ? ' for ' + fmtDate(date) : ''}.</td></tr>`;
      return;
    }
    let html = '';
    bookings.forEach((b, i) => {
      html += `
        <tr>
          <td>${i + 1}</td>
          <td><strong>${b.member_name || b.username || '—'}</strong></td>
          <td>Court ${b.court_number}</td>
          <td>${fmtDate(b.slot_date)}</td>
          <td>${fmtTime(b.start_time)}–${fmtTime(b.end_time)}</td>
          <td>${b.batch}</td>
          <td>${roleBadge(b.booking_type)}</td>
          <td>${bookingStatusBadge(b.status)}</td>
          <td>${fmtDateTime(b.booked_at)}</td>
          <td>
            ${b.status === 'CONFIRMED' ? `<button class="btn btn-danger btn-sm" onclick="cancelAnyBooking(${b.id})">Cancel</button>` : '—'}
          </td>
        </tr>`;
    });
    tbody.innerHTML = html;
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="10" class="alert alert-danger">${e.message}</td></tr>`;
  }
}

async function cancelAnyBooking(id) {
  if (!confirm('Cancel this booking as Coach?')) return;
  try {
    await apiFetch(`/api/bookings/${id}`, { method: 'DELETE' });
    loadAllBookings();
    loadStats();
  } catch (e) { alert(e.message); }
}

// ── Batch Timings ──────────────────────────────────────────
async function loadBatchTimings() {
  try {
    const batches = await apiFetch('/api/settings/batches');
    const m = batches.find(b => b.batch_name === 'MORNING');
    const e = batches.find(b => b.batch_name === 'EVENING');
    if (m) {
      if (document.getElementById('morningOpen')) document.getElementById('morningOpen').value = m.open_time.slice(0, 5);
      if (document.getElementById('morningClose')) document.getElementById('morningClose').value = m.close_time.slice(0, 5);
    }
    if (e) {
      if (document.getElementById('eveningOpen')) document.getElementById('eveningOpen').value = e.open_time.slice(0, 5);
      if (document.getElementById('eveningClose')) document.getElementById('eveningClose').value = e.close_time.slice(0, 5);
    }
  } catch (e) { console.error(e); }
}

async function saveBatch(batch_name) {
  hideAlert('batchAlert');
  const openId = batch_name === 'MORNING' ? 'morningOpen' : 'eveningOpen';
  const closeId = batch_name === 'MORNING' ? 'morningClose' : 'eveningClose';
  const open_time = document.getElementById(openId).value;
  const close_time = document.getElementById(closeId).value;

  if (!open_time || !close_time) {
    showAlert('batchAlert', `Please enter both opening and closing times for ${batch_name} batch.`, 'warning');
    return;
  }

  try {
    await apiFetch('/api/settings/batches', {
      method: 'PUT',
      body: JSON.stringify({ batch_name, open_time: open_time + ':00', close_time: close_time + ':00' })
    });
    showAlert('batchAlert', `✅ ${batch_name} batch timing updated successfully!`, 'success');
  } catch (e) {
    showAlert('batchAlert', e.message, 'danger');
  }
}
